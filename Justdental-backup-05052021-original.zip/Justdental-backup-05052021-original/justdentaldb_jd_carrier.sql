-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_carrier`
--

DROP TABLE IF EXISTS `jd_carrier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_carrier` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `CarrierNum` bigint(20) NOT NULL,
  `CarrierName` varchar(255) DEFAULT '',
  `Address` varchar(255) DEFAULT '',
  `Address2` varchar(255) DEFAULT '',
  `City` varchar(255) DEFAULT '',
  `State` varchar(255) DEFAULT '',
  `Zip` varchar(255) DEFAULT '',
  `Phone` varchar(255) DEFAULT '',
  `ElectID` varchar(255) DEFAULT '',
  `NoSendElect` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `IsCDA` tinyint(3) unsigned NOT NULL,
  `CDAnetVersion` varchar(100) DEFAULT '',
  `CanadianNetworkNum` bigint(20) NOT NULL,
  `IsHidden` tinyint(4) NOT NULL,
  `CanadianEncryptionMethod` tinyint(4) NOT NULL,
  `CanadianSupportedTypes` int(11) NOT NULL,
  `SecUserNumEntry` bigint(20) NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `TIN` varchar(255) NOT NULL,
  `CarrierGroupName` bigint(20) NOT NULL,
  `ApptTextBackColor` int(11) NOT NULL,
  `IsCoinsuranceInverted` tinyint(4) NOT NULL,
  `TrustedEtransFlags` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `CarrierNumName` (`CarrierNum`,`CarrierName`),
  KEY `CanadianNetworkNum` (`CanadianNetworkNum`),
  KEY `CarrierGroupName` (`CarrierGroupName`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_carrier`
--

LOCK TABLES `jd_carrier` WRITE;
/*!40000 ALTER TABLE `jd_carrier` DISABLE KEYS */;
INSERT INTO `jd_carrier` VALUES (1,1,'R','2021-05-05 08:17:00',6,'Star Insurance','1029 Insurance way','','San Antonio','78251','TX','(929)292-9292','963852',0,0,'',0,0,0,0,1,'2019-08-07','2019-08-07 19:42:55','',0,-986896,0,0),(2,1,'R','2021-05-05 08:17:00',7,'cvs','Test address','','San antonio','TX','78255','(343)434-3433','',0,0,'',0,0,0,0,1,'2020-12-20','2020-12-20 19:30:23','',0,0,0,0),(3,1,'R','2021-05-05 08:17:00',8,'Alabama','Test address','','San antonio','TX','78255','(343)434-3433','',0,0,'',0,0,0,0,1,'2020-12-28','2020-12-29 02:16:31','',0,0,0,0);
/*!40000 ALTER TABLE `jd_carrier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:50
