-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_procedurecode`
--

DROP TABLE IF EXISTS `jd_procedurecode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_procedurecode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `CodeNum` bigint(20) NOT NULL,
  `ProcCode` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `Descript` varchar(255) DEFAULT '',
  `AbbrDesc` varchar(50) DEFAULT '',
  `ProcTime` varchar(24) DEFAULT '',
  `ProcCat` bigint(20) NOT NULL,
  `TreatArea` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `NoBillIns` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `IsProsth` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `DefaultNote` text,
  `IsHygiene` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `GTypeNum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `AlternateCode1` varchar(15) DEFAULT '',
  `MedicalCode` varchar(15) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT '',
  `IsTaxed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `PaintType` tinyint(4) NOT NULL DEFAULT '0',
  `GraphicColor` int(11) NOT NULL,
  `LaymanTerm` varchar(255) DEFAULT '',
  `IsCanadianLab` tinyint(3) unsigned NOT NULL,
  `PreExisting` tinyint(1) NOT NULL DEFAULT '0',
  `BaseUnits` int(11) NOT NULL,
  `SubstitutionCode` varchar(25) DEFAULT NULL,
  `SubstOnlyIf` int(11) NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IsMultiVisit` tinyint(4) NOT NULL,
  `DrugNDC` varchar(255) NOT NULL,
  `RevenueCodeDefault` varchar(255) NOT NULL,
  `ProvNumDefault` bigint(20) NOT NULL,
  `CanadaTimeUnits` double NOT NULL,
  `IsRadiology` tinyint(4) NOT NULL,
  `DefaultClaimNote` text NOT NULL,
  `DefaultTPNote` text NOT NULL,
  `BypassGlobalLock` tinyint(4) NOT NULL,
  `TaxCode` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ProcCode` (`ProcCode`),
  KEY `ProvNumDefault` (`ProvNumDefault`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_procedurecode`
--

LOCK TABLES `jd_procedurecode` WRITE;
/*!40000 ALTER TABLE `jd_procedurecode` DISABLE KEYS */;
/*!40000 ALTER TABLE `jd_procedurecode` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:48
