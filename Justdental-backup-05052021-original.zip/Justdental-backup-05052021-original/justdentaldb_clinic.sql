-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clinic`
--

DROP TABLE IF EXISTS `clinic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(2000) NOT NULL,
  `groupof` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(55) DEFAULT NULL,
  `state` varchar(55) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `dentist_name` varchar(255) DEFAULT NULL,
  `primary_contact` varchar(255) DEFAULT NULL,
  `primary_phone` varchar(20) DEFAULT NULL,
  `secondary_phone` varchar(20) DEFAULT NULL,
  `primary_email` varchar(255) DEFAULT NULL,
  `website` varchar(2000) DEFAULT NULL,
  `appt_request_page` varchar(2000) DEFAULT NULL,
  `comments` varchar(2000) DEFAULT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `unique_id` varchar(200) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic`
--

LOCK TABLES `clinic` WRITE;
/*!40000 ALTER TABLE `clinic` DISABLE KEYS */;
INSERT INTO `clinic` VALUES (1,'Brook hallow family dentistry','','San Padro Avenue','Highway 281','Highway 281','Texas','78248','','Dr. Chauan','2102222222','','brookfamily@gmail.com','','','','2020-11-28 01:03:20',1,1,'866e6cd3-a868-4c74-9f7e-a3f8d6b29330'),(2,'Brooda Dentist','Brooda Dentist','Patty aventue',NULL,'San Antonio','Texas','78526',NULL,'Dr. Kunjan','2106545654',NULL,'kunjan@gmail.com',NULL,NULL,NULL,'2021-04-17 16:34:50',1,1,'beadba40-8802-418f-97de-1b29dfa3b85c'),(5,'Leenadental clinic','','Padi','addr2','Ambattur','Tamil Nadu','600050','Pottery Bold','EXCEL ENGG','2323232323',NULL,'excel@gmail.com','','',NULL,'2021-04-29 01:57:47',NULL,1,'47cf0235-09c4-4380-a397-5c0a7e2aa783'),(6,'Leenadental clinicas',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-04-29 04:59:00',NULL,1,'247bad97-b9b8-4157-9c46-fb68df3f5fc1'),(8,'Leenadental clinic 2','leema 2 group','','','','','','tim mothy','','',NULL,'','','',NULL,'2021-05-03 17:27:40',NULL,1,'ecbac942-3c28-4e93-a5c6-bee52dcb50a7'),(9,'Leenadental clinic 3','leem3 group','','','','','','kennedy john','','',NULL,'johnk@gmail.com','','',NULL,'2021-05-03 18:31:00',NULL,1,'73b484cc-b2fe-426f-8155-64d9a001077a');
/*!40000 ALTER TABLE `clinic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:42
