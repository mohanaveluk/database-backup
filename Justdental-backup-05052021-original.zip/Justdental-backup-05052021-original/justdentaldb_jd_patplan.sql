-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_patplan`
--

DROP TABLE IF EXISTS `jd_patplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_patplan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `PatPlanNum` bigint(20) NOT NULL,
  `PatNum` bigint(20) NOT NULL,
  `Ordinal` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `IsPending` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Relationship` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `PatID` varchar(100) DEFAULT '',
  `InsSubNum` bigint(20) NOT NULL,
  `OrthoAutoFeeBilledOverride` double NOT NULL DEFAULT '-1',
  `OrthoAutoNextClaimDate` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEntry` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `indexPatNum` (`PatNum`),
  KEY `InsSubNum` (`InsSubNum`),
  KEY `SecDateTEdit` (`SecDateTEdit`),
  KEY `SecDateTEntry` (`SecDateTEntry`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_patplan`
--

LOCK TABLES `jd_patplan` WRITE;
/*!40000 ALTER TABLE `jd_patplan` DISABLE KEYS */;
INSERT INTO `jd_patplan` VALUES (1,1,'R','2021-05-05 08:17:00',7,1,1,0,0,'',1,-1,'0001-01-01','0001-01-01 00:00:00','2020-11-24 17:13:38'),(2,1,'R','2021-05-05 08:17:00',8,2,1,0,0,'',2,-1,'0001-01-01','0001-01-01 00:00:00','2020-11-24 17:13:38'),(3,1,'R','2021-05-05 08:17:00',9,5,1,0,0,'',3,-1,'0001-01-01','0001-01-01 00:00:00','2020-11-24 17:13:38'),(4,1,'R','2021-05-05 08:17:00',10,3,1,0,0,'',4,-1,'0001-01-01','0001-01-01 00:00:00','2020-11-24 17:13:38'),(5,1,'R','2021-05-05 08:17:00',11,18,1,0,0,'',5,-1,'0001-01-01','2020-12-20 10:37:59','2020-12-20 16:37:59'),(6,1,'R','2021-05-05 08:17:00',12,18,2,0,0,'',6,-1,'0001-01-01','2020-12-28 19:40:40','2020-12-29 01:40:40');
/*!40000 ALTER TABLE `jd_patplan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:47
