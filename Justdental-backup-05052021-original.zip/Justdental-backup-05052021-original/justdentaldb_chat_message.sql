-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_message`
--

DROP TABLE IF EXISTS `chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chat_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `conversation_id` varchar(10) NOT NULL,
  `conversation_dir` varchar(10) NOT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdby` int(11) NOT NULL,
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_message`
--

LOCK TABLES `chat_message` WRITE;
/*!40000 ALTER TABLE `chat_message` DISABLE KEYS */;
INSERT INTO `chat_message` VALUES (5,5,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-11-30 05:45:08',1,1),(6,6,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-11-30 05:52:17',1,1),(7,7,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 00:50:41',1,1),(8,8,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:04:36',1,1),(9,9,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:06:17',1,1),(10,10,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:12:49',1,1),(11,11,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:14:01',1,1),(12,12,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:15:22',1,1),(13,13,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:18:22',1,1),(14,14,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 01:18:44',1,1),(15,15,5,1,5,'1-5','u-p','Hi Santra, Thanks you for choosing Brrok Hallow family dentistry!. We truly value your feedback. Please take a second to leave us a review on Google by tapping the link below. Thanks again!\nhttp://bit.ly/BHFDGoogle\n\nReply STOP to opt out of all text messages','2020-12-01 03:58:36',1,1),(16,16,5,1,5,'1-5','u-p','Hi Santra ,\n\nPlease click on the below link to send your review\n\nhttp://www.bity,com\n\nMohan dentist\n','2020-12-02 19:40:09',1,1),(17,17,1,1,1,'1-1','u-p','popopopoopop','2020-12-07 02:32:26',1,1),(18,18,2,1,2,'1-2','u-p','gfhghfghfghgfhfghfghfghghfg h fgh fgh fgh gfh gfh fgh fgh gfh gfh fgh','2020-12-12 14:50:17',1,1),(19,19,2,1,2,'1-2','u-p','dfdsfdf','2020-12-12 14:58:36',1,1),(20,20,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 11/27/2020 10:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-12 17:14:23',1,1),(21,21,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 11/27/2020 10:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-12 17:18:41',1,1),(22,22,9,1,9,'1-9','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTest3  Patient3 - appointment is on 12/28/2020 11:10 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-27 19:42:33',1,1),(23,23,9,1,9,'1-9','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTest3  Patient3 - appointment is on 12/28/2020 11:10 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-27 19:47:14',1,1),(24,24,9,1,9,'1-9','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTest3  Patient3 - appointment is on 12/28/2020 11:10 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-27 19:50:01',1,1),(25,25,9,1,9,'1-9','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTest3  Patient3 - appointment is on 12/28/2020 11:10 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-27 19:54:08',1,1),(26,26,9,1,9,'1-9','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTest3  Patient3 - appointment is on 12/28/2020 11:10 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2020-12-27 20:04:35',1,1),(27,27,20,1,20,'1-20','u-p','Hi Test14, Request you to fill COVID Questionnaire using the link https://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\n','2021-01-24 07:05:22',1,1),(28,31,2,1,2,'1-2','u-p','message - clinic base','2021-04-20 00:03:30',1,1),(29,32,2,1,2,'1-2','u-p','Hi Mark, Please take a minute to fill COVID Questionnaire.\nhttps://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\nReply STOP to opt out of all text messages','2021-04-20 04:39:16',1,1),(30,33,2,1,2,'1-2','u-p','Hi Mark, Please take a minute to fill COVID Questionnaire.\nhttps://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\nReply STOP to opt out of all text messages','2021-04-20 04:44:02',1,1),(31,34,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 02:10:16',1,1),(32,35,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 02:18:40',1,1),(33,36,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 02:35:20',1,1),(34,37,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 03:34:06',1,1),(35,38,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:14:51',1,1),(36,39,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:26:46',1,1),(37,40,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:36:16',1,1),(38,41,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:37:38',1,1),(39,42,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:43:27',1,1),(40,43,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:44:35',1,1),(41,44,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 04:51:31',1,1),(42,45,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:22:29',1,1),(43,46,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:23:14',1,1),(44,47,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:28:40',1,1),(45,48,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:29:23',1,1),(46,49,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:34:17',1,1),(47,50,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:35:13',1,1),(48,51,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 04/26/2021 14:30 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:35:46',1,1),(49,52,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 04/26/2021 14:30 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:35:57',1,1),(50,53,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 14:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:36:55',1,1),(51,54,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-21 05:37:05',1,1),(52,55,1,1,1,'1-1','u-p','Hi Teresa, Please take a minute to fill COVID Questionnaire.\nhttps://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\nReply STOP to opt out of all text messages','2021-04-21 05:43:30',1,1),(53,56,2,1,2,'1-2','u-p','Hi Mark, Please take a minute to fill COVID Questionnaire.\nhttps://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\nReply STOP to opt out of all text messages','2021-04-21 05:50:26',1,1),(54,57,3,1,3,'1-3','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nStewert  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 00:15:43',1,1),(55,58,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 01:52:59',1,1),(56,59,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/21/2021 16:55 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 01:53:35',1,1),(57,62,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:29:51',1,1),(58,63,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 04/26/2021 14:30 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:30:05',1,1),(59,64,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 04/26/2021 14:30 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:53:30',1,1),(60,65,1,1,1,'1-1','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nTeresa  Grant - appointment is on 04/23/2021 13:00 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:54:57',1,1),(61,66,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:56:16',1,1),(62,67,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:56:37',1,1),(63,68,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 16:58:10',1,1),(64,69,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 17:08:39',1,1),(65,70,2,1,2,'1-2','u-p','Dental appointment reminder from Brook Hollow Family Dentistry:\nMark  Grant - appointment is on 04/26/2021 11:20 . Please reply as either C or Confirm to confirm. \nIf you have any questions, please call 2104947681. \n\nReply STOP to opt out of all text messages','2021-04-22 17:25:52',1,1),(66,71,2,1,2,'1-2','u-p','Hi Mark, Please take a minute to fill COVID Questionnaire.\nhttps://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\nReply STOP to opt out of all text messages','2021-04-22 17:28:10',1,1),(67,72,2,1,2,'1-2','u-p','new txt','2021-04-22 17:28:20',1,1);
/*!40000 ALTER TABLE `chat_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger add_chat_activity
after insert
ON chat_message for each row
begin
	declare __template_eventname Text default '';
    declare __activity_role varchar(100) default '';
    declare __activity_description varchar(1000) default '';
    declare __appointment_datetime datetime default CURRENT_TIMESTAMP;
    
	if(new.conversation_dir = 'u-p') then
		-- select new.message into __template_eventname 
		-- from trigger_event te
		-- left join event e on e.id = te.event_id
		-- where te.template_id = new.template_id limit 1;
		
		-- select appt.AptDateTime into __appointment_datetime from appointment appt where appt.AptNum = new.appointment_id;
		set __template_eventname = new.message;
		set __appointment_datetime = new.createdon;
		
		
		-- setting __activity_role
		if(LOWER(__template_eventname) like '%appointment%' or LOWER(__template_eventname) like '%reminder%') then
			set __activity_role = 'Appointment';
		elseif(LOWER(__template_eventname) like '%patient%') then
			set __activity_role = 'Patient';
		elseif(LOWER(__template_eventname) like '%patient%') then
			set __activity_role = 'Patient1';
		end if;
		
		-- setting __activity_description
		if(LOWER(__template_eventname) like '%reminder%') then
			set __activity_description = 'Reminder sent';
		elseif(LOWER(__template_eventname) like '%review%') then
			set __activity_description = 'Review request has been sent';
		elseif(LOWER(__template_eventname) like '%feedback%') then
			set __activity_description = 'Feedback request has been sent';
		else
			set __activity_description = __template_eventname;
		end if;
		
		-- insert data into activity table
		if new.message IS NOT NULL then
			INSERT INTO activity (
				patient_id	
				,activity_type_id
				,act_datetime
				,act_description
				,act_role
                ,act_other
				,user_id
				,createdby
                ,createdon
                ,clinic_id
			) values (
				new.patient_id
				,2
				,__appointment_datetime
				,__activity_description
				,__activity_role
                ,''
				,new.createdby
				,new.createdby
                ,__appointment_datetime
                ,new.clinic_id
			);
		end if;
    end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:49
