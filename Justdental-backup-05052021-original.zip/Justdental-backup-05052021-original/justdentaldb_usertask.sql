-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usertask`
--

DROP TABLE IF EXISTS `usertask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usertask` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_no` bigint(20) DEFAULT '0',
  `task_name` varchar(255) DEFAULT '',
  `task_description` varchar(2055) DEFAULT '',
  `task_type` varchar(20) DEFAULT '',
  `task_cycle` varchar(20) DEFAULT NULL,
  `task_start` datetime DEFAULT NULL,
  `task_end` datetime DEFAULT NULL,
  `range_start` datetime DEFAULT NULL,
  `range_end` datetime DEFAULT NULL,
  `taskto` int(11) DEFAULT '0',
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `createdby` int(11) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  `comments` varchar(2000) DEFAULT '',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `updatedby` int(11) DEFAULT '0',
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertask`
--

LOCK TABLES `usertask` WRITE;
/*!40000 ALTER TABLE `usertask` DISABLE KEYS */;
INSERT INTO `usertask` VALUES (1,1,'first','','single','Month','2021-04-22 15:00:00','2021-04-25 01:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-24 19:34:57',1,_binary '','','2021-04-24 14:34:57',1,1),(2,1,'secnd','','single','Month','2020-12-13 00:00:00','2020-12-14 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','0001-01-01 00:00:00',0,1),(3,1,'thrid','','single','Month','2020-12-26 00:00:00','2020-12-27 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '\0','','0001-01-01 00:00:00',0,1),(4,1,'dfdfdfdfdf','','single','Month','2021-05-12 06:00:00','2021-05-12 07:00:00','2021-01-01 00:00:00','2021-02-01 00:00:00',0,'2021-04-24 19:25:10',1,_binary '','','2021-04-24 14:25:10',1,1),(5,1,'aasasas','','single','Month','2021-05-25 00:00:00','2021-02-26 00:00:00','2021-02-01 00:00:00','2021-03-01 00:00:00',0,'2021-04-22 04:39:19',1,_binary '\0','','0001-01-01 00:00:00',0,1),(6,1,'range 1','','single','Month','2021-05-17 10:00:00','2021-05-17 11:00:00','2021-02-01 00:00:00','2021-03-01 00:00:00',0,'2021-04-24 19:26:18',1,_binary '','','2021-04-24 14:26:18',1,1),(7,1,'sdsdsdssdsd','','single','Month','2021-05-21 13:00:00','2021-05-21 14:00:00','2021-02-01 00:00:00','2021-03-01 00:00:00',0,'2021-04-24 19:36:16',1,_binary '\0','','2021-04-24 14:27:13',1,1),(8,1,'regards','','single','Month','2020-12-25 00:00:00','2020-12-26 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 22:11:48',1,1),(9,1,'range dec','','single','Month','2020-12-29 00:00:00','2021-01-01 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 22:23:24',1,1),(10,1,'another meeting','','single','Month','2020-12-25 00:00:00','2020-12-26 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '\0','','0001-01-01 00:00:00',0,1),(11,1,'call patient 1','','single','Month','2020-12-23 00:00:00','2020-12-24 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','0001-01-01 00:00:00',0,1),(12,1,'call patient 3','','single','Month','2020-12-26 00:00:00','2020-12-27 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '\0','','0001-01-01 00:00:00',0,1),(13,1,'capp patient 4','','single','Month','2020-12-24 00:00:00','2020-12-25 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','0001-01-01 00:00:00',0,1),(14,1,'call p[atient 5','','single','Month','2020-12-23 00:00:00','2020-12-24 00:00:00','2020-12-01 00:00:00','2021-01-01 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','0001-01-01 00:00:00',0,1),(15,1,'call patient 6','','single','timeGridDay','2020-12-25 09:00:00','2020-12-25 11:00:00','2020-12-25 00:00:00','2020-12-26 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 19:46:28',1,1),(16,1,'call patient 7','','single','timeGridWeek','2020-12-27 13:00:00','2020-12-27 13:30:00','2020-12-20 00:00:00','2020-12-27 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 20:31:47',1,1),(17,1,'call patient 9','','single','timeGridDay','2020-12-24 16:00:00','2020-12-24 18:30:00','2020-12-25 00:00:00','2020-12-26 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 22:11:51',1,1),(18,1,'call patient 10','','single','timeGridDay','2020-12-28 18:30:00','2020-12-28 21:00:00','2020-12-25 00:00:00','2020-12-26 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 20:37:57',1,1),(19,1,'meeting 1','','single','timeGridDay','2020-12-27 14:30:00','2020-12-27 17:00:00','2020-12-27 00:00:00','2020-12-28 00:00:00',0,'2021-04-22 04:38:46',1,_binary '','','2020-12-26 20:44:48',1,1),(20,0,'Meeting','','single','Month','2021-05-07 00:00:00','2021-05-08 00:00:00','2021-05-01 00:00:00','2021-06-01 00:00:00',0,'2021-04-24 19:32:06',1,_binary '\0','','0001-01-01 00:00:00',0,1),(21,0,'Meeting','','single','Month','2021-05-07 09:00:00','2021-05-07 11:00:00','2021-05-01 00:00:00','2021-06-01 00:00:00',0,'2021-04-24 19:33:18',1,_binary '','','2021-04-24 14:33:18',1,1);
/*!40000 ALTER TABLE `usertask` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:43
