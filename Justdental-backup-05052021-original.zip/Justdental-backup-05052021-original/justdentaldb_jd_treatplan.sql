-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_treatplan`
--

DROP TABLE IF EXISTS `jd_treatplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_treatplan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `TreatPlanNum` bigint(20) NOT NULL,
  `PatNum` bigint(20) NOT NULL,
  `DateTP` date NOT NULL DEFAULT '0001-01-01',
  `Heading` varchar(255) DEFAULT '',
  `Note` text,
  `Signature` text,
  `SigIsTopaz` tinyint(1) NOT NULL,
  `ResponsParty` bigint(20) NOT NULL,
  `DocNum` bigint(20) NOT NULL,
  `TPStatus` tinyint(4) NOT NULL,
  `SecUserNumEntry` bigint(20) NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserNumPresenter` bigint(20) NOT NULL,
  `TPType` tinyint(4) NOT NULL,
  `SignaturePractice` text NOT NULL,
  `DateTSigned` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `DateTPracticeSigned` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `SignatureText` varchar(255) NOT NULL,
  `SignaturePracticeText` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TreatPlanNum` (`TreatPlanNum`),
  KEY `indexPatNum` (`PatNum`),
  KEY `DocNum` (`DocNum`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `UserNumPresenter` (`UserNumPresenter`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_treatplan`
--

LOCK TABLES `jd_treatplan` WRITE;
/*!40000 ALTER TABLE `jd_treatplan` DISABLE KEYS */;
INSERT INTO `jd_treatplan` VALUES (1,1,'R','2021-05-05 08:17:00',1,1,'0001-01-01','General Cleaning and filling','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-07','2019-08-07 22:30:50',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(2,1,'R','2021-05-05 08:17:00',2,2,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-07','2019-08-07 19:49:29',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(3,1,'R','2021-05-05 08:17:00',3,5,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-09','2019-08-09 23:58:07',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(4,1,'R','2021-05-05 08:17:00',4,5,'2019-08-09','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,0,1,'2019-08-09','2019-08-09 23:59:47',1,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(5,1,'R','2021-05-05 08:17:00',5,3,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2019-08-09','2019-08-10 00:13:55',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(6,1,'R','2021-05-05 08:17:00',6,17,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-10-02','2020-10-03 03:19:19',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(7,1,'R','2021-05-05 08:17:00',7,16,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-10-10','2020-10-11 04:26:04',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(8,1,'R','2021-05-05 08:17:00',8,18,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-10-11','2020-10-11 22:54:42',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(9,1,'R','2021-05-05 08:17:00',9,7,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-12-15','2020-12-15 22:54:37',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(10,1,'R','2021-05-05 08:17:00',10,23,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-12-16','2020-12-16 22:40:48',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','',''),(11,1,'R','2021-05-05 08:17:00',11,14,'0001-01-01','Active Treatment Plan','If you have dental insurance, please be aware that THIS IS AN ESTIMATE ONLY.  Coverage may be different if your deductible has not been met, annual maximum has been met, or if your coverage table is lower than average.','',0,0,0,1,1,'2020-12-20','2020-12-20 16:37:30',0,0,'','0001-01-01 00:00:00','0001-01-01 00:00:00','','');
/*!40000 ALTER TABLE `jd_treatplan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:43
