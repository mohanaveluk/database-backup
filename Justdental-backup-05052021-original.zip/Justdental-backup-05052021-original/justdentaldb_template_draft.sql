-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `template_draft`
--

DROP TABLE IF EXISTS `template_draft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_draft` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `bodycontent` mediumtext,
  `bodycontent_text` mediumtext,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(11) DEFAULT NULL,
  `updatedon` datetime DEFAULT NULL,
  `updatedby` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  `comments` varchar(5000) DEFAULT NULL,
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `category_idfktemp_1` FOREIGN KEY (`category_id`) REFERENCES `templatecategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_draft`
--

LOCK TABLES `template_draft` WRITE;
/*!40000 ALTER TABLE `template_draft` DISABLE KEYS */;
INSERT INTO `template_draft` VALUES (1,1,'Text','Appointment Confirmation','[#FirstName] , please reply Y to confirm your appt on [#ApptDatetime] or call [#ClinicContact]. [#Dependants] [#ClinicName]. Reply STOP to opt out of ALL txt msg.\n','[#FirstName] , please reply Y to confirm your appt on [#ApptDatetime] or call [#ClinicContact]. [#Dependants] [#ClinicName]. Reply STOP to opt out of ALL txt msg.\n','2020-11-28 23:09:16',1,'2021-04-23 00:17:18',1,1,NULL,1),(2,1,'Text','Appointment Confirmation','[#FirstName] - Your dental appt is [#ApptDatetime]. [#Dependants] Reply with the letters `DDS` to confirm or call us @ [#ClinicContact] . Plz tell us of any insur/health/contact changes when you arrive. [#ClinicName] Reply STOP to opt out of ALL txt msgs.\n','[#FirstName] - Your dental appt is [#ApptDatetime]. [#Dependants] Reply with the letters `DDS` to confirm or call us @ [#ClinicContact] . Plz tell us of any insur/health/contact changes when you arrive. [#ClinicName] Reply STOP to opt out of ALL txt msgs.\n','2020-11-28 23:09:16',1,'2021-04-23 00:17:23',1,1,NULL,1),(3,1,'Text','Appointment Confirmation','[#FirstName] - Please reply `DDS` to confirm your dental appt on [#ApptDatetime]. [#Dependants] [#ClinicName]. Reply STOP to opt out of ALL txt msgs - [#ReviewLink]\n','[#FirstName] - Please reply `DDS` to confirm your dental appt on [#ApptDatetime]. [#Dependants] [#ClinicName]. Reply STOP to opt out of ALL txt msgs - [#ReviewLink]\n','2020-11-28 23:09:16',1,'2020-12-02 11:59:46',1,1,NULL,1),(4,1,'Text','Appointment Confirmation','[#FirstName] , Reply `DDS` to confirm or call [#ClinicContact] for appt on [#ApptDatetime]. [#Dependants]  (2 days notice for cancellations.) [#ClinicName]  Reply STOP to opt out of ALL txt msgs\n','[#FirstName] , Reply `DDS` to confirm or call [#ClinicContact] for appt on [#ApptDatetime]. [#Dependants]  (2 days notice for cancellations.) [#ClinicName]  Reply STOP to opt out of ALL txt msgs\n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(5,1,'Text','Appointment Confirmation','[#FirstName] - Dental Appt - [#ApptDatetime]. [#Dependants]  Reply with the\nletters `DDS` to confirm or call us @ [#ClinicContact] . [#ClinicName]. Reply STOP\nto opt out of ALL txt msgs\n','[#FirstName] - Dental Appt - [#ApptDatetime]. [#Dependants]  Reply with the\nletters `DDS` to confirm or call us @ [#ClinicContact] . [#ClinicName]. Reply STOP\nto opt out of ALL txt msgs\n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(6,1,'Text','Appointment Confirmation','It\'s Time! Dental appts on [#ApptDatetime]: [#Dependants]  Reply \'YES\' to confirm these appts. Reply STOP to opt out of ALL txt msgs\n','It\'s Time! Dental appts on [#ApptDatetime]: [#Dependants]  Reply \'YES\' to confirm these appts. Reply STOP to opt out of ALL txt msgs\n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(7,1,'Text','Appointment Confirmation','[#FirstName], please reply Y to confirm your appt on  [#ApptDatetime] or call [#ClinicContact]. [#Dependants]  [#ClinicName]  Reply STOP to opt out of ALL txt msg.\n','[#FirstName], please reply Y to confirm your appt on  [#ApptDatetime] or call [#ClinicContact]. [#Dependants]  [#ClinicName]  Reply STOP to opt out of ALL txt msg.\n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(8,1,'Text','Appointment Confirmation','Dear [#FirstName], please reply \"C\" to confirm. [#Dependants] If you have any questions, please call [#ClinicName] [#ClinicContact]. Text STOP to opt out of txt msg. [#FeedbackLink] \n','Dear [#FirstName], please reply \"C\" to confirm. [#Dependants] If you have any questions, please call [#ClinicName] [#ClinicContact]. Text STOP to opt out of txt msg. [#FeedbackLink] \n','2020-11-28 23:09:16',1,'2020-12-02 12:00:31',1,1,NULL,1),(9,1,'Email','Appointment Confirmation','<p>[#FirstName], Please click the \"<span style=\"color: rgb(34, 34, 34);\">Confirm\" </span>button to confirm this appointment by email or call us at [#ClinicContact]. [#ApptDatetime]  [#Dependants]  We look forward to seeing you!</p><p><br></p><p><br></p><p>[#Signature] </p>','[#FirstName], Please click the \"Confirm\" button to confirm this appointment by email or call us at [#ClinicContact]. [#ApptDatetime]  [#Dependants]  We look forward to seeing you!\n\n\n[#Signature] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(10,1,'Email','Casual Confirm','<p>Dear [#FirstName], We are looking forward to seeing you on [#ApptDatetime]. We hope life has been treating you</p><p>well since your last dental appointment and look forward to giving you a clean healthy mouth...and catching up. Please call</p><p>us at [#ClinicContact]  or e-mail [#ClinicEmail]  to confirm that you will be here. We are really looking forward</p><p>to it.</p><p><br></p><p>[#Signature] </p><p>REMINDER: - [#Dependants] </p>','Dear [#FirstName], We are looking forward to seeing you on [#ApptDatetime]. We hope life has been treating you\nwell since your last dental appointment and look forward to giving you a clean healthy mouth...and catching up. Please call\nus at [#ClinicContact]  or e-mail [#ClinicEmail]  to confirm that you will be here. We are really looking forward\nto it.\n\n[#Signature] \nREMINDER: - [#Dependants] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(11,1,'Email','Appointment Confirmation','<p>[#FirstName] , Please click the \"confirm\" button to confirm this appointment by email or call us at [#ClinicContact] . [#ApptDatetime] [#Dependants]  We look forward to seeing you!</p><p><br></p><p>[#Signature] </p>','[#FirstName] , Please click the \"confirm\" button to confirm this appointment by email or call us at [#ClinicContact] . [#ApptDatetime] [#Dependants]  We look forward to seeing you!\n\n[#Signature] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(12,1,'Email','Confirm Fee','<p>Dear [#FirstName], It\'s Time! The appointment you made for your dental health is: [#ApptDatetime]. Please call us</p><p>at [#ClinicContact] or click the \"<span style=\"color: rgb(34, 34, 34);\">Confirm</span>\" button to confirm this appointment by email. Any changes or cancellation requires 24</p><p>hour notice or a fee will be charged. We look forward to seeing you!</p><p><br></p><p>[#Signature]</p><p>REMINDER: [#Dependants] </p>','Dear [#FirstName], It\'s Time! The appointment you made for your dental health is: [#ApptDatetime]. Please call us\nat [#ClinicContact] or click the \"Confirm\" button to confirm this appointment by email. Any changes or cancellation requires 24\nhour notice or a fee will be charged. We look forward to seeing you!\n\n[#Signature]\nREMINDER: [#Dependants] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(13,1,'Email','Confirm No Phone','<p>Dear [#FirstName] , It\'s Time! The appointment you made for your dental health is: [#ApptDatetime].  Please call us</p><p>or e-mail [#ClinicEmail] to confirm this appointment. We look forward to seeing you! </p><p><br></p><p>[#Signature] </p><p>REMINDER: [#Dependants] </p>','Dear [#FirstName] , It\'s Time! The appointment you made for your dental health is: [#ApptDatetime].  Please call us\nor e-mail [#ClinicEmail] to confirm this appointment. We look forward to seeing you! \n\n[#Signature] \nREMINDER: [#Dependants] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(14,1,'Email','Confirm List','<p>Dear [#FirstName], It\'s Time! The appointments you made for your family\'s oral health are: [#FirstName], [#ApptDatetime] [#Dependants] </p><p>Please call us at [#ClinicContact]  or click the \"confirm appointment button\" to confirm these appointments. We look forward to</p><p>seeing you all!</p><p><br></p><p>[#Signature] </p>','Dear [#FirstName], It\'s Time! The appointments you made for your family\'s oral health are: [#FirstName], [#ApptDatetime] [#Dependants] \nPlease call us at [#ClinicContact]  or click the \"confirm appointment button\" to confirm these appointments. We look forward to\nseeing you all!\n\n[#Signature] \n','2020-11-28 23:09:16',1,NULL,NULL,1,NULL,1),(15,2,'Email','Referal','<p>[#FirstName]</p><p><br></p><p>Get $200 as a referral bonus - 1</p><p><br></p><p><br></p><p>[#Signature]</p>','[#FirstName]\n\nGet $200 as a referral bonus - 1\n\n\n[#Signature]\n','2021-04-24 11:39:28',1,'2021-04-24 11:44:04',1,1,'',1);
/*!40000 ALTER TABLE `template_draft` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:50
