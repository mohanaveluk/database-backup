-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `histforgotpassword`
--

DROP TABLE IF EXISTS `histforgotpassword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `histforgotpassword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `emailId` varchar(255) DEFAULT NULL,
  `guid` varchar(255) DEFAULT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` datetime DEFAULT NULL,
  `expirydatetime` datetime DEFAULT NULL,
  `isActive` bit(1) DEFAULT b'1',
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `users_fk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `histforgotpassword`
--

LOCK TABLES `histforgotpassword` WRITE;
/*!40000 ALTER TABLE `histforgotpassword` DISABLE KEYS */;
INSERT INTO `histforgotpassword` VALUES (1,1,1,'admin@gmail.com','5ef8f809-2702-445e-83dd-f31e97e4e752','2020-12-15 05:11:30','2020-12-15 00:39:00','2020-12-17 23:11:00',_binary '\0',0),(2,1,1,'admin@gmail.com','ed0a0be7-3676-41c5-866a-142befeaa920','2020-12-15 07:05:23','2020-12-15 01:08:00','2020-12-18 01:05:00',_binary '\0',0),(3,1,1,'admin@gmail.com','ef8529b7-2d44-41bb-9d7d-365f5fbcaad1','2020-12-15 07:08:39','2020-12-15 01:09:00','2020-12-18 01:08:00',_binary '\0',0),(4,1,1,'admin@gmail.com','e1d8f725-15e4-49f3-a731-84fb0817309d','2020-12-15 20:13:33','2020-12-15 14:14:00','2020-12-18 14:13:00',_binary '\0',0),(5,1,1,'admin@gmail.com','6bd87baa-8eb8-4ae5-a367-5f60e45453e7','2020-12-15 20:24:25','2020-12-15 14:25:00','2020-12-18 14:24:00',_binary '\0',0),(6,1,1,'admin@gmail.com','9b914b29-7382-48c2-89dd-0d3680f8da98','2020-12-15 22:46:45','2020-12-15 16:47:00','2020-12-18 16:46:00',_binary '\0',0),(7,1,1,'admin@gmail.com','9bf886d4-e0ab-4df4-85b3-e844ae218ce5','2020-12-16 02:53:12',NULL,'2020-12-18 20:53:00',_binary '',0),(8,1,1,'admin@gmail.com','c0198409-3ad1-4834-9444-16c433b8f478','2020-12-16 02:54:00',NULL,'2020-12-18 20:54:00',_binary '',0),(9,1,2,'mohanaveluk@gmail.com','3a7de08b-630b-4646-9b85-d35bf39bf769','2020-12-16 02:54:11',NULL,'2020-12-18 20:54:00',_binary '',0),(10,1,2,'mohanaveluk@gmail.com','f035f6db-595c-4a80-bba6-091077ea5f2e','2020-12-16 02:56:43',NULL,'2020-12-18 20:56:00',_binary '',0),(11,1,2,'mohanaveluk@gmail.com','1bca409d-af5a-43ee-8c5c-5721f37b6650','2020-12-16 05:13:48',NULL,'2020-12-18 23:13:00',_binary '',0),(12,1,2,'mohanaveluk@gmail.com','2d6363b8-cd72-4a35-a9d3-757a4b35bab1','2020-12-16 05:21:21',NULL,'2020-12-18 23:21:00',_binary '',0),(13,0,2,'mohanaveluk@gmail.com','aaaassseeeddd','2021-04-25 22:17:39',NULL,'2020-12-13 20:00:00',_binary '',1),(14,0,2,'2323','2222','2021-04-25 22:26:46',NULL,'2021-04-25 17:19:00',_binary '',1),(15,0,2,'2323','2222','2021-04-25 22:33:18',NULL,'2021-04-25 17:19:14',_binary '',1),(16,0,2,'2323','2222','2021-04-25 22:35:12',NULL,'2021-04-25 17:19:00',_binary '',1),(17,0,2,'mohanaveluk@gmail.com','73202cd3-ec2f-4eef-b878-135ad58913c8','2021-04-25 22:39:17',NULL,'2021-04-25 17:38:00',_binary '',1),(18,0,2,'mohanaveluk@gmail.com','999f7cb4-9db1-4859-9c62-e58e9491c00c','2021-04-25 22:43:47',NULL,'2021-04-25 17:43:00',_binary '',1),(19,0,2,'mohanaveluk@gmail.com','745fecdb-affd-49f1-a750-1a6c8410be06','2021-04-25 22:46:59',NULL,'2021-04-25 17:46:00',_binary '',1),(20,0,2,'mohanaveluk@gmail.com','33aacd6e-36fd-499c-a17b-5511fd225433','2021-04-25 22:51:17',NULL,'2021-04-25 17:51:00',_binary '',1),(21,0,2,'mohanaveluk@gmail.com','8b60f016-d7e9-44b2-bddf-f5cd6b7ea38b','2021-04-25 22:54:13',NULL,'2021-04-25 17:54:00',_binary '',1),(22,0,2,'mohanaveluk@gmail.com','e1b8e9fb-43ff-442f-ae49-2d039bec93c9','2021-04-25 22:56:15',NULL,'2021-04-25 17:56:00',_binary '',1),(23,0,2,'mohanaveluk@gmail.com','9f8b22b7-bbfe-452b-bbd7-8c805c7c8504','2021-04-25 23:08:02',NULL,'2021-04-25 18:08:00',_binary '',1),(24,0,2,'mohanaveluk@gmail.com','53bc34c1-d236-4763-83bf-14227055e7ea','2021-04-25 23:14:16',NULL,'2021-04-25 18:14:00',_binary '',1),(25,0,2,'mohanaveluk@gmail.com','ba8e9933-a1ea-4fc3-bd7c-3cb8df6f4a58','2021-04-25 23:25:20',NULL,'2021-04-25 18:25:00',_binary '',1),(26,0,2,'mohanaveluk@gmail.com','8e27ad82-738b-43a0-93ca-89b681d50c89','2021-04-25 23:34:05',NULL,'2021-04-25 18:34:00',_binary '',1),(27,0,2,'mohanaveluk@gmail.com','c256ac62-e424-428f-b5b2-9764454d617f','2021-04-25 23:38:48',NULL,'2021-04-25 18:38:00',_binary '',1),(28,0,5,'plain@gmail.com','71be8f13-f0a0-4c84-83b7-305d4b1f1f42','2021-04-25 23:54:02',NULL,'2021-04-25 18:54:00',_binary '',2),(29,0,5,'plain@gmail.com','c457dfb3-4f5e-4f66-9086-3b6586b2ea3a','2021-04-26 00:12:16',NULL,'2021-04-25 19:12:00',_binary '',2),(30,0,5,'plain@gmail.com','ec2edda2-0e52-4904-9649-343c0255f9bf','2021-04-26 00:12:55',NULL,'2021-04-25 19:12:00',_binary '',2),(31,0,5,'plain@gmail.com','acd3a95a-9991-4ae5-8a6b-b2065980a278','2021-04-26 00:16:08',NULL,'2021-04-25 19:16:00',_binary '',2),(32,0,5,'plain@gmail.com','4890d51c-d279-4e77-b6d3-115c348cd223','2021-04-26 00:17:24',NULL,'2021-04-25 19:17:00',_binary '',2),(33,0,19,'leema@gmail.com','f6437b74-71fc-4178-ac08-149765ae85a6','2021-04-29 02:50:40',NULL,'2021-04-28 21:50:00',_binary '',5),(34,0,19,'leema@gmail.com','a727049e-02e4-420f-b44f-5e4b8ef9f551','2021-04-29 04:14:13',NULL,'2021-04-28 23:14:00',_binary '',5);
/*!40000 ALTER TABLE `histforgotpassword` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:46
