-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templatetypename_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `templatefor` varchar(250) DEFAULT NULL,
  `leadtime_number` int(11) DEFAULT '0',
  `leadtime_interval` int(11) DEFAULT '0',
  `leadtime_mode` int(11) DEFAULT '0',
  `bodycontent` mediumtext,
  `createdby` int(11) DEFAULT NULL,
  `updatedby` int(11) DEFAULT NULL,
  `createdon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedon` datetime DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  `comments` varchar(5000) DEFAULT NULL,
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `templatetypename_id` (`templatetypename_id`),
  CONSTRAINT `templatetypename_idfk_1` FOREIGN KEY (`templatetypename_id`) REFERENCES `templatetypename` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES (1,1,1,1,'Appointment Confirmation',NULL,NULL,NULL,NULL,'<p>[#FirstName],</p><p><br></p><p>Please click the \"<span style=\"color: rgb(34, 34, 34);\">Confirm\" </span>button to confirm this appointment by email or call us at [#ClinicContact]. [#ApptDatetime] [#Dependants] We look forward to seeing you!</p><p><br></p><p><br></p><p>[#Signature]</p><p><br></p><p>[#ReviewLink]</p>',1,1,'2020-11-29 22:43:38','2021-04-24 11:44:35',1,NULL,1),(2,2,3,1,'Send Review Request',NULL,1,2,2,'<p>Hi [#FirstName] ,</p><p><br></p><p>Please click on the below link to send your review</p><p><br></p><p>[#ReviewLink] </p><p><br></p><p>[#Signature]</p>',1,1,'2020-11-30 04:43:22','2020-12-02 12:01:36',1,NULL,1),(3,3,3,1,'Feedback link',NULL,10,3,2,'<p>Hi [#FirstName],</p><p><br></p><p>Please send your feedback about the recent experience.</p><p><br></p><p>[#FeedbackLink]</p><p><br></p><p>[#Signature]</p>',1,1,'2020-12-02 19:23:21','2021-04-24 01:05:27',1,NULL,1),(4,4,3,2,'Feedback link',NULL,10,3,2,'Hi [#FirstName] ,\n\nPlease click on the below link to send your review\n\n[#ReviewLink]\n\n[#Signature]\n',1,NULL,'2020-12-02 19:26:34',NULL,1,NULL,1),(5,5,3,2,'COVID Questionnaire',NULL,15,3,1,'Hi [#FirstName], Request you to fill COVID Questionnaire using the link https://patientviewer.com/WebFormsGWT/GWT/WebForms/WebForms.html?DOID=31638&WSDID=53984\n\n',1,NULL,'2021-01-24 06:34:00',NULL,1,NULL,1),(6,6,1,2,'Appointment Confirmation',NULL,NULL,NULL,NULL,'[#FirstName] , please reply Y to confirm your appt on [#ApptDatetime] or call [#ClinicContact]. [#Dependants] [#ClinicName]. Reply STOP to opt out of All txt msg\n',1,NULL,'2021-04-24 05:43:45',NULL,1,NULL,1),(7,7,3,1,'COVID Questionnaire',NULL,30,3,1,'<p>Hi [#FirstName] , </p><p><br></p><p>Please click on the below link to send your review </p><p>[#ReviewLink]</p><p><br></p><p><br></p><p> [#Signature]</p>',1,NULL,'2021-04-24 06:13:06',NULL,1,NULL,1);
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:48
