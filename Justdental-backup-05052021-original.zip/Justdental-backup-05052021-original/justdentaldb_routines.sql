-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vw_templatewithevent`
--

DROP TABLE IF EXISTS `vw_templatewithevent`;
/*!50001 DROP VIEW IF EXISTS `vw_templatewithevent`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_templatewithevent` AS SELECT 
 1 AS `trigger_event_id`,
 1 AS `event_id`,
 1 AS `category_id`,
 1 AS `subcategory_id`,
 1 AS `template_id`,
 1 AS `clinic_id`,
 1 AS `templatetypename_id`,
 1 AS `template_type_name`,
 1 AS `subject`,
 1 AS `bodycontent`,
 1 AS `event_name`,
 1 AS `category_name`,
 1 AS `subcategory_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_templatewithevent`
--

/*!50001 DROP VIEW IF EXISTS `vw_templatewithevent`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_templatewithevent` AS select `te`.`id` AS `trigger_event_id`,`te`.`event_id` AS `event_id`,`te`.`category_id` AS `category_id`,`te`.`subcategory_id` AS `subcategory_id`,`te`.`template_id` AS `template_id`,`template`.`clinic_id` AS `clinic_id`,`template`.`templatetypename_id` AS `templatetypename_id`,`typename`.`name` AS `template_type_name`,`template`.`subject` AS `subject`,`template`.`bodycontent` AS `bodycontent`,`evnt`.`name` AS `event_name`,`tc`.`name` AS `category_name`,`tsc`.`name` AS `subcategory_name` from (((((`trigger_event` `te` left join `templates` `template` on((`template`.`id` = `te`.`template_id`))) left join `event` `evnt` on((`evnt`.`id` = `te`.`event_id`))) left join `templatetypename` `typename` on((`typename`.`id` = `template`.`templatetypename_id`))) left join `templatecategory` `tc` on(((`tc`.`id` = `evnt`.`category_id`) and (`tc`.`id` = `te`.`category_id`)))) left join `templatesubcategory` `tsc` on((`tsc`.`id` = `te`.`subcategory_id`))) where ((`te`.`active` = 1) and (`evnt`.`active` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'justdentaldb'
--
/*!50003 DROP FUNCTION IF EXISTS `func_get_clinic_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `func_get_clinic_id`(__guid varchar(100)) RETURNS int(11)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select clinic_id into __clinic_id from user_login_status where guid = __guid and active = 1;
    END IF;
    RETURN __clinic_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `workdays` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `workdays`(first_date DATE, second_date DATE) RETURNS int(11)
    DETERMINISTIC
BEGIN

RETURN (DATEDIFF(second_date, first_date)) + 1
     - (DATEDIFF(ADDDATE(second_date, INTERVAL 1 - DAYOFWEEK(second_date) DAY),
                    ADDDATE(first_date, INTERVAL 1 - DAYOFWEEK(first_date) DAY))) / 7 * 2
     - (DAYOFWEEK(IF(first_date < second_date, first_date, second_date)) = 1)
     - (DAYOFWEEK(IF(first_date > second_date, first_date, second_date)) = 7);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addHistCampaignStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addHistCampaignStatus`(
		IN __guid varchar(100)
		,IN  __campaign_schedule_id INT
		,IN  __appointment_id INT
		,IN  __category_id INT
		,IN  __subcategory_id INT
		,IN  __template_id INT
		,IN  __patient_id INT
		,IN  __email_to varchar(250)
		,IN  __email_cc varchar(250)
		,IN  __text_to varchar(10)
		,IN  __message_status bit
		,IN  __message_error varchar(2500)
		,IN  __createdon varchar(30)
		,IN  __createdby INT    
        ,IN __appointment_datetime varchar(30)
        ,OUT __result varchar(100)
)
BEGIN
	DECLARE __tempAppointment_id INT DEFAULT 0;
    DECLARE __tempPatient_id INT DEFAULT 0;
    DECLARE __tempCampaign_sent_status_count INT DEFAULT 0;
    
    DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

		insert into histemailsent (
				clinic_id
				,campaign_schedule_id
				,appointment_id
				,category_id
				,subcategory_id
				,template_id
				,patient_id
				,email_to
				,email_cc
				,text_to
				,message_status
				,message_error
				,createdon
				,createdby
				,appointment_datetime
			) values (
				__clinic_id
				,__campaign_schedule_id
				,__appointment_id
				,__category_id
				,__subcategory_id
				,__template_id
				,__patient_id
				,__email_to
				,__email_cc
				,__text_to
				,__message_status
				,__message_error
				,__createdon
				,__createdby
				,__appointment_datetime
			);
            
	if(__category_id = 3 ) then
		select count(*) into __tempCampaign_sent_status_count from campaign_sent_status where appointment_id = __appointment_id and patient_id = __patient_id
			and category_id = __category_id and subcategory_id = __subcategory_id;
		if(__tempCampaign_sent_status_count = 0) then
			insert into campaign_sent_status (
								clinic_id
                                ,appointment_id
                                ,category_id
                                ,subcategory_id
                                ,template_id
                                ,patient_id
                                ,email_to
                                ,email_cc
                                ,text_to
                                ,message_status
                                ,message_error
                                ,createdon
                                ,createdby
                            ) values (
								__clinic_id
                                ,__appointment_id
                                ,__category_id
                                ,__subcategory_id
                                ,__template_id
                                ,__patient_id
                                ,__email_to
                                ,__email_cc
                                ,__text_to
                                ,__message_status
                                ,__message_error
                                ,__createdon
                                ,__createdby	
                            );                            
                            
		elseif(__tempCampaign_sent_status_count > 0) then
			update campaign_sent_status set 
								category_id = __category_id
                                ,subcategory_id = __subcategory_id
                                ,template_id = __template_id
                                ,email_to = __email_to
                                ,email_cc = __email_cc
                                ,text_to = __text_to
                                ,message_status = __message_status
                                ,updatedon = __createdon
                                ,updatedby = __createdby
							where appointment_id = __appointment_id 
								and patient_id = __patient_id
                                and category_id = __category_id
                                and subcategory_id = __subcategory_id
                                and clinic_id = __clinic_id;
		end if;
	end if;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetActiveCampaignTemplate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetActiveCampaignTemplate`(
	IN  __category_id INT,
    IN __guid varchar(100)
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

	select _template.id as template_id
                            ,_template.templatetypename_id
                            ,(_template.subject)
                            ,_template.bodycontent
                            ,_template.leadtime_number
                            ,_template.leadtime_interval
                            ,case 
                                when leadtime_interval = 1 then 'day(s)'
                                when leadtime_interval = 2 then 'hour(s)'
                            end as leadtime_interval_desc
                            ,_template.leadtime_mode
                            ,case 
                                when leadtime_mode = 1 then 'before'
                                when leadtime_mode = 2 then 'after'
                            end as leadtime_mode_desc
                            ,_template.category_id
                            ,_template.subcategory_id
                            from templates _template
                            where _template.category_id = __category_id
                                and _template.active = 1
                                and lcase(_template.subject) not like'%birthday%'
                                and _template.clinic_id = __clinic_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAppointmentsByDateRange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAppointmentsByDateRange`(
	IN __guid varchar(100),
    IN __from_date varchar(10),
    IN __to_date varchar(10),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
  
	IF(length(__from_date) > 0 ) then
    
		set @sQLStmt = CONCAT("select 
            appointment.clinic_id,
            appointment.clinic_id as ClinicNum,        
        appointment.aptnum as appointment_sr_no, 
        appointment.PatNum as patient_id, 
        patient.LName as lastName, 
        patient.MiddleI as middleName, 
        patient.FName as firstName, 
        CONCAT(patient.FName, ' ', IFNULL(CONCAT(patient.MiddleI, ' '),''), patient.LName) as patient_name,
        patient.TxtMsgOk as sendtext,
        patient.PatStatus as patStatus, 
        CASE
            WHEN patient.PatStatus = 0 then 'Patient'
            WHEN patient.PatStatus = 1 then 'NonPatient'
            WHEN patient.PatStatus = 2 then 'Inactive'
            WHEN patient.PatStatus = 3 then 'Archived'
            WHEN patient.PatStatus = 4 then 'Deleted'
            WHEN patient.PatStatus = 5 then 'Deceased'
            WHEN patient.PatStatus = 6 then 'Prospective'
        END as patientStatus, 
        CASE
            When patient.Gender = 0 then 'Male'
            When patient.Gender = 1 then 'Female'
        END as 'gender',
        patient.WirelessPhone as cell, 
        patient.Email as email, 
        DATE_FORMAT(patient.DateFirstVisit, '%m/%d/%Y') as dateFirstVisit,
        DATE_FORMAT(patient.Birthdate, '%m/%d/%Y') as patient_birth_date,
		DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 as patient_age,
        appointment.AptStatus as aptStatus,
        CASE 
            When appointment.AptStatus = 1 then 'Scheduled'
            When appointment.AptStatus = 2 then 'Complete'
            When appointment.AptStatus = 3 then 'unscheduled'
            When appointment.AptStatus = 5 then 'Broken'
            When appointment.AptStatus = 6 then 'Planned'
            When appointment.AptStatus = 7 then 'PtNote'
            When appointment.AptStatus = 8 then 'PtNote Completed'
        END as 'status',
        (length(appointment.Pattern) * 5) as appt_duration, 
        appointment.Confirmed as confirmed, 
        definition.itemname as 'aptConfirmedStatus',
        definition.itemvalue as 'aptConfirmedStatusValue',
        appointment.TimeLocked as timeLocked, 
        appointment.Op as operatory, 
        appointment.Note as note, 
        appointment.ProvNum as provNum, 
        appointment.ProvHyg as provHyg, 
        DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y %H:%i') as aptDateTime,
        DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y') as date,
        DATE_FORMAT(appointment.AptDateTime, '%H:%i') as time,
        appointment.NextAptNum as nextAptNum, 
        appointment.UnschedStatus as unschedStatus, 
        appointment.IsNewPatient as isNewPatient, 
        appointment.ProcDescript as description, 
        appointment.Assistant as assistant, 
        appointment.ClinicNum as clinicNum, 
        appointment.IsHygiene as isHygiene, 
        DATE_FORMAT(appointment.DateTStamp, '%m/%d/%Y %H:%i') as appointment_made_date,
        DATE_FORMAT(appointment.DateTimeArrived, '%m/%d/%Y %H:%i') as dateTimeArrived,
        DATE_FORMAT(appointment.DateTimeSeated, '%m/%d/%Y %H:%i') as dateTimeSeated,
        DATE_FORMAT(appointment.DateTimeDismissed, '%m/%d/%Y %H:%i') as dateTimeDismissed,
        appointment.InsPlan1 as insPlan1, 
        appointment.InsPlan2 as insPlan2, 
        DATE_FORMAT(appointment.DateTimeAskedToArrive, '%m/%d/%Y %H:%i') as dateTimeAskedToArrive,
        appointment.ProcsColored as procsColored, 
        appointment.ColorOverride as colorOverride, 
        appointment.AppointmentTypeNum as appointmentTypeNum, 
        appointment.SecUserNumEntry as secUserNumEntry, 
        /*DATE_FORMAT(appointment.SecDateTEntry, '%m/%d/%Y %H:%i') as secDateEntry,*/
        appointment.Priority as priority
        ,reminder_temp.ApptReminderSentNum as apptReminderSentNum
        ,DATE_FORMAT(reminder_temp.DateTimeSent, '%m/%d/%Y %H:%i') as dateTimeSent
        ,reminder_temp.TSPrior as tSPrior
        ,reminder_temp.IsSmsSent as isSmsSent
        ,CASE
            when reminder_temp.IsSmsSent = 1 then 'Reminder sent'
            when reminder_temp.IsSmsSent = 0 then 'Not sent'
            when reminder_temp.IsSmsSent = null then 'Yet to send'
        END as 'smsSentStatus'
        ,request_temp.ConfirmationRequestNum as confirmationRequestNum
        ,request_temp.ApptNum as apptNum
        ,request_temp.ConfirmCode as confirmCode
        ,DATE_FORMAT(request_temp.DateTimeConfirmTransmit, '%m/%d/%Y %H:%i') as confirmed_on_date
        ,request_temp.MsgTextToMobile as msgTextToMobile
        ,CASE
            when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 0 then 'Today'
            when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 1 then 'Yesterday'
            when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) > 1 and DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) <= 365 then CONCAT(DATEDIFF(now(), request_temp.DateTimeConfirmTransmit), ' d ago')
        End as daysago
        ,(select round(ifnull(sum(proclog.ProcFee), 0), 0) from ", __opendentalDB, ".jd_procedurelog proclog where proclog.AptNum = appointment.AptNum and proclog.ProcStatus = 1) as tp_amount
        ,(select _carrier.CarrierName 
			from ", __opendentalDB, ".jd_carrier _carrier 
			left join ", __opendentalDB, ".jd_insplan _insplan on _insplan.CarrierNum = _carrier.CarrierNum
			left join ", __opendentalDB, ".jd_appointment _appointment on _appointment.Insplan1 = _insplan.PlanNum
			where _appointment.AptNum = appointment.AptNum) as insurance_name,
		(select _procedurecode.isHygiene 
			from ", __opendentalDB, ".jd_procedurecode _procedurecode 
			left join ", __opendentalDB, ".jd_procedurelog _procedurelog on _procedurelog.CodeNum = _procedurecode.CodeNum
			where _procedurecode.isHygiene = 1 and _procedurelog.AptNum = appointment.AptNum limit 1) as isHygiene
        from ", __opendentalDB, ".jd_appointment appointment
        join ", __opendentalDB, ".jd_definition definition on definition.defnum = appointment.Confirmed AND definition.clinic_id = ", __clinic_id, "
        join ", __opendentalDB, ".jd_patient patient on patient.PatNum = appointment.PatNum and patient.clinic_id = ", __clinic_id, "
        left join (select reminder1.* from ", __opendentalDB, ".jd_apptremindersent reminder1 
                left join ", __opendentalDB, ".jd_apptremindersent reminder2
                on reminder1.ApptNum = reminder2.ApptNum
                    and reminder1.DateTimeSent < reminder2.DateTimeSent 
                where reminder2.ApptNum IS NULL
                and reminder1.clinic_id = ", __clinic_id, "
                ) as reminder_temp
                ON reminder_temp.ApptNum = appointment.AptNum
        left join (
                select request1.* 
                from ", __opendentalDB, ".jd_confirmationrequest request1
                left join ", __opendentalDB, ".jd_confirmationrequest request2
                on request1.ApptNum = request2.ApptNum
                and request1.DateTimeEntry < request2.DateTimeEntry
                where request2.ApptNum is NULL
                and request1.clinic_id = ", __clinic_id, "
                ) as request_temp
                ON request_temp.ApptNum = appointment.AptNum
        where DATE(appointment.AptDateTime) between DATE('", __from_date ,"') and DATE('", __to_date ,"')
        and appointment.clinic_id = ", __clinic_id, "
        order by appointment.AptDateTime");
        
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt;        

	ELSE
		SET temp_status_id = 0;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertlogger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertlogger`(
    IN  __clinicId INT
	,IN  __logtimestamp varchar(30)
    ,IN  __loglevel varchar(20)
    ,IN  __logmessage text
    ,IN  __createdon varchar(30)
    ,IN  __createdby INT   
)
BEGIN
	insert into logger (
		clinicid
		,logtimestamp
		,loglevel
		,logmessage
		,createdon
		,createdby
    ) values (
		__clinicId
		,__logtimestamp
		,__loglevel
		,__logmessage
		,__createdon
		,__createdby
    );
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `jdsp_get_clinic_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `jdsp_get_clinic_id`(
	IN __guid varchar(100)
)
BEGIN
    DECLARE __clinic_id INT DEFAULT 0;
    SET __clinic_id = func_get_clinic_id(__guid);
    select __clinic_id as clinic_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `jdsp_set_historyappointment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `jdsp_set_historyappointment`(
	
	IN __userId INT(010), 
	IN __aptTimestamp varchar(30), 
    IN __HistApptAction INT   , 
    IN __ApptSource INT, 
	IN __AptNum INT, 
    IN __PatNum INT, 
    IN __AptStatus INT, 
    IN __Pattern  varchar(255), 
    IN __Confirmed int, 
    IN __TimeLocked int, 

    IN __operatorId int, 
    IN __Note text, 
    IN __ProvNum int, 
    IN __ProvHyg int, 
    IN __reAptDateTime  varchar(30), 
    IN __NextAptNum int, 
    IN __UnschedStatus int, 
    IN __IsNewPatient int, 
    IN __ProcDescript  varchar(255), 
    IN __Assistant int, 

    IN __ClinicNum int, 
    IN __IsHygiene int, 
    IN __DateTimeArrived  varchar(30), 
    IN __DateTimeSeated varchar(30), 
    IN __DateTimeDismissed varchar(30), 
    IN __InsPlan1 int, 
    IN __InsPlan2 int, 
    IN __DateTimeAskedToArrive varchar(30), 
    IN __ProcsColored text, 
    IN __ColorOverride int, 

    IN __AppointmentTypeNum int, 
    IN __SecUserNumEntry int, 
    IN __SecDateEntry varchar(30), 
    IN __Priority int, 
	IN __ProvBarText varchar(60), 
	IN __PatternSecondary varchar(255), 
    IN __guid varchar(100),
    IN __updatemode varchar(1)
)
BEGIN
    DECLARE __clinic_id INT DEFAULT 0;
	DECLARE __NextHistAptNum INT DEFAULT 1;
	DECLARE __result_id INT DEFAULT 0;

    SET __clinic_id = func_get_clinic_id(__guid);
	select ifnull(max(HistApptNum),0) into __NextHistAptNum from jd_histappointment where clinic_id = __clinic_id;
    
	IF length(AptNum)  > 0 THEN

		insert into jd_histappointment (
				HistUserNum
				,HistDateTStamp
				,HistApptAction
				,ApptSource
				,AptNum
				,PatNum
				,AptStatus
				,Pattern
				,Confirmed
				,TimeLocked

				,Op
				,Note
				,ProvNum
				,ProvHyg
				,AptDateTime
				,NextAptNum
				,UnschedStatus
				,IsNewPatient
				,ProcDescript
				,Assistant

				,ClinicNum
				,IsHygiene
				,DateTStamp
				,DateTimeArrived
				,DateTimeSeated
				,DateTimeDismissed
				,InsPlan1
				,InsPlan2
				,DateTimeAskedToArrive
				,ProcsColored

				,ColorOverride
				,AppointmentTypeNum
				,SecUserNumEntry
				,SecDateTEntry
				,Priority
				,ProvBarText
				,PatternSecondary
				,clinic_id
				,update_mode
				,updatedon
				,HistApptNum
			) values (
				__HistUserNum
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__HistApptAction
				,__ApptSource
				,__AptNum
				,__PatNum
				,__AptStatus
				,__Pattern
				,__Confirmed
				,__TimeLocked

				,__Op
				,__Note
				,__ProvNum
				,__ProvHyg
				,STR_TO_DATE(__reAptDateTime, '%c/%e/%Y %H:%i')
				,__NextAptNum
				,__UnschedStatus
				,__IsNewPatient
				,__ProcDescript
				,__Assistant

				,__clinic_id
				,__IsHygiene
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__DateTimeArrived
				,__DateTimeSeated
				,__DateTimeDismissed
				,__InsPlan1
				,__InsPlan2
				,__DateTimeAskedToArrive
				,__ProcsColored

				,__ColorOverride
				,__AppointmentTypeNum
				,__SecUserNumEntry
				,__SecDateTEntry
				,__Priority
				,__ProvBarText
				,__PatternSecondary
				,__clinic_id
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__updatedon
				,__NextHistAptNum
			);
			SET __result_id = LAST_INSERT_ID();
	END IF;
	select __result_id as resultId, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `jdsp_update_schedler_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `jdsp_update_schedler_status`(
	IN __guid varchar(100),
    IN __id INT,	
    IN __scheduler_id INT,
    IN __last_job_run DATETIME,
    IN __next_job_frequency INT,
    IN __created_by INT
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
	DECLARE __clinic_id INT DEFAULT 0;
    
	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(__scheduler_id > 0) then
		Select count(*) into temp_status_id from scheduler_status where scheduler_id = __scheduler_id and clinic_id = __clinic_id;
        IF(temp_status_id > 0) THEN
			update scheduler_status set 
			last_job_run = __last_job_run,
            next_job_frequency = __next_job_frequency,
            updated_by = __created_by,
            updatedon = __last_job_run
            where scheduler_id = __scheduler_id
				and clinic_id = __clinic_id;
            SET temp_status_id = __id;
		ELSE
			insert into scheduler_status (scheduler_id, last_job_run, next_job_frequency, created_by, createdon, clinic_id) 
            values (__scheduler_id, __last_job_run, __next_job_frequency, __created_by, __last_job_run, __clinic_id);
            SET temp_status_id = LAST_INSERT_ID();
        END IF;
	ELSE
		SET temp_status_id = 0;
    END IF;
    select temp_status_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `jdsp_update_template` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `jdsp_update_template`(
	IN __guid varchar(100),
	IN __category_id INT,			
	IN __subcategory_id INT,
	IN __categorymapping_id INT,
	IN __template_type_id INT,
    IN __template_type_name varchar(500),
    IN __template_id INT,
    IN __template_subject VARCHAR(500),
    IN __template_body MEDIUMTEXT,
    IN __template_trigger_id VARCHAR(500), -- comma seperated
    IN __updatedby    INT,
	IN __updatedon DATETIME,
    IN __leadtime_number INT,
    IN __leadtime_interval INT,
    IN __leadtime_mode INT,
	OUT __result varchar(100)
)
BEGIN
	DECLARE typeCount INT DEFAULT 0;
	DECLARE temp_template_type_id INT DEFAULT 0;
    DECLARE tempEventId INT  DEFAULT 0;
    DECLARE strIDs varchar(100);
    DECLARE strLen    INT DEFAULT 0;
	DECLARE SubStrLen INT DEFAULT 0;
    -- DECLARE result varchar(1000);
	
	DECLARE __clinic_id INT DEFAULT 0;
    SET __clinic_id = func_get_clinic_id(__guid);
    
    -- insert or udpate templatetypename data
    if (__template_type_id > 0) then
		update templatetypename set name = __template_type_name, updatedon = __updatedon, updatedby = __updatedby where id = __template_type_id;
        SET temp_template_type_id = __template_type_id;
        set __result = 'updated';
	else
		insert into templatetypename (categorymapping_id, name, createdby, clinic_id) 
        values (__categorymapping_id, __template_type_name, __updatedby, __clinic_id);
        SET temp_template_type_id = LAST_INSERT_ID();
        set __result = 'inserted';
    end if;
    
    if(temp_template_type_id > 0 and __template_id > 0) then
		update templates set 
                                subject = __template_subject,
                                bodycontent = __template_body,
                                category_id = __category_id,
                                subcategory_id = __subcategory_id,
                                leadtime_number = __leadtime_number,
                                leadtime_interval = __leadtime_interval,
                                leadtime_mode = __leadtime_mode,
                                updatedon = __updatedon,
                                updatedby = __updatedby
                                where id = __template_id;
		update trigger_event set active = 0 where template_id = __template_id;
	elseif(temp_template_type_id > 0 and __template_id <= 0) then
		insert into templates (templatetypename_id, subject, bodycontent, createdby,
        category_id, subcategory_id, leadtime_number, leadtime_interval, leadtime_mode, clinic_id) 
			values (temp_template_type_id, __template_subject, __template_body, __updatedby, 
            __category_id, __subcategory_id, __leadtime_number, __leadtime_interval, __leadtime_mode, __clinic_id);
        set __template_id = LAST_INSERT_ID();
    end if;
    
    -- assign template_trigger_id to strIDs
	IF __template_trigger_id IS NULL or __template_trigger_id = '' THEN
		SET strIDs = '';
	else
		SET strIDs = __template_trigger_id;
	END IF;    
    
    -- update or insert trigger event data with respect to template
    if(__template_id > 0 and __template_trigger_id != '') then
		-- set result = strIDs;
        -- set result = 'aa';
        
		do_this:
		  LOOP
          SET typeCount = 0;
			SET strLen = CHAR_LENGTH(strIDs);
            set tempEventId  = SUBSTRING_INDEX(strIDs, ',', 1);
			select count(distinct concat(template_id, event_id)) into typeCount from trigger_event where template_id = __template_id and event_id = tempEventId and clinic_id = __clinic_id;
            -- set result = CONCAT(result, ',', template_id, ',', tempEventId, ',', typeCount); -- , ',', SUBSTRING_INDEX(strIDs, ',', 1), ',', template_id);
            
            if(typeCount > 0) then
				UPDATE trigger_event SET active = 1 WHERE template_id = __template_id and event_id =  tempEventId;
				-- set result = CONCAT(result, ',', SUBSTRING_INDEX(strIDs, ',', 1), ',', template_id);
            else
			 	insert into trigger_event (template_id, event_id, category_id, subcategory_id, created_by, clinic_id)
                 values (__template_id, SUBSTRING_INDEX(strIDs, ',', 1), __category_id, __subcategory_id, __updatedby, __clinic_id);
            end if;

			SET SubStrLen = CHAR_LENGTH(SUBSTRING_INDEX(strIDs, ',', 1)) + 2;
			SET strIDs = MID(strIDs, SubStrLen, strLen);

			IF strIDs = '' THEN
			  LEAVE do_this;
			END IF;
		END LOOP do_this;
    end if;
    commit;
    select __result, temp_template_type_id as tempTypeId, __template_id as template_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `patientAppointmentById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `patientAppointmentById`(
	IN __guid varchar(100),
	IN  __patient_id INT,
    IN  __appointment_id INT,
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    set @sQLStmt = CONCAT("select 
		pat.PatNum as patient_id 
		,pat.FName as firstName 
		,pat.LName as lastName 
		,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name 
		,pat.PatStatus as patstatus 
		,pat.Gender as gender 
		,pat.Position as position
		,pat.Birthdate as dob 
		,pat.Address as address 
		,pat.Address2 as address2 
		,pat.City as city 
		,pat.State as state 
		,pat.wirelessphone as patient_cell 
		,CASE
			WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 < 19 OR pat.WirelessPhone = ''  THEN 
			(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = pat.Guarantor)
			WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 >= 19 THEN pat.WirelessPhone 
		END as cell    
		,pat.HmPhone as homephone
		,pat.WkPhone as workphone
		,pat.Email as patient_email 
		,CASE
			WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 < 19 OR pat.Email = ''  THEN 
			(select p1.Email from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = pat.Guarantor)
			WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 >= 19 THEN pat.Email
		END as email
		,pat.TxtMsgOk as sendtext 
		,pat.DateFirstVisit as firstvisit ,pat.Zip as zip 
		,_appointment.AptNum as appointment_id 
		,_appointment.AptStatus as appointment_status 
		,DATE_FORMAT(_appointment.AptDateTime, '%m/%d/%Y %h:%i %p') as apptdatetime 
		,ImageFolder as imagefolder 
		from ", __opendentalDB, ".jd_patient pat 
		left join ", __opendentalDB, ".jd_appointment _appointment on pat.PatNum = _appointment.PatNum and _appointment.clinic_id = ", __clinic_id, "
		where pat.PatNum = ", __patient_id, " 
        and pat.clinic_id = ", __clinic_id, " 
        and _appointment.AptNum = ", __appointment_id);
		
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_active_signature` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_active_signature`(
	IN __id INT
)
BEGIN
	IF __id = 0 THEN
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
			,(select group_concat(tsml.id) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_ids
            ,(select group_concat(tsml.type) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_types
            ,(select group_concat(tsml.address) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_addresses
		from template_signature td
        where td.active = 1 limit 1;
	ELSE
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
			,(select group_concat(tsml.id) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_ids
            ,(select group_concat(tsml.type) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_types
            ,(select group_concat(tsml.address) from template_signature_media_links tsml where tsml.signature_id = td.id) as media_addresses
		from template_signature td
        WHERE td.id = __id limit 1;
   
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_addConfirmationrequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_addConfirmationrequest`(
	IN __guid varchar(100),
    IN __update_mode varchar(1),
    IN __updatedon varchar(30),
    IN __ClinicNum INT,
    IN __IsForEmail INT,
    IN __IsForSMS INT,
    IN __PatNum INT,
    IN __ApptNum INT,
    IN __PhonePat varchar(255),
    IN __ShortGUID varchar(255),
    IN __MsgTextToMobile text,
    IN __DateTimeEntry varchar(30),
    IN __GuidMessageToMobile text,
    IN __AptDateTimeOrig varchar(30),
    IN __SmsSentOk INT,
    IN __EmailSentOk INT,
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE __ConfirmationRequestNum INT;
    DECLARE __result_id INT default 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
	
    select ifnull(max(ConfirmationRequestNum), 0) into __ConfirmationRequestNum from jd_confirmationrequest where clinic_id = __clinic_id;
	
    IF __ConfirmationRequestNum = 0 THEN
		SET __ConfirmationRequestNum = 1;
	ELSE
		SET __ConfirmationRequestNum = __ConfirmationRequestNum + 1;
    END IF;

	IF(__PatNum > 0 ) then
    
		
			Insert into jd_confirmationrequest (
				clinic_id,
                update_mode,
                updatedon,
                ConfirmationRequestNum,
				ClinicNum,
				IsForEmail,
				IsForSms,
				PatNum,
				ApptNum,
				PhonePat,
                
				ShortGUID,
				MsgTextToMobile,
				DateTimeEntry,
				GuidMessageToMobile,
				AptDateTimeOrig,
				SmsSentOk,
                SecondsFromEntryToExpire,
				ConfirmCode,
				MsgTextToMobileTemplate,
				EmailSubjTemplate,
                
				EmailSubj,
				EmailTextTemplate,
				EmailText,
				RSVPStatus,
				ResponseDescript,
				GuidMessageFromMobile,
				ShortGuidEmail,
				TSPrior,
				DoNotResend,
				EmailSentOk,
                
                ApptReminderRuleNum

			) values (
            __clinic_id, 
            __update_mode, 
            __updatedon, 
            __ConfirmationRequestNum, 
            __clinic_id, 
            __IsForEmail, 
            __IsForSMS,
            __PatNum,
            __ApptNum,
            __PhonePat,
            
            __ShortGUID,
            __MsgTextToMobile,
            __DateTimeEntry,
            __GuidMessageToMobile,
            __AptDateTimeOrig,
            __SmsSentOk,
             0
            ,''
            ,''
            ,''
            
            ,''
            ,''
            ,''
            ,0
            ,''
            ,''
            ,''
            ,0
            ,0
            ,__EmailSentOk
            
            , 0);
		SET __result_id = LAST_INSERT_ID();
        select __result_id as resultId, 'success' as response;
	ELSE
		select __result_id as resultId, 'missing patient id' as response;
		SET temp_status_id = 0;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_add_app_reminder_sent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_add_app_reminder_sent`(
	IN __guid varchar(100),
    IN __update_mode varchar(1),
    IN __updatedon varchar(30),
    IN __apptNum INT,
    IN __apptDateTime varchar(30),
    IN __tsPrior INT,
    IN __apptReminderRuleNum INT,
    IN __IsSmsSent int,
    IN __IsEmailSent int
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;
	DECLARE __ApptReminderSentNum INT DEFAULT 0;
    DECLARE __result_id INT DEFAULT 0;
    
	SET __clinic_id = func_get_clinic_id(__guid);
	
    select ifnull(max(ApptReminderSentNum), 0) into __ApptReminderSentNum from jd_apptremindersent where ApptNum = __apptNum and clinic_id = __clinic_id;
    IF __ApptReminderSentNum = 0 THEN
		SET __ApptReminderSentNum = 1;
	ELSE
		SET __ApptReminderSentNum = __ApptReminderSentNum + 1;
    END IF;
    
    IF __apptNum > 0 THEN
		Insert into jd_apptremindersent 
		(ApptNum, ApptDateTime, DateTimeSent, TSPrior, ApptReminderRuleNum, ApptReminderSentNum, IsSmsSent, IsEmailSent,
		clinic_id, update_mode, updatedon) 
        values 
        (
			__apptNum
            ,__apptDateTime
            ,__updatedon
            ,__tsPrior
            ,__apptReminderRuleNum
            ,__ApptReminderSentNum
            ,__IsSmsSent
            ,__IsEmailSent
            ,__clinic_id
            ,__update_mode
            ,__updatedon
        ) ;
        SET __result_id = LAST_INSERT_ID();
    END IF;
	select __result_id as resultId, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_appointmentDataByDateQuery` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_appointmentDataByDateQuery`(
	IN __guid varchar(100),
    IN __apptdate varchar(30),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
   
	IF(length(__apptdate) >= 0 ) then
    
		set @sQLStmt = CONCAT("
			select 
            appointment.clinic_id,
            appointment.clinic_id as ClinicNum,            
			appointment.aptnum as appointment_sr_no, 
			appointment.PatNum as patient_id, 
			patient.LName as lastName, 
			patient.MiddleI as middleName, 
			patient.FName as firstName, 
			CONCAT(patient.FName, ' ', IFNULL(CONCAT(patient.MiddleI, ' '),''), patient.LName) as patient_name,
			patient.TxtMsgOk as sendtext,
			patient.PatStatus as patStatus, 
			CASE
				WHEN patient.PatStatus = 0 then 'Patient'
				WHEN patient.PatStatus = 1 then 'NonPatient'
				WHEN patient.PatStatus = 2 then 'Inactive'
				WHEN patient.PatStatus = 3 then 'Archived'
				WHEN patient.PatStatus = 4 then 'Deleted'
				WHEN patient.PatStatus = 5 then 'Deceased'
				WHEN patient.PatStatus = 6 then 'Prospective'
			END as patientStatus, 
			CASE
				When patient.Gender = 0 then 'Male'
				When patient.Gender = 1 then 'Female'
			END as 'gender',
			patient.WirelessPhone as cellnumber,
			CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.WirelessPhone = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.WirelessPhone 
			END as cell,
			patient.Email as email, 
			DATE_FORMAT(patient.DateFirstVisit, '%m/%d/%Y') as dateFirstVisit,
			patient.ImageFolder as imageFolder,
			appointment.AptStatus as aptStatus,
			CASE 
				When appointment.AptStatus = 1 then 'Scheduled'
				When appointment.AptStatus = 2 then 'Complete'
				When appointment.AptStatus = 3 then 'unscheduled'
				When appointment.AptStatus = 5 then 'Broken'
				When appointment.AptStatus = 6 then 'Planned'
				When appointment.AptStatus = 7 then 'PtNote'
				When appointment.AptStatus = 8 then 'PtNote Completed'
			END as 'status',
			appointment.Pattern as pattern, 
			appointment.Confirmed as confirmed, 
			definition.itemname as 'aptConfirmedStatus',
			definition.itemvalue as 'aptConfirmedStatusValue',
			appointment.TimeLocked as timeLocked, 
			appointment.Op as operatory, 
			appointment.Note as note, 
			appointment.ProvNum as provNum, 
			appointment.ProvHyg as provHyg, 
			DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y %H:%i') as aptDateTime,
			DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y') as date,
			DATE_FORMAT(appointment.AptDateTime, '%H:%i') as time,
			appointment.NextAptNum as nextAptNum, 
			appointment.UnschedStatus as unschedStatus, 
			appointment.IsNewPatient as isNewPatient, 
			appointment.ProcDescript as description, 
			appointment.Assistant as assistant, 
			appointment.ClinicNum as clinicNum, 
			appointment.IsHygiene as isHygiene, 
			DATE_FORMAT(appointment.DateTStamp, '%m/%d/%Y %H:%i') as appointment_made_date,
			DATE_FORMAT(appointment.DateTimeArrived, '%m/%d/%Y %H:%i') as dateTimeArrived,
			DATE_FORMAT(appointment.DateTimeSeated, '%m/%d/%Y %H:%i') as dateTimeSeated,
			DATE_FORMAT(appointment.DateTimeDismissed, '%m/%d/%Y %H:%i') as dateTimeDismissed,
			appointment.InsPlan1 as insPlan1, 
			appointment.InsPlan2 as insPlan2, 
			DATE_FORMAT(appointment.DateTimeAskedToArrive, '%m/%d/%Y %H:%i') as dateTimeAskedToArrive,
			appointment.ProcsColored as procsColored, 
			appointment.ColorOverride as colorOverride, 
			appointment.AppointmentTypeNum as appointmentTypeNum, 
			appointment.SecUserNumEntry as secUserNumEntry, 
			-- DATE_FORMAT(appointment.SecDateEntry, '%m/%d/%Y %H:%i') as secDateEntry,
			appointment.Priority as priority
			,reminder_temp.ApptReminderSentNum as apptReminderSentNum
			,DATE_FORMAT(reminder_temp.DateTimeSent, '%m/%d/%Y %H:%i') as dateTimeSent
			,reminder_temp.TSPrior as tSPrior
			,reminder_temp.IsSmsSent as isSmsSent
			,CASE
				when reminder_temp.IsSmsSent = 1 then 'Reminder sent'
				when reminder_temp.IsSmsSent = 0 then 'Not sent'
				when reminder_temp.IsSmsSent = null then 'Yet to send'
			END as 'smsSentStatus'
			,request_temp.ConfirmationRequestNum as confirmationRequestNum
			,request_temp.ApptNum as apptNum
			,request_temp.ConfirmCode as confirmCode
			,DATE_FORMAT(request_temp.DateTimeConfirmTransmit, '%m/%d/%Y %H:%i') as confirmed_on_date
			,request_temp.MsgTextToMobile as msgTextToMobile
			,CASE
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 0 then 'Today'
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 1 then 'Yesterday'
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) > 1 and DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) <= 365 then CONCAT(DATEDIFF(now(), request_temp.DateTimeConfirmTransmit), ' d ago')
			End as daysago
			from ", __opendentalDB, ".jd_appointment appointment
			join ", __opendentalDB, ".jd_definition definition on definition.defnum = appointment.Confirmed AND definition.clinic_id = ", __clinic_id, "
			join ", __opendentalDB, ".jd_patient patient on patient.PatNum = appointment.PatNum and patient.clinic_id = ", __clinic_id, "
			left join (select reminder1.* from ", __opendentalDB, ".jd_apptremindersent reminder1 
					left join ", __opendentalDB, ".jd_apptremindersent reminder2 
					on reminder1.ApptNum = reminder2.ApptNum
						and reminder2.clinic_id = ", __clinic_id, "
						and reminder1.DateTimeSent < reminder2.DateTimeSent 
					where reminder2.ApptNum IS NULL
						and reminder1.clinic_id = ", __clinic_id, "
                    ) as reminder_temp
					ON reminder_temp.ApptNum = appointment.AptNum
			left join (
					select request1.* 
					from ", __opendentalDB, ".jd_confirmationrequest request1
					left join ", __opendentalDB, ".jd_confirmationrequest request2  
					on request1.ApptNum = request2.ApptNum
                    and request2.clinic_id = ", __clinic_id, "
					and request1.DateTimeEntry < request2.DateTimeEntry
					where request2.ApptNum is NULL
                    and request1.clinic_id = ", __clinic_id, "
                    ) as request_temp
					ON request_temp.ApptNum = appointment.AptNum
            where DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y') = '", __apptdate, "'
            and appointment.clinic_id = ", __clinic_id, "
			order by appointment.AptDateTime        
        ");
        
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt;        

	ELSE
		SET temp_status_id = 0;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_appointmentDataQuery` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_appointmentDataQuery`(
	IN __guid varchar(100),
    IN __daysAhead INT,
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);    
   
	IF(length(__daysAhead) >= 0 ) then
    
		set @sQLStmt = CONCAT("
			select 
            appointment.clinic_id,
            appointment.clinic_id as ClinicNum,
			appointment.aptnum as appointment_sr_no, 
			appointment.PatNum as patient_id, 
			patient.LName as lastName, 
			patient.MiddleI as middleName, 
			patient.FName as firstName, 
			CONCAT(patient.FName, ' ', IFNULL(CONCAT(patient.MiddleI, ' '),''), patient.LName) as patient_name,
			patient.TxtMsgOk as sendtext,
			patient.PatStatus as patStatus, 
			CASE
				WHEN patient.PatStatus = 0 then 'Patient'
				WHEN patient.PatStatus = 1 then 'NonPatient'
				WHEN patient.PatStatus = 2 then 'Inactive'
				WHEN patient.PatStatus = 3 then 'Archived'
				WHEN patient.PatStatus = 4 then 'Deleted'
				WHEN patient.PatStatus = 5 then 'Deceased'
				WHEN patient.PatStatus = 6 then 'Prospective'
			END as patientStatus, 
			CASE
				When patient.Gender = 0 then 'Male'
				When patient.Gender = 1 then 'Female'
			END as 'gender',
			patient.WirelessPhone as cellnumber,
			CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.WirelessPhone = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.WirelessPhone 
			END as cell,
			patient.Email as email, 
			DATE_FORMAT(patient.DateFirstVisit, '%m/%d/%Y') as dateFirstVisit,
			patient.ImageFolder as imageFolder,
			appointment.AptStatus as aptStatus,
			CASE 
				When appointment.AptStatus = 1 then 'Scheduled'
				When appointment.AptStatus = 2 then 'Complete'
				When appointment.AptStatus = 3 then 'unscheduled'
				When appointment.AptStatus = 5 then 'Broken'
				When appointment.AptStatus = 6 then 'Planned'
				When appointment.AptStatus = 7 then 'PtNote'
				When appointment.AptStatus = 8 then 'PtNote Completed'
			END as 'status',
			appointment.Pattern as pattern, 
			appointment.Confirmed as confirmed, 
			definition.itemname as 'aptConfirmedStatus',
			definition.itemvalue as 'aptConfirmedStatusValue',
			appointment.TimeLocked as timeLocked, 
			appointment.Op as operatory, 
			appointment.Note as note, 
			appointment.ProvNum as provNum, 
			appointment.ProvHyg as provHyg, 
			DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y %H:%i') as aptDateTime,
			DATE_FORMAT(appointment.AptDateTime, '%m/%d/%Y') as date,
			DATE_FORMAT(appointment.AptDateTime, '%H:%i') as time,
			appointment.NextAptNum as nextAptNum, 
			appointment.UnschedStatus as unschedStatus, 
			appointment.IsNewPatient as isNewPatient, 
			appointment.ProcDescript as description, 
			appointment.Assistant as assistant, 
			appointment.ClinicNum as clinicNum, 
			appointment.IsHygiene as isHygiene, 
			DATE_FORMAT(appointment.DateTStamp, '%m/%d/%Y %H:%i') as appointment_made_date,
			DATE_FORMAT(appointment.DateTimeArrived, '%m/%d/%Y %H:%i') as dateTimeArrived,
			DATE_FORMAT(appointment.DateTimeSeated, '%m/%d/%Y %H:%i') as dateTimeSeated,
			DATE_FORMAT(appointment.DateTimeDismissed, '%m/%d/%Y %H:%i') as dateTimeDismissed,
			appointment.InsPlan1 as insPlan1, 
			appointment.InsPlan2 as insPlan2, 
			DATE_FORMAT(appointment.DateTimeAskedToArrive, '%m/%d/%Y %H:%i') as dateTimeAskedToArrive,
			appointment.ProcsColored as procsColored, 
			appointment.ColorOverride as colorOverride, 
			appointment.AppointmentTypeNum as appointmentTypeNum, 
			appointment.SecUserNumEntry as secUserNumEntry, 
			-- DATE_FORMAT(appointment.SecDateEntry, '%m/%d/%Y %H:%i') as secDateEntry,
			appointment.Priority as priority
			,reminder_temp.ApptReminderSentNum as apptReminderSentNum
			,DATE_FORMAT(reminder_temp.DateTimeSent, '%m/%d/%Y %H:%i') as dateTimeSent
			,reminder_temp.TSPrior as tSPrior
			,reminder_temp.IsSmsSent as isSmsSent
			,CASE
				when reminder_temp.IsSmsSent = 1 then 'Reminder sent'
				when reminder_temp.IsSmsSent = 0 then 'Not sent'
				when reminder_temp.IsSmsSent = null then 'Yet to send'
			END as 'smsSentStatus'
			,request_temp.ConfirmationRequestNum as confirmationRequestNum
			,request_temp.ApptNum as apptNum
			,request_temp.ConfirmCode as confirmCode
			,DATE_FORMAT(request_temp.DateTimeConfirmTransmit, '%m/%d/%Y %H:%i') as confirmed_on_date
			,request_temp.MsgTextToMobile as msgTextToMobile
			,CASE
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 0 then 'Today'
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) = 1 then 'Yesterday'
				when DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) > 1 and DATEDIFF(now(), request_temp.DateTimeConfirmTransmit) <= 365 then CONCAT(DATEDIFF(now(), request_temp.DateTimeConfirmTransmit), ' d ago')
			End as daysago
			from ", __opendentalDB, ".jd_appointment appointment
			join ", __opendentalDB, ".jd_definition definition on definition.defnum = appointment.Confirmed AND definition.clinic_id = ", __clinic_id, "
			join ", __opendentalDB, ".jd_patient patient on patient.PatNum = appointment.PatNum and patient.clinic_id = ", __clinic_id, "
			left join (select reminder1.* from ", __opendentalDB, ".jd_apptremindersent reminder1 
					left join ", __opendentalDB, ".jd_apptremindersent reminder2
					on reminder1.ApptNum = reminder2.ApptNum
						and reminder1.DateTimeSent < reminder2.DateTimeSent 
					where reminder2.ApptNum IS NULL
                    and reminder1.clinic_id = ", __clinic_id, ") as reminder_temp
					ON reminder_temp.ApptNum = appointment.AptNum
			left join (
					select request1.* 
					from ", __opendentalDB, ".jd_confirmationrequest request1
					left join ", __opendentalDB, ".jd_confirmationrequest request2
					on request1.ApptNum = request2.ApptNum
					and request1.DateTimeEntry < request2.DateTimeEntry
					where request2.ApptNum is NULL
                    and request1.clinic_id = ", __clinic_id, ") as request_temp
					ON request_temp.ApptNum = appointment.AptNum
			where DATE(appointment.AptDateTime) >= date(date_add(now(), interval ", __daysAhead ," day))
            and appointment.clinic_id = ", __clinic_id, "
			order by appointment.AptDateTime        
        ");
        
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt;        

	ELSE
		SET temp_status_id = 0;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_appointment_details_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_appointment_details_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
        				SELECT pat.PatNum as patient_id,
						CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name,
						pat.Email as email
						,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
						,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
						,pat.Address as address
						,pat.Address2 as address2
						,pat.City as city
						,pat.State as state
						,pat.Zip as zip                        
						,pat.wirelessphone as cell
						,pat.HmPhone as homephone
						,pat.WkPhone as workphone
						,pat.TxtMsgOk as sendtext
						,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,pat.Gender as gender
						,CASE 
							WHEN pat.gender = 0 then 'Male'
							WHEN pat.gender = 1 then 'Female'
							WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'                          
                        /*,DATE_FORMAT((AA.ProcDate),'%m/%d/%Y') AS lastvisit*/
						
                    FROM
                    (SELECT distinct _appointment.PatNum from ", __opendentalDB, ".jd_appointment _appointment
                    WHERE DATE(_appointment.AptDateTime) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') and _appointment.clinic_id = ", __clinic_id, ")A
                    JOIN ", __opendentalDB, ".jd_patient pat on A.PatNum = pat.PatNum and pat.PatStatus=0  and pat.clinic_id = ", __clinic_id, "
					LEFT OUTER JOIN (
									select distinct pl.PatNum
									FROM ", __opendentalDB, ".jd_procedurelog pl
									WHERE 
										pl.ProcStatus=2 
                                        AND DATE(pl.ProcDate) < DATE('",__reportStartDate,"') 
                                        AND pl.clinic_id = ", __clinic_id, "
									) AA on AA.PatNum = A.PatNum    					
				");
				/* LEFT OUTER JOIN (
								select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate -- , pl.AptNum, 
								FROM ", __opendentalDB, ".jd_procedurelog pl
								WHERE 
									pl.ProcStatus=2 AND 
									DATE(pl.ProcDate) < DATE('",__reportStartDate,"') 
									GROUP BY pl.PatNum
									HAVING MAX(pl.ProcDate)
								) AA on AA.PatNum = A.PatNum                   */

        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SELECT 0 as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_appointment_reminder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_appointment_reminder`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
		set @sQLStmt = CONCAT("SELECT 
			patient.PatNum as patient_id
			,CONCAT(patient.FName, ' ', patient.LName) as patient_name
			,patient.FName as patient_firstName
			,patient.LName as patient_lastName
			,CONCAT(pg.FName, ' ', pg.LName) as guarantor_name
			,pg.FName as guarantor_firstName
			,pg.LName as guarantor_lastName
			,patient.Position position
			,CASE 
				WHEN patient.gender = 0 then 'Male'
				WHEN patient.gender = 1 then 'Female'
				WHEN patient.gender = 2 then 'Unknown'
			END as 'gender_text'
			,CASE 
				WHEN patient.Position = 0 then 'Single'
				WHEN patient.Position = 1 then 'Married'
				WHEN patient.Position = 2 then 'Child'
				WHEN patient.Position = 3 then 'Widowed'
				WHEN patient.Position = 4 then 'Divorced'
			END as 'position_text'
			,patient.Guarantor as guarantor
			,patient.PatStatus as patient_status
			,DATE_FORMAT(patient.Birthdate, '%m/%d/%Y') AS birth_date
			,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 AS age
			,patient.WirelessPhone as cellnumber
			,CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.WirelessPhone = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.WirelessPhone 
			END as cell
			,patient.Email as patient_email
			,CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.Email = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.Email 
			END as email
			,pg.Email as guarantor_email
			,appointment.AptNum as appointment_id
			,appointment.AptDateTime as appointment_date
			,appointment.Confirmed as appointment_confirmed
		FROM ", __opendentalDB, ".jd_patient patient
		INNER JOIN ", __opendentalDB, ".jd_patient pg ON patient.Guarantor = pg.PatNum and pg.clinic_id = ", __clinic_id, "
		INNER JOIN ", __opendentalDB, ".jd_appointment appointment ON patient.PatNum = appointment.PatNum and appointment.clinic_id = ", __clinic_id , "
		AND (aptstatus=1 or aptstatus=6)
		AND Date(aptdatetime) = DATE('",__reportStartDate,"')
        and patient.clinic_id = ", __clinic_id, "
		order by patient.Guarantor, appointment.AptDateTime");
	PREPARE Stmt FROM @sQLStmt;
	EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_completed_appointments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_completed_appointments`(
	IN __guid varchar(100),
	IN  __leadtime_interval INT,
    IN  __leadtime_mode INT,
    IN  __leadtime INT,
    IN  __category_id INT,
    IN  __subcategory_id INT,
    IN  __opendentalDB CHAR(100)
)
BEGIN
    DECLARE sQLStmt TEXT;
	DECLARE __leadTimeByMode INT DEFAULT 0;
    DECLARE __leadTimeByMode_attempt INT DEFAULT 0;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	if (__leadtime_interval = 1) then
		if (__leadtime_mode = 1) then
			set __leadTimeByMode = -__leadtime;
			set __leadTimeByMode_attempt = -(__leadtime + 1);
		elseif(__leadtime_mode = 2) then
			set __leadTimeByMode = __leadtime;
			set __leadTimeByMode_attempt = __leadtime + 1;
		end if;
        
		set @sQLStmt = CONCAT("select 
							_appointment.AptNum as apptmt_id
                            ,_appointment.PatNum as patient_id
                            ,_appointment.AptStatus
                            ,_appointment.Pattern
                            ,_appointment.Confirmed
                            ,_appointment.TimeLocked
                            ,_appointment.AptDateTime
                            ,_appointment.NextAptNum
                            ,_appointment.UnschedStatus
                            ,_appointment.IsNewPatient
                            ,_appointment.ProcDescript
                            ,_histemailsent.id as histemailsent_id
                            ,_histemailsent.appointment_id
                            ,_histemailsent.category_id
                            ,_histemailsent.subcategory_id
                            ,_histemailsent.template_id
                            ,_histemailsent.patient_id as hist_patient_id
                            ,_histemailsent.email_to
                            ,_histemailsent.email_cc
                            ,_histemailsent.text_to
                            ,_histemailsent.message_status
                            from ", __opendentalDB, ".jd_appointment _appointment
                            left join campaign_sent_status _histemailsent on _histemailsent.appointment_id = _appointment.AptNum 
								and _histemailsent.category_id = ", __category_id, " 
								and _histemailsent.subcategory_id =", __subcategory_id, "
                                and _histemailsent.clinic_id = ", __clinic_id, "
                            where (DATE(_appointment.AptDateTime) = date(date_add(now(), interval ", __leadTimeByMode, " day)) 
								or DATE(_appointment.AptDateTime) = date(date_add(now(), interval ", __leadTimeByMode_attempt, " day)))
                                and _appointment.AptStatus = 2 
                                and (_histemailsent.message_status is null or _histemailsent.message_status = 0) 
                                and _appointment.clinic_id = ", __clinic_id);
                                
--                                 and  _histemailsent.id = (
-- 									select _histemailsent2.id from histemailsent _histemailsent2
-- 									where _histemailsent2.appointment_id =  _histemailsent.appointment_id
-- 									order by _histemailsent2.id desc limit 1);   

--                             where _appointment.AptStatus = 2
-- 								and (_histemailsent.message_status is null or _histemailsent.message_status = 0)
-- 								and (DATE(_appointment.AptDateTime) = date(date_add(now(), interval -11 day)) 
-- 								  or DATE(_appointment.AptDateTime) = date(date_add(now(), interval -12 day))) ") ;
                                    
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
				
    elseif (__leadtime_interval = 2) then
		if (__leadtime_mode = 1) then
			set __leadTimeByMode = __leadtime;
			set __leadTimeByMode_attempt = (__leadtime + 1);
		elseif(__leadtime_mode = 2) then
			set __leadTimeByMode = -__leadtime;
			set __leadTimeByMode_attempt = -(__leadtime + 1);
		end if;
    
			set @sQLStmt = CONCAT("select _appointment.AptNum as apptmt_id
                            ,_appointment.PatNum as patient_id
                            ,_appointment.AptStatus
                            ,_appointment.Pattern
                            ,_appointment.Confirmed
                            ,_appointment.TimeLocked
                            ,_appointment.AptDateTime
                            ,_appointment.NextAptNum
                            ,_appointment.UnschedStatus
                            ,_appointment.IsNewPatient
                            ,_appointment.ProcDescript
                            ,_histemailsent.id as histemailsent_id
                            ,_histemailsent.appointment_id
                            ,_histemailsent.category_id
                            ,_histemailsent.subcategory_id
                            ,_histemailsent.template_id
                            ,_histemailsent.patient_id as hist_patient_id
                            ,_histemailsent.email_to
                            ,_histemailsent.email_cc
                            ,_histemailsent.text_to
                            ,_histemailsent.message_status
                            from ", __opendentalDB, ".jd_appointment _appointment
                            left join campaign_sent_status _histemailsent on _histemailsent.appointment_id = _appointment.AptNum 
								and _histemailsent.category_id = ", __category_id, " 
                                and _histemailsent.subcategory_id =", __subcategory_id, "
                                and _histemailsent.clinic_id = ", __clinic_id, "
                            where _appointment.AptStatus = 2
                            and (_histemailsent.message_status is null or _histemailsent.message_status = 0)
                            and (_appointment.AptDateTime) between (date_add(now(), interval ", __leadTimeByMode_attempt, " hour)) 
								and (date_add(now(), interval ", __leadTimeByMode, " hour)) 
                                and _appointment.clinic_id = ", __clinic_id);
                                
                                -- and  _histemailsent.id = (
								-- 	select _histemailsent2.id from histemailsent _histemailsent2
								-- 	where _histemailsent2.appointment_id =  _histemailsent.appointment_id
								-- 	order by _histemailsent2.id desc limit 1);   
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_create_user_code_verification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_create_user_code_verification`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __secretcode varchar(10),
    IN __verifystatus char(1),
    IN __createdon varchar(30)
)
BEGIN
	-- attempt
    DECLARE __attempt int;
    DECLARE __result_id INT DEFAULT 0;
    
    select attempt into __attempt from user_code_verification where user_id = __user_id and clinic_id = __paged and verifystatus = 'N' order by id desc limit 1;
    IF __attempt is null THEN
		set __attempt = 1;
	ELSE
		set __attempt = __attempt + 1;
	END IF;
    
    IF __user_id > 0 THEN
		insert into user_code_verification (clinic_id, user_id, secretcode, attempt, verifystatus, createdon)
        values (__paged, __user_id, __secretcode, __attempt, __verifystatus, __createdon);
    END IF;

    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_delete_purchaseorder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_delete_purchaseorder`(
		IN __id int(11),
        IN __guid varchar(1000),
        IN __active INT(1),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE purchaseorder_detail set active = 0 where po_id = __id;
		UPDATE purchaseorder set
			updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,active = __active
			,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	END IF;
    
    select __result_id as responseid, 'Purchase order has been deleted successfully' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_delete_usertask` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_delete_usertask`(
		IN __usertask_id INT,
		IN __guid varchar(100)
    )
BEGIN
   DECLARE __def_id INT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
   
   set @_def_id = 0;
	IF __usertask_id > 0 THEN
        update usertask set active = 0 where id = __usertask_id and clinic_id = __clinic_id;
	END IF;
	SET @__usertask_id = LAST_INSERT_ID();
	select __usertask_id as usertaskId, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_dependant_appointments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_dependant_appointments`(
	IN __guid varchar(100),
	IN __patient_id INT,
    IN __appointment_id INT,
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
   
    set @sQLStmt = CONCAT("SELECT 
			patient.PatNum as patient_id
			,CONCAT(patient.FName, ' ', patient.LName) as patient_name
			,patient.FName as patient_firstName
			,patient.LName as patient_lastName
			,CONCAT(pg.FName, ' ', pg.LName) as guarantor_name
			,pg.FName as guarantor_firstName
			,pg.LName as guarantor_lastName
			,patient.Position position
			,CASE 
				WHEN patient.gender = 0 then 'Male'
				WHEN patient.gender = 1 then 'Female'
				WHEN patient.gender = 2 then 'Unknown'
			END as 'gender_text'
			,CASE 
				WHEN patient.Position = 0 then 'Single'
				WHEN patient.Position = 1 then 'Married'
				WHEN patient.Position = 2 then 'Child'
				WHEN patient.Position = 3 then 'Widowed'
				WHEN patient.Position = 4 then 'Divorced'
			END as 'position_text'
			,patient.Guarantor as guarantor
			,patient.PatStatus as patient_status
			,DATE_FORMAT(patient.Birthdate, '%m/%d/%Y') AS birth_date
			,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 AS age
			,patient.WirelessPhone as cellnumber
			,CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.WirelessPhone = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.WirelessPhone 
			END as cell
			,patient.Email as patient_email
			,CASE
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 < 19 OR patient.Email = ''  THEN 
				(select p1.WirelessPhone from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum where p1.PatNum = patient.Guarantor)
				WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), patient.Birthdate)), '%Y')+0 >= 19 THEN patient.Email 
			END as email
			,pg.Email as guarantor_email
			,appointment.AptNum as appointment_id
			,appointment.AptDateTime as appointment_date
			,appointment.Confirmed as appointment_confirmed
		FROM ", __opendentalDB, ".jd_patient patient
		INNER JOIN ", __opendentalDB, ".jd_patient pg ON patient.Guarantor=pg.PatNum
		INNER JOIN ", __opendentalDB, ".jd_appointment appointment ON patient.PatNum=appointment.PatNum
		AND (aptstatus=1 or aptstatus=6)
		AND patient.Guarantor = (select Guarantor from ", __opendentalDB, ".jd_patient where PatNum = ", __patient_id, ")
		AND Date(appointment.AptDateTime) = (select date(appt.AptDateTime) from ", __opendentalDB, ".jd_appointment appt 
												where appt.AptNum = ", __appointment_id, " and appt.clinic_id = ", __clinic_id, ")
        AND appointment.clinic_id = ", __clinic_id, "
        where patient.clinic_id = ", __clinic_id, "
		order by patient.Guarantor, appointment.AptDateTime");
		
        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_getnotes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_getnotes`(
		IN __guid varchar(100),
        IN __patient_id INT(11),
		IN __note_start_date varchar(30),
        IN __note_end_date varchar(30)
    )
BEGIN
   	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
   if length(__note_start_date) > 0 THEN
		select 
			id
			,patient_id
			,title
			,summary
			,(CASE 
				WHEN category = 'document' THEN 'Documentation'
                WHEN category = 'bill' THEN 'Billing'
                WHEN category = 'follow' THEN 'Follow-up'
                WHEN category = 'hold' THEN 'Hold'
            END) as category
			,DATE_FORMAT(createdon, '%Y-%m-%dT%H:%i') as createdon
			,DATE_FORMAT(updatedon, '%Y-%m-%dT%H:%i') as updatedon
            ,comments
			,createdby
			,updatedby
		from patient_notes 
		where date(createdon) between date(__note_start_date) and date(__note_end_date) 
            and patient_id = __patient_id
            and clinic_id = __clinic_id
			and active = 1
            order by pnote.id desc;
	ELSE
		select 
			pnote.id
			,pnote.patient_id
			,pnote.title
			,pnote.summary
			,(CASE 
				WHEN pnote.category = 'document' THEN 'Documentation'
                WHEN pnote.category = 'bill' THEN 'Billing'
                WHEN pnote.category = 'follow' THEN 'Follow-up'
                WHEN pnote.category = 'hold' THEN 'Hold'
            END) as category
			,DATE_FORMAT(pnote.createdon, '%Y-%m-%dT%H:%i') as createdon
			,DATE_FORMAT(pnote.updatedon, '%Y-%m-%dT%H:%i') as updatedon
            ,pnote.comments
			,pnote.createdby
			,pnote.updatedby
		from patient_notes pnote
		where pnote.patient_id = __patient_id
			and pnote.clinic_id = __clinic_id
			and pnote.active = 1
            order by pnote.id desc; 
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_getusertask` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_getusertask`(
		IN __task_start_date varchar(30),
        IN __task_end_date varchar(30),
        IN __taskto INT(11),
		IN __guid varchar(100)
    )
BEGIN
	DECLARE __def_id INT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
   
   set @_def_id = 0;
   
   if length(__task_start_date) > 0 THEN
	select 
		id
		,clinic_id
		,task_name
		,task_description
		,task_type
		,task_cycle
        ,DATE_FORMAT(task_start, '%Y-%m-%dT%H:%i:%s') as task_start
        ,DATE_FORMAT(task_end, '%Y-%m-%dT%H:%i:%s') as task_end
        ,DATE_FORMAT(range_start, '%Y-%m-%dT%H:%i:%s') as range_start
        ,DATE_FORMAT(range_end, '%Y-%m-%dT%H:%i:%s') as range_end
		,createdon
		,createdby
    from usertask 
    where task_start >= date(__task_start_date) 
		and task_end <= date(__task_end_date) 
        and clinic_id = __clinic_id
        and active = 1;
	ELSE
	select 
		id
		,clinic_id
		,task_name
		,task_description
		,task_type
		,task_cycle
        ,DATE_FORMAT(task_start, '%Y-%m-%dT%H:%i:%s') as task_start
        ,DATE_FORMAT(task_end, '%Y-%m-%dT%H:%i:%s') as task_end
        ,DATE_FORMAT(range_start, '%Y-%m-%dT%H:%i:%s') as range_start
        ,DATE_FORMAT(range_end, '%Y-%m-%dT%H:%i:%s') as range_end
		,createdon
		,createdby
    from usertask 
    where active = 1 and clinic_id = __clinic_id;    
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_getusertask_appointment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_getusertask_appointment`(
		IN __task_date varchar(30),
        IN __taskto INT(11),
		IN __guid varchar(100)
    )
BEGIN
   DECLARE __def_id INT;
   DECLARE __clinic_id INT DEFAULT 0;
   set @_def_id = 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
   if length(__task_date) > 0 THEN
		select 
			id
			,clinic_id
			,task_name
			,task_description
			,task_type
			,task_cycle
            ,(CASE WHEN DATE_FORMAT(task_start, '%H:%i') = '00:00' THEN DATE_FORMAT(task_start, '%Y-%m-%d')
			 ELSE DATE_FORMAT(task_start, '%Y-%m-%d %H:%i') 
			 END) as task_start
            ,(CASE WHEN DATE_FORMAT(task_end, '%H:%i') = '00:00' THEN DATE_FORMAT(task_end, '%Y-%m-%d')
			 ELSE DATE_FORMAT(task_end, '%Y-%m-%d %H:%i') 
			 END) as task_end
			,DATE_FORMAT(range_start, '%m/%d/%YT%H:%i') as range_start
			,DATE_FORMAT(range_end, '%m/%d/%YT%H:%i') as range_end
            ,taskto
			,createdon
			,createdby
		from usertask 
		where (DATE(task_start) <= date(__task_date) and DATE(task_end) >= date(__task_date))
			or (DATE(task_start) <= (DATE_ADD(__task_date, INTERVAL 1 day)) and DATE(task_end) >= (DATE_ADD(__task_date, INTERVAL 1 day)))
			or (DATE(task_start) <= (DATE_ADD(__task_date, INTERVAL 2 day)) and DATE(task_end) >= (DATE_ADD(__task_date, INTERVAL 2 day)))
			or (DATE(task_start) <= (DATE_ADD(__task_date, INTERVAL 3 day)) and DATE(task_end) >= (DATE_ADD(__task_date, INTERVAL 3 day)))
            or (date(__task_date) between DATE(task_start) and DATE(task_end))
			and active = 1
            and clinic_id = __clinic_id
		order by DATE(task_start);

	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_account_registration_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_account_registration_status`(
	IN __guid varchar(100)
)
ThisSP:BEGIN
	
    select 
			_status.id as status_id,
			_status.createon,
            _status.iscompleted,
            _status.completedon,
            _status.active,
        	_user.id as user_id,
			_status.clinic_id,
			_clinic.name as clinic_name,
			_user.username,
			_user.phone as userphone,
            _user.firstname,
            _user.lastname
        from account_registration_status _status
        left join user _user on _user.id = _status.user_id
        left join clinic _clinic on _clinic.id = _status.clinic_id -- and _clinic.active = 1
		where _status.guid = __guid; -- and active = 1;
    
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_adjustment_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_adjustment_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".adjustment limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_alluser_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_alluser_account`(
	IN __guid varchar(100)
)
BEGIN
	DECLARE __organisation_id INT DEFAULT 0;

	SET __organisation_id = func_get_organisation_id(__guid);
		select
				u.id 
				,u.organisation_id 
				,u.username 
				,u.password 
				,u.firstname 
				,u.lastname 
				,u.phone 
				,u.roleid
				,u.createdon 
				,u.updatedon 
				,u.updatedby 
				,ifnull(u.profile_picture_url, '')  as profile_picture_url
				,c.name as organisation_name
				,c.groupof
				,c.address1
				,c.address2
				,c.city
				,c.state
				,c.zip
				,c.primary_contact
				,c.primary_phone
				,c.secondary_phone
				,c.primary_email
				,c.website
				,r.rolename as role_name
				from user u 
				left join organisation c on c.id = u.organisation_id
				left join role r on r.id = u.roleid
                where  u.organisation_id  = __organisation_id;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_appointment_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_appointment_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".appointment limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_apptremindersent_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_apptremindersent_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".apptremindersent limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_bank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_bank`(
    IN __id varchar(1000)
    )
BEGIN
	if __id > 0 THEN
		select 
		_bank.id,
		_bank.bankname,
		DATE_FORMAT(_bank.createdon, '%Y-%m-%d %H:%i') as createdon,
		_bank.createdby
		from bank _bank
		where _bank.id = __id 
		and _bank.active =1;
    ELSE 
		select 
		_bank.id,
		_bank.bankname,
		DATE_FORMAT(_bank.createdon, '%Y-%m-%d %H:%i') as createdon,
		_bank.createdby
		from bank _bank
		where _bank.active =1;
    END IF;

    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_benefit_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_benefit_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".benefit limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_carrier_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_carrier_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".carrier limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_claimpayment_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_claimpayment_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".claimpayment limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_claimproc_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_claimproc_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".claimproc limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_commlog_definition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_commlog_definition`(
		IN __guid varchar(100),
        IN __opendentalDB CHAR(100)
    )
BEGIN
   DECLARE __def_id INT;
   DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	set @sQLStmt = CONCAT("select 
		DefNum as defnum
		,Category as category
		,ItemOrder as itemOrder
		,ItemName as itemName
        from ", __opendentalDB, ".jd_definition
        where IsHidden = 0
        and Category = 27
        and clinic_id = ", __clinic_id, "
        order by ItemOrder
	");
	
	PREPARE Stmt FROM @sQLStmt;
	EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt; 
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_commlog_notes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_commlog_notes`(
		IN __guid varchar(100),
		IN __patnum INT(11),
		IN __note_start_date varchar(30),
        IN __note_end_date varchar(30),
        IN __opendentalDB CHAR(100)
    )
BEGIN
   DECLARE __def_id INT;
   DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
   
	IF length(__note_start_date) > 0 THEN
		set @sQLStmt = CONCAT("select 
			__commlog.CommlogNum as commlog_num
			,__commlog.PatNum as patient_id
			,__commlog.CommDateTime as comm_datetime
			,__commlog.CommType as comm_type
			,__commlog.Note as note
			,__commlog.Mode_ as mode
            ,(CASE WHEN __commlog.Mode_ = 0 THEN ''
				WHEN __commlog.Mode_ = 1 THEN 'Email'
                WHEN __commlog.Mode_ = 2 THEN 'Mail'
                WHEN __commlog.Mode_ = 3 THEN 'Phone'
                WHEN __commlog.Mode_ = 4 THEN 'InPerson'
                WHEN __commlog.Mode_ = 5 THEN 'Text'
                WHEN __commlog.Mode_ = 6 THEN 'EmailAndText'
            END) as modestr            
			,__commlog.SentOrReceived as sent_received
            ,(CASE WHEN __commlog.SentOrReceived = 0 THEN ''
				WHEN __commlog.SentOrReceived = 1 THEN 'Sent'
                WHEN __commlog.SentOrReceived = 2 THEN 'Received'
            END) as sent_receivedstr
			,__commlog.UserNum as user_id
			,__commlog.Signature as signature
			,__commlog.SigIsTopaz as sig_topaz
			,__commlog.DateTStamp as createdon
			,__definition.ItemName as itemname
			from ", __opendentalDB, ".jd_commlog __commlog
			left join ", __opendentalDB, ".jd_definition __definition on __commlog.CommType = __definition.DefNum and __definition.clinic_id = ", __clinic_id, "
			where PatNum = ", __patnum, 
			" and date(CommDateTime) between date('",__note_start_date, "') and date('", __note_end_date, "') 
            and __commlog.clinic_id = ", __clinic_id, "
			order by CommlogNum desc");
	ELSE
		set @sQLStmt = CONCAT("select 
			__commlog.CommlogNum as commlog_num
			,__commlog.PatNum as patient_id
			,__commlog.CommDateTime as comm_datetime
			,__commlog.CommType as comm_type
			,__commlog.Note as note
			,__commlog.Mode_ as mode
            ,(CASE WHEN __commlog.Mode_ = 0 THEN ''
				WHEN __commlog.Mode_ = 1 THEN 'Email'
                WHEN __commlog.Mode_ = 2 THEN 'Mail'
                WHEN __commlog.Mode_ = 3 THEN 'Phone'
                WHEN __commlog.Mode_ = 4 THEN 'InPerson'
                WHEN __commlog.Mode_ = 5 THEN 'Text'
                WHEN __commlog.Mode_ = 6 THEN 'EmailAndText'
            END) as modestr
			,__commlog.SentOrReceived as sent_received
            ,(CASE WHEN __commlog.SentOrReceived = 0 THEN ''
				WHEN __commlog.SentOrReceived = 1 THEN 'Sent'
                WHEN __commlog.SentOrReceived = 2 THEN 'Received'
            END) as sent_receivedstr
			,__commlog.UserNum as user_id
			,__commlog.Signature as signature
			,__commlog.SigIsTopaz as sig_topaz
			,__commlog.DateTStamp as createdon
			,__definition.ItemName as itemname
			from ", __opendentalDB, ".jd_commlog __commlog
			left join ", __opendentalDB, ".jd_definition __definition on __commlog.CommType = __definition.DefNum and __definition.clinic_id = ", __clinic_id, "
			where PatNum = ", __patnum, " 
            and __commlog.clinic_id = ", __clinic_id, " 
            order by CommlogNum desc");
    END IF;
    
	PREPARE Stmt FROM @sQLStmt;
	EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt; 
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_commlog_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_commlog_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".commlog limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_confirmationrequest_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_confirmationrequest_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".confirmationrequest limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_customer`(
			IN 	__id INT
			,IN __guid varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF __id > 0 THEN
		select
			cust.id
			,cust.organisation_id
			,cust.name as customer_name
			,cust.Address1 as address1
			,cust.Address2 as address2
			,cust.city
			,cust.state
			,cust.zip
			,cust.gstin
			,cust.vendorcode
            ,cust.primarycontact
            ,cust.contactno
            ,cust.primaryemail
            ,DATE_FORMAT(cust.createdon, '%m/%d/%Y %H:%i') as createdon
			,cust.createdby
            ,DATE_FORMAT(cust.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,cust.updatedby
			,cust.comments
            ,org.name as org_name
		from customer cust
        left join organisation org on org.id = cust.organisation_id
        WHERE cust.id = __id
			and cust.organisation_id = __organisation_id
            and cust.active = 1
		ORDER BY cust.name;
	ELSEIF __id = 0 THEN
		select
			cust.id
			,cust.organisation_id
			,cust.name as customer_name
			,cust.Address1 as address1
			,cust.Address2 as address2
			,cust.city
			,cust.state
			,cust.zip
			,cust.gstin
			,cust.vendorcode
			,cust.primarycontact
            ,cust.contactno
            ,cust.primaryemail
            ,DATE_FORMAT(cust.createdon, '%m/%d/%Y %H:%i') as createdon
			,cust.createdby
            ,DATE_FORMAT(cust.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,cust.updatedby
			,cust.comments
            ,org.name as org_name
		from customer cust
        left join organisation org on org.id = cust.organisation_id
        WHERE cust.organisation_id = __organisation_id
			and cust.active = 1
		ORDER BY cust.name;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_active_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_active_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
			_customer.id as customer_id
			,_customer.name as customer_name
			,_customer.primarycontact as primarycontact
			,_customer.contactno as contactno
			,_customer.primaryemail as primaryemail  
			FROM customer _customer 
				WHERE _customer.active = 1
                AND _customer.organisation_id = __organisation_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_collection_amount_by_date` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_collection_amount_by_date`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
		__invoice.inv_number
		,_collection.id as collection_id
        ,DATE_FORMAT(_collection.cheque_date , '%m/%d/%Y') as collection_date
		,_collection.amount as collection_amount  
        ,_collection.writeoff as writeoff
        ,'cur' as transaction
		FROM invoice_collection _collection
        LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
		WHERE date(_collection.cheque_date) between date(__start_date) and date(__end_date)
        AND __invoice.status NOT IN ('cancelled', 'c')
        AND _collection.active = 1
        AND __invoice.organisation_id = __organisation_id
	union
    	SELECT 
		__invoice.inv_number
		,_collection.id as collection_id
        ,DATE_FORMAT(_collection.cheque_date , '%m/%d/%Y') as collection_date
		,_collection.amount as collection_amount  
        ,_collection.writeoff as writeoff
        ,'pre' as transaction
		FROM invoice_collection _collection
        LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
		WHERE date(_collection.cheque_date) between DATE_SUB(__start_date, interval 1 year) and last_day(DATE_SUB(__end_date, interval 1 year))
        AND __invoice.status NOT IN ('cancelled', 'c')
        AND _collection.active = 1
        AND __invoice.organisation_id = __organisation_id
        ORDER BY collection_date;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_collection_by_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_collection_by_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
	IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
        _invoice.customer_id
        ,_customer.name as customer_name
		,sum(_collection.amount) as collection_amount
        ,sum(_collection.writeoff) as writeoff
		FROM invoice _invoice
        LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id
        LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
		WHERE  date(_collection.cheque_date) between date(__start_date) and date(__end_date)
        AND _invoice.status NOT IN ('cancelled', 'c')
        AND _collection.active = 1
        AND _invoice.organisation_id = __organisation_id
        GROUP BY _invoice.customer_id, _customer.name
        ORDER BY  _customer.name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_collection_by_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_collection_by_transaction`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
	IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
		_collection.pay_mode
		,(CASE WHEN _collection.pay_mode = 1 THEN 'Cash'
		  WHEN _collection.pay_mode = 2 THEN 'Cheque'
		  WHEN _collection.pay_mode = 3 THEN 'NEFT/Wire'
		 END) as pay_mode_str
		,sum(_collection.amount) as collection_amount
        ,sum(_collection.writeoff) as writeoff
		FROM invoice _invoice
        LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id
		WHERE  date(_collection.cheque_date) between date(__start_date) and date(__end_date)
        AND _invoice.status NOT IN ('cancelled', 'c')
        AND _collection.active = 1
        AND _invoice.organisation_id = __organisation_id
        GROUP BY _collection.pay_mode
        ORDER BY  _collection.pay_mode;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_consolidated_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_consolidated_data`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
	IN __guid varchar(1000),
    IN __report_type char(1) -- '1' - Month , '2' - Year
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    IF __report_type = '1' THEN
		SELECT 
			sum(_invoice.amount_after_tax) as current_invoice_amount
			,(SELECT sum(_invoice.amount_after_tax)
			FROM invoice _invoice
			WHERE date(_invoice.inv_date) between date_sub(__start_date, INTERVAL 1 MONTH) AND date_sub(__end_date, INTERVAL 1 MONTH)
				AND _invoice.status NOT IN ('cancelled', 'c') AND _invoice.active = 1 AND _invoice.organisation_id = __organisation_id) as previous_invoice_amount
				
			,(SELECT sum(_collection.amount)
			FROM invoice_collection _collection
			LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
			WHERE date(_collection.cheque_date) between date(__start_date) and date(__end_date)
				AND _collection.active = 1  AND __invoice.organisation_id = __organisation_id) as current_collection_amount
				
			,(SELECT sum(_collection.amount)
			FROM invoice_collection _collection
			LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
			WHERE date(_collection.cheque_date) between date_sub(__start_date, INTERVAL 1 MONTH) AND date_sub(__end_date, INTERVAL 1 MONTH) 
				 AND _collection.active = 1 AND __invoice.organisation_id = __organisation_id) as previous_collection_amount
			,(SELECT 
			sum(_invoice.amount_after_tax) 
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE  _collection.invoice_id is null -- _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id
			AND DATEDIFF(curdate(), _invoice.inv_date) >= 31) as expected_collection
			
			,(SELECT 
				sum(_invoice.amount_after_tax) 
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE  _collection.invoice_id is null -- _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id) as outstanding_collection
			
			FROM invoice _invoice
			WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
				AND _invoice.status NOT IN ('cancelled', 'c')
				AND _invoice.active = 1 AND _invoice.organisation_id = __organisation_id;
	ELSEIF __report_type = '2' THEN
		SELECT 
			sum(_invoice.amount_after_tax) as current_invoice_amount
			,(SELECT sum(_invoice.amount_after_tax)
			FROM invoice _invoice
			WHERE date(_invoice.inv_date) between date_sub(__start_date, INTERVAL 1 YEAR) AND date_sub(__end_date, INTERVAL 1 YEAR)
				AND _invoice.status NOT IN ('cancelled', 'c') AND _invoice.active = 1 AND _invoice.organisation_id = __organisation_id) as previous_invoice_amount
				
			,(SELECT sum(_collection.amount)
			FROM invoice_collection _collection
			LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
			WHERE date(_collection.cheque_date) between date(__start_date) and date(__end_date)
				AND _collection.active = 1  AND __invoice.organisation_id = __organisation_id) as current_collection_amount
				
			,(SELECT sum(_collection.amount)
			FROM invoice_collection _collection
			LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
			WHERE date(_collection.cheque_date) between date_sub(__start_date, INTERVAL 1 YEAR) AND date_sub(__end_date, INTERVAL 1 YEAR) 
				 AND _collection.active = 1 
                 AND __invoice.organisation_id = __organisation_id) as previous_collection_amount
			,(SELECT 
			sum(_invoice.amount_after_tax) 
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE  _collection.invoice_id is null -- _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id
			AND DATEDIFF(curdate(), _invoice.inv_date) >= 31) as expected_collection
			
			,(SELECT 
				sum(_invoice.amount_after_tax) 
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE  _collection.invoice_id is null -- _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id) as outstanding_collection
			
			FROM invoice _invoice
			WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
				AND _invoice.status NOT IN ('cancelled', 'c')
				AND _invoice.active = 1 AND _invoice.organisation_id = __organisation_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_consolidated_detail_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_consolidated_detail_data`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
	IN __guid varchar(1000),
    IN __type char(1)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __type = '1' THEN
    SELECT
			_invoice.id
            ,_invoice.organisation_id
            ,_invoice.inv_prefix
			,_invoice.inv_number
            ,_invoice.inv_date as inv_date_raw
            ,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
            ,_invoice.amount_before_tax  as production_amount
            ,_invoice.cgst
            ,_invoice.sgst
            ,_invoice.inv_discount
			,_invoice.amount_after_tax as invoice_amount
            ,_invoice.customer_id
            ,_collection.id as collection_id
            ,_customer.name	as customer_name
            ,_collection.amount as collection_amount
            ,_collection.writeoff as writeoff
            ,DATE_FORMAT(_collection.cheque_date, '%d/%m/%Y') as collection_date
		FROM invoice _invoice
        LEFT JOIN invoice_collection _collection ON _collection.invoice_id = _invoice.id and _collection.active = 1
        LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
		WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
			AND _invoice.status NOT IN ('cancelled', 'c')
            AND _invoice.active = 1 AND _invoice.organisation_id = __organisation_id;        
	ELSEIF __type = '2' THEN
		SELECT 
			_invoice.id
            ,_invoice.organisation_id
            ,_invoice.inv_prefix
			,_invoice.inv_number
            ,_invoice.inv_date as inv_date_raw
            ,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
            ,_invoice.amount_before_tax  as production_amount
            ,_invoice.cgst
            ,_invoice.sgst
            ,_invoice.inv_discount
			,_invoice.amount_after_tax as invoice_amount
            ,_collection.id as collection_id
            ,_invoice.customer_id
            ,_customer.name as customer_name
			,_collection.amount as collection_amount
            ,DATE_FORMAT(_collection.cheque_date, '%d/%m/%Y') as collection_date
			,_collection.writeoff
			FROM invoice_collection _collection
            LEFT JOIN invoice _invoice on _invoice.id = _collection.invoice_id
            LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE date(_collection.cheque_date) between date(__start_date) and date(__end_date)
				AND _collection.active = 1  
                AND _invoice.organisation_id = __organisation_id 
                AND _customer.organisation_id = __organisation_id;
	ELSEIF __type = '3' THEN
		SELECT 
			_invoice.id
			,_invoice.organisation_id
            ,_invoice.inv_prefix
			,_invoice.inv_number
            ,_invoice.inv_date as inv_date_raw
			,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
			,DATEDIFF(curdate(), _invoice.inv_date) AS days
			,_invoice.customer_id
			,_customer.name as customer_name
			,_invoice.amount_after_tax as invoice_amount
			,_collection.invoice_id
            ,_collection.id as collection_id
            ,DATE_FORMAT(_collection.cheque_date, '%d/%m/%Y') as collection_date
			,_collection.amount as collection_amount
			,_collection.writeoff
			,_collection.amount+_collection.writeoff as total_collection
            ,_collection.active
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE  _collection.invoice_id is null -- _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id
			HAVING days >= 31;
	ELSEIF __type = '4' THEN
		SELECT 
			_invoice.id
			,_invoice.organisation_id
            ,_invoice.inv_prefix
			,_invoice.inv_number
            ,_invoice.inv_date as inv_date_raw
			,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
			,_invoice.customer_id
			,_customer.name as customer_name
			,_invoice.amount_after_tax as invoice_amount
			,_collection.invoice_id
            ,_collection.id as collection_id
            ,DATE_FORMAT(_collection.cheque_date, '%d/%m/%Y') as collection_date
			,_collection.amount as collection_amount
			,_collection.writeoff
			,_collection.amount+_collection.writeoff as total_collection
			FROM invoice _invoice
			LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id and _collection.active = 1
			LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE _collection.invoice_id is null --  _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or
			AND _invoice.status NOT IN ('cancelled', 'c')
			AND _invoice.organisation_id = __organisation_id;    
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
    COUNT(*) active_customer,
    (SELECT 
    COUNT(*) as invoiced_customer
		FROM
			(SELECT 
				_invoice.customer_id
				-- ,_invoice.amount_before_tax,
				-- ,_invoice.inv_number,
				-- ,_invoice.status
			FROM invoice _invoice 
				WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
				AND _invoice.status != 'cancelled' AND _invoice.organisation_id = __organisation_id
				group by _invoice.customer_id) res) AS invoiced_customer
		
        ,(SELECT 
				COUNT(*) 
			FROM
				(SELECT 
					_invoice.customer_id
				FROM invoice _invoice 
					WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
					AND _invoice.status != 'cancelled' 
                    AND _invoice.organisation_id = __organisation_id
					AND _invoice.customer_id NOT IN (
						SELECT __invoice.customer_id
							FROM invoice __invoice 
								WHERE date(__invoice.inv_date) < date(__start_date)
								AND __invoice.status != 'cancelled' 
                                 AND __invoice.organisation_id = __organisation_id
								group by __invoice.customer_id
					)
					group by _invoice.customer_id) res        
        ) as new_customer
            
		,(select count(*) from
			(SELECT 
            COUNT(_invoice.customer_id) 
			FROM
				invoice _invoice 
			WHERE _invoice.status != 'cancelled' 
				AND _invoice.organisation_id = __organisation_id
			group by _invoice.customer_id
			having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -6 MONTH)) res) as lost_customer
		,(select count(*) from
			(SELECT 
				COUNT(_invoice.customer_id)
			FROM
				invoice _invoice 
			WHERE _invoice.status != 'cancelled' 
				AND _invoice.organisation_id = __organisation_id
			group by _invoice.customer_id
			having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -3 MONTH)) res ) as not_in_contact_customer
        ,(select 
			count(__invoice.customer_id) 
			-- ,MAX(__invoice.inv_date) inv_date
		from invoice __invoice
		where __invoice.organisation_id = __organisation_id
			AND __invoice.customer_id in 
			(SELECT 
						_invoice.customer_id
				FROM
					invoice _invoice 
				WHERE _invoice.status != 'cancelled' 
				group by _invoice.customer_id
				having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -6 MONTH))
		group by __invoice.customer_id
		having MAX(__invoice.inv_date) between date(__start_date) and date(__end_date)
    ) as reactivated_customer
	
FROM
    customer
WHERE active = 1
    AND organisation_id = __organisation_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_expected_collection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_expected_collection`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
	IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
		_invoice.id
        ,_invoice.organisation_id
		,_invoice.inv_number
		,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
        ,DATEDIFF(curdate(), _invoice.inv_date) AS days
        ,_invoice.customer_id
        ,_customer.name as customer_name
		,_invoice.amount_after_tax
        ,_collection.invoice_id
		,_collection.amount
        ,_collection.writeoff
        ,_collection.amount+_collection.writeoff as total_collection
		FROM invoice _invoice
        LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id
        LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
		WHERE  _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or _collection.invoice_id is null
        AND _invoice.status NOT IN ('cancelled', 'c')
        AND _invoice.organisation_id = __organisation_id
        HAVING days >= 31;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_invoiced_amount_by_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_invoiced_amount_by_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	SELECT 
			_invoice.customer_id
			,_customer.name as customer_name
			,sum(_invoice.amount_after_tax) as invoice_amount
		FROM invoice _invoice
		LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
		WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
			AND _invoice.status NOT IN ('cancelled', 'c')
            AND _invoice.organisation_id = __organisation_id
		GROUP BY _invoice.customer_id, _customer.name
        ORDER BY _customer.name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_invoiced_amount_by_date` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_invoiced_amount_by_date`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
			_invoice.inv_number
            ,DATE_FORMAT(_invoice.inv_date, '%m/%d/%Y') as inv_date
            ,_invoice.amount_before_tax as production_amount
            ,_invoice.cgst
            ,_invoice.sgst
			,_invoice.amount_after_tax as invoice_amount
            ,'inv' as transaction
		FROM invoice _invoice
		WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
			AND _invoice.status NOT IN ('cancelled', 'c')
            AND _invoice.organisation_id = __organisation_id
	union
		SELECT
			_invoice.inv_number
            ,DATE_FORMAT(_invoice.inv_date, '%m/%d/%Y') as inv_date
            ,_invoice.amount_before_tax as production_amount
            ,_invoice.cgst
            ,_invoice.sgst
			,_invoice.amount_after_tax as invoice_amount
            ,'pre' as transaction
		FROM invoice _invoice
        WHERE date(_invoice.inv_date) between DATE_SUB(__start_date, interval 1 year) and last_day(DATE_SUB(__end_date, interval 1 year))
			AND _invoice.status NOT IN ('cancelled', 'c')
            AND _invoice.organisation_id = __organisation_id;
            
		/* SELECT 
		__invoice.inv_number
		,DATE_FORMAT(_collection.cheque_date , '%m/%d/%Y') as inv_date
			,0 as production_amount
            ,0 as cgst
            ,0 as sgst
			,_collection.amount as invoice_amount  
            ,'col' as transaction
		FROM invoice_collection _collection
        LEFT JOIN invoice __invoice on __invoice.id = _collection.invoice_id
		WHERE date(_collection.cheque_date) between date(__start_date) and date(__end_date)
        AND __invoice.status NOT IN ('cancelled', 'c')
        AND _collection.active = 1
        AND __invoice.organisation_id = __organisation_id
        ORDER BY inv_date; */
        
        -- WHERE date(_collection.cheque_date) between DATE_SUB(__start_date, interval 1 year) and DATE_SUB(__end_date, interval 1 year)
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_invoiced_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_invoiced_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	SELECT 
			_invoice.customer_id
			,_customer.name as customer_name
			,_customer.primarycontact as primarycontact
			,_customer.contactno as contactno
			,_customer.primaryemail as primaryemail  
			FROM invoice _invoice 
             LEFT JOIN customer _customer ON _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
				WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
				AND _invoice.status != 'cancelled' 
                AND _invoice.organisation_id = __organisation_id
				group by _invoice.customer_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_lost_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_lost_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
		DECLARE __organisation_id INT DEFAULT 0;

		if length(__guid) > 0 THEN
			select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
		END IF;
		SELECT 
            _invoice.customer_id
			,_customer.name as customer_name
			,_customer.primarycontact as primarycontact
			,_customer.contactno as contactno
			,_customer.primaryemail as primaryemail  
			FROM invoice _invoice 
            LEFT JOIN customer _customer ON _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE _invoice.status != 'cancelled' 
            AND _invoice.organisation_id = __organisation_id
			group by _invoice.customer_id
			having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -6 MONTH);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_new_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_new_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	SELECT 
        _invoice.customer_id
        ,_customer.name as customer_name
        ,_customer.primarycontact as primarycontact
        ,_customer.contactno as contactno
        ,_customer.primaryemail as primaryemail        
    FROM invoice _invoice
    LEFT JOIN customer _customer ON _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
        WHERE date(_invoice.inv_date) between date(__start_date) and date(__end_date)
        AND _invoice.status != 'cancelled' 
        AND _invoice.organisation_id = __organisation_id
        AND _invoice.customer_id NOT IN (
			SELECT __invoice.customer_id
				FROM invoice __invoice 
					WHERE date(__invoice.inv_date) < date(__start_date)
					AND __invoice.status != 'cancelled' 
                    AND __invoice.organisation_id = __organisation_id
					group by __invoice.customer_id
        )
        group by _invoice.customer_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_notin_contact_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_notin_contact_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
		DECLARE __organisation_id INT DEFAULT 0;

		if length(__guid) > 0 THEN
			select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
		END IF;

		SELECT 
            _invoice.customer_id
			,_customer.name as customer_name
			,_customer.primarycontact as primarycontact
			,_customer.contactno as contactno
			,_customer.primaryemail as primaryemail  
			FROM invoice _invoice 
            LEFT JOIN customer _customer ON _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE _invoice.status != 'cancelled' 
            AND _invoice.organisation_id = __organisation_id
			group by _invoice.customer_id
			having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -3 MONTH);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_outstanding_invoices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_outstanding_invoices`(
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	SELECT 
		_invoice.id
        ,_invoice.organisation_id
		,_invoice.inv_number
		,DATE_FORMAT(_invoice.inv_date, '%d/%m/%Y') as inv_date
        ,_invoice.customer_id
        ,_customer.name as customer_name
		,_invoice.amount_after_tax
        ,_collection.invoice_id
		,_collection.amount
        ,_collection.writeoff
        ,_collection.amount+_collection.writeoff as total_collection
		FROM invoice _invoice
        LEFT JOIN invoice_collection _collection on _collection.invoice_id = _invoice.id
        LEFT JOIN customer _customer on _customer.id = _invoice.customer_id and _customer.organisation_id = __organisation_id
		WHERE  _invoice.amount_after_tax > (_collection.amount+_collection.writeoff) or _collection.invoice_id is null
        AND _invoice.status NOT IN ('cancelled', 'c')
        AND _invoice.organisation_id = __organisation_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_dashboard_reactivated_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_dashboard_reactivated_customer`(
    IN __start_date varchar(30),
    IN __end_date varchar(30),
    IN __guid varchar(1000)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;

    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;

	select 
			__invoice.customer_id
			,_customer.name as customer_name
			,_customer.primarycontact as primarycontact
			,_customer.contactno as contactno
			,_customer.primaryemail as primaryemail  
		from invoice __invoice
        LEFT JOIN customer _customer ON _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
		where __invoice.organisation_id = __organisation_id 
			AND __invoice.customer_id in 
			(SELECT 
						_invoice.customer_id
				FROM
					invoice _invoice 
				WHERE _invoice.status != 'cancelled'
                  AND _invoice.organisation_id = __organisation_id
				group by _invoice.customer_id
				having MAX(_invoice.inv_date) <= date_add(__start_date, INTERVAL -6 MONTH))
		group by __invoice.customer_id
		having MAX(__invoice.inv_date) between date(__start_date) and date(__end_date);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_definition_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_definition_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".definition");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_deliverychallan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_deliverychallan`(
		IN 		__id INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    set __organisation_id = func_get_organisation_id(__guid);
    
	IF __id > 0 THEN
		SELECT 
			__deliverychallan.id
			,__organisation_id
			,__deliverychallan.dc_prefix
			,__deliverychallan.dc_number
			,__deliverychallan.dc_date
			,__deliverychallan.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
            ,__deliverychallan.order_id
			,__deliverychallan.order_no
			,__deliverychallan.order_date
			,__deliverychallan.vendor_code
			,DATE_FORMAT(__deliverychallan.createdon, '%m/%d/%Y %H:%i') as createdon
			,__deliverychallan.createdby
			,DATE_FORMAT(__deliverychallan.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__deliverychallan.updatedby
			,__deliverychallan.comments       
        FROM deliverychallan __deliverychallan
        left join customer _customer on _customer.id = __deliverychallan.customer_id and _customer.organisation_id = __organisation_id
        WHERE __deliverychallan.id = __id
			and __deliverychallan.organisation_id = __organisation_id
		order by __deliverychallan.id desc;
	ELSEIF __id = 0 THEN
			SELECT
			__deliverychallan.id
			,__organisation_id
			,__deliverychallan.dc_prefix
			,__deliverychallan.dc_number
			,__deliverychallan.dc_date
			,__deliverychallan.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
            ,__deliverychallan.order_id
			,__deliverychallan.order_no
			,__deliverychallan.order_date
			,__deliverychallan.vendor_code
			,DATE_FORMAT(__deliverychallan.createdon, '%m/%d/%Y %H:%i') as createdon
			,__deliverychallan.createdby
			,DATE_FORMAT(__deliverychallan.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__deliverychallan.updatedby
			,__deliverychallan.comments  
        FROM deliverychallan __deliverychallan
        left join customer _customer on _customer.id = __deliverychallan.customer_id and _customer.organisation_id = __organisation_id
        WHERE __deliverychallan.organisation_id = __organisation_id
        order by __deliverychallan.id desc;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_deliverychallanWithDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_deliverychallanWithDetail`(
        IN __guid	varchar(1000)
        ,IN __order_id INT
        
    )
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;
    set __organisation_id = func_get_organisation_id(__guid);
	
    if(__order_id > 0) THEN
		select 
			__deliverychallan.id
			,__deliverychallan.dc_prefix
			,__deliverychallan.dc_number
			,__deliverychallan.dc_date as dc_date_raw
			,DATE_FORMAT(__deliverychallan.dc_date, '%d/%m/%Y') as dc_date
			,__deliverychallan.order_id as order_ids
			,__deliverychallan.order_no
			,__deliverychallan.order_date
			,__deliverychallan.customer_id
			,__deliverychallan_detail.dc_id
			,__deliverychallan_detail.order_id
			,__customer.name as customer_name
			,__customer.gstin as customer_gstin
			,__customer.vendorcode as customer_vendor_code
			,__customer.primaryemail as customer_email
			,__customer.primarycontact as customer_primary_contact
			,__customer.Address1  as address1
			,__customer.Address2  as address2
			,__customer.city
			,__customer.state
			,__customer.zip
			
			,__deliverychallan_detail.dc_id
            ,__deliverychallan_detail.order_id as dc_order_id
            ,__purchaseorder.order_no as dc_order_no
            ,__purchaseorder.order_date as dc_order_date
            ,__deliverychallan_detail.product_id
			,__product.name as product_name
			,__deliverychallan_detail.process_id
			,__process.process_name
			,__deliverychallan_detail.quantity
			,__deliverychallan_detail.unit
		from deliverychallan __deliverychallan
		left join deliverychallan_detail __deliverychallan_detail on __deliverychallan_detail.dc_id = __deliverychallan.id
        left join purchaseorder __purchaseorder on __purchaseorder.id = __deliverychallan_detail.order_id
		left join customer __customer on __customer.id = __deliverychallan.customer_id and __customer.organisation_id = __organisation_id
		left join product __product on __product.id = __deliverychallan_detail.product_id
		left join jobservice __process on __process.id = __deliverychallan_detail.process_id
		WHERE __deliverychallan.organisation_id = __organisation_id
			and __deliverychallan_detail.dc_id in (select distinct dc_id from deliverychallan_detail where order_id =  __order_id);
	ELSE
		select 'order_id is missing' as message;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_deliverychallan_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_deliverychallan_detail`(
		IN 		__dc_id INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
	DECLARE __organisation_id INT DEFAULT 0;
    
	set __organisation_id = func_get_organisation_id(__guid);
    
	IF __dc_id > 0 THEN
		SELECT 
			__deliverychallan_detail.id
			,__deliverychallan_detail.dc_id
            ,__deliverychallan_detail.order_id
            ,__purchaseorder.order_no
            ,__purchaseorder.order_date
			,__deliverychallan_detail.product_id
            ,__product.name as product_name
			,__deliverychallan_detail.hsn_sac
            ,__deliverychallan_detail.process_id as process_id
            ,__process.process_name
			,__deliverychallan_detail.quantity
			,__deliverychallan_detail.unit
			,DATE_FORMAT(__deliverychallan_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__deliverychallan_detail.createdby
			,DATE_FORMAT(__deliverychallan_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__deliverychallan_detail.updatedby
			,__deliverychallan_detail.comments        
        FROM deliverychallan_detail __deliverychallan_detail
        join deliverychallan __deliverychallan on __deliverychallan.id = __deliverychallan_detail.dc_id
        left join jobservice __process on __process.id = __deliverychallan_detail.process_id
        left join purchaseorder __purchaseorder on __purchaseorder.id = __deliverychallan_detail.order_id
        left join product __product on __product.id = __deliverychallan_detail.product_id
        WHERE __deliverychallan_detail.id = __dc_id 
			and __deliverychallan.organisation_id = __organisation_id
			and __deliverychallan_detail.active = 1;
	ELSEIF __dc_id = 0 THEN
		SELECT 
			__deliverychallan_detail.id
			,__deliverychallan_detail.dc_id
            ,__deliverychallan_detail.order_id
            ,__purchaseorder.order_no
            ,__purchaseorder.order_date
			,__deliverychallan_detail.product_id
            ,__product.name as product_name
			,__deliverychallan_detail.hsn_sac
            ,__deliverychallan_detail.process_id as process_id
            ,__process.process_name
			,__deliverychallan_detail.quantity
			,__deliverychallan_detail.unit
			,DATE_FORMAT(__deliverychallan_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__deliverychallan_detail.createdby
			,DATE_FORMAT(__deliverychallan_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__deliverychallan_detail.updatedby
			,__deliverychallan_detail.comments        
        FROM deliverychallan_detail __deliverychallan_detail
        join deliverychallan __deliverychallan on __deliverychallan.id = __deliverychallan_detail.dc_id
        left join jobservice __process on __process.id = __deliverychallan_detail.process_id
        left join purchaseorder __purchaseorder on __purchaseorder.id = __deliverychallan_detail.order_id
        left join product __product on __product.id = __deliverychallan_detail.product_id
        WHERE __deliverychallan.organisation_id = __organisation_id 
			and __deliverychallan_detail.active = 1;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_document_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_document_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".document limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_guardian_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_guardian_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".guardian");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_histappointment_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_histappointment_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".histappointment limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_insplan_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_insplan_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".insplan limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_inssub_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_inssub_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".inssub limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice`(
		IN 		__id INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __id > 0 THEN
		SELECT 
			__invoice.id
			,__organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
			,__invoice.inv_date
			,__invoice.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
            ,__invoice.order_id
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
            ,__invoice.inv_discount
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
            ,(CASE WHEN __invoice.status='cancelled' THEN 'Cancelled' 
				WHEN _collection.id > 0 THEN 'Received'
                ELSE 'Open' END) as status
			,__invoice.comments       
            ,_collection.collection_main_id as collection_main_id
            ,_collection.id as collection_id
            ,_collection.amount as collected_amount
            ,_collection.pay_mode
            ,(CASE WHEN _collection.pay_mode = 1 THEN 'Cash'
			  WHEN _collection.pay_mode = 2 THEN 'Cheque'
              WHEN _collection.pay_mode = 3 THEN 'NEFT/Wire'
             END) as pay_mode_str
            ,_collection.cheque_no
            ,DATE_FORMAT(_collection.cheque_date, '%m/%d/%Y') as cheque_date
            ,_collection.bank_id
            ,_bank.bankname as bank_name
            ,_collection.writeoff as writeoff_amount            
            -- ,(select ifnull(sum(_collection.amount), 0) from invoice_collection _collection where _collection.invoice_id = __invoice.id) as collected_amount
        FROM invoice __invoice
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        left join invoice_collection _collection on _collection.invoice_id = __invoice.id and _collection.active = 1
        left join bank _bank on _bank.id = _collection.bank_id 
        WHERE __invoice.id = __id
			and __invoice.organisation_id = __organisation_id
		order by __invoice.id desc;
	ELSEIF __id = 0 THEN
			SELECT
			__invoice.id
			,__organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
			,__invoice.inv_date
			,__invoice.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
            ,__invoice.order_id
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
            ,__invoice.inv_discount
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
            ,(CASE WHEN __invoice.status='cancelled' THEN 'Cancelled' 
				WHEN _collection.id > 0 THEN 'Received'
                ELSE 'Open' END) as status
			,__invoice.comments  
            ,_collection.collection_main_id as collection_main_id
            ,_collection.id as collection_id
            ,_collection.amount as collected_amount
            ,_collection.pay_mode
            ,(CASE WHEN _collection.pay_mode = 1 THEN 'Cash'
			  WHEN _collection.pay_mode = 2 THEN 'Cheque'
              WHEN _collection.pay_mode = 3 THEN 'NEFT/Wire'
             END) as pay_mode_str            
            ,_collection.cheque_no
            ,DATE_FORMAT(_collection.cheque_date, '%m/%d/%Y') as cheque_date
            ,_collection.bank_id
            ,_bank.bankname as bank_name
            ,_collection.writeoff as writeoff_amount
            ,DATE_FORMAT(_collection.createdon, '%m/%d/%Y') as received_date
        FROM invoice __invoice
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        left join invoice_collection _collection on _collection.invoice_id = __invoice.id and _collection.active = 1
        left join bank _bank on _bank.id = _collection.bank_id 
        WHERE __invoice.organisation_id = __organisation_id
        order by __invoice.id desc;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoiceByNo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoiceByNo`(
		IN 		__inv_no INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __inv_no > 0 THEN
		SELECT 
			__invoice.id
			,__organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
			,__invoice.inv_date
			,__invoice.customer_id
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
			,__invoice.cgst
			,__invoice.sgst
			,__invoice.amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
			,__invoice.comments        
        FROM invoice __invoice
        WHERE __invoice.inv_number = __inv_no
			and __invoice.organisation_id = __organisation_id
            and __invoice.status = '' or __invoice.status is null;
	ELSEIF __inv_no = 0 THEN
			SELECT
			__invoice.id
			,__organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
			,__invoice.inv_date
			,__invoice.customer_id
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
			,__invoice.cgst
			,__invoice.sgst
			,__invoice.amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
			,__invoice.comments        
        FROM invoice __invoice
        WHERE __invoice.organisation_id = __organisation_id
        and __invoice.status = '' or __invoice.status is null;    
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice_collection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice_collection`(
		IN 		__invoice_id INT
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
	IF __invoice_id > 0 THEN
		select 
			__collection_main.id as collection_main_id
			,__invoice_collection.id
			,__invoice_collection.invoice_id
			,__invoice.inv_number as inv_number
			,__collection_main.pay_mode
			,(CASE WHEN __collection_main.pay_mode = 1 THEN 'Cash'
			  WHEN __collection_main.pay_mode = 2 THEN 'Cheque'
			  WHEN __collection_main.pay_mode = 3 THEN 'NEFT/Wire'
			 END) as pay_mode_str        
			,__collection_main.cheque_no
			,__collection_main.cheque_date
			,__collection_main.bank_id
			,_bank.bankname as bank_name
			,__collection_main.amount
			,__collection_main.writeoff
			,__collection_main.iscombined     
			,__collection_main.combinedfor 
			,DATE_FORMAT(__collection_main.createdon, '%m/%d/%Y %H:%i') as createdon
			,__collection_main.createdby
			,DATE_FORMAT(__collection_main.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__collection_main.updatedby
			,__collection_main.comments            
		FROM invoice_collection_main __collection_main
		left join invoice_collection __invoice_collection on __invoice_collection.collection_main_id = __collection_main.id
		left join invoice __invoice on __invoice.id = __invoice_collection.invoice_id
		left join bank _bank on _bank.id = __collection_main.bank_id 
		WHERE __invoice.id = __invoice_id
			and __invoice_collection.active = 1;
	ELSEIF __invoice_id = 0 THEN
		select 
			__collection_main.id as collection_main_id
			,__invoice_collection.id
			,__invoice_collection.invoice_id
			,__invoice.inv_number as inv_number
			,__collection_main.pay_mode
			,(CASE WHEN __collection_main.pay_mode = 1 THEN 'Cash'
			  WHEN __collection_main.pay_mode = 2 THEN 'Cheque'
			  WHEN __collection_main.pay_mode = 3 THEN 'NEFT/Wire'
			 END) as pay_mode_str        
			,__collection_main.cheque_no
			,__collection_main.cheque_date
			,__collection_main.bank_id
			,_bank.bankname as bank_name
			,__collection_main.amount
			,__collection_main.writeoff
			,__collection_main.iscombined     
			,__collection_main.combinedfor 
					,DATE_FORMAT(__collection_main.createdon, '%m/%d/%Y %H:%i') as createdon
					,__collection_main.createdby
					,DATE_FORMAT(__collection_main.updatedon, '%m/%d/%Y %H:%i') as updatedon
					,__collection_main.updatedby
					,__collection_main.comments            
		FROM invoice_collection_main __collection_main
		left join invoice_collection __invoice_collection on __invoice_collection.collection_main_id = __collection_main.id
		left join invoice __invoice on __invoice.id = __invoice_collection.invoice_id
		left join bank _bank on _bank.id = __collection_main.bank_id 
		WHERE __invoice_collection.active = 1;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice_consolidated_range` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice_consolidated_range`(
		IN 	__guid	varchar(1000)
        ,IN 	__start_date	varchar(30)
        ,IN 	__end_date	varchar(30)
        ,IN 	__customer_id	INT
        ,IN 	__status varchar(10)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF length(__start_date) > 0 THEN
		select 
			__customer.id as customer_id
			,__customer.name as customer_name
			,sum(__invoice.amount_before_tax) as amount_before_tax
			,sum(__invoice.cgst*__invoice.amount_before_tax/100) as cgst_amount
			,sum(__invoice.sgst*__invoice.amount_before_tax/100) as sgst_amount
			,sum(__invoice.amount_after_tax)  as amount_after_tax
			,ifnull(sum(__collection.writeoff), 0) as writeoff_amount
			,ifnull(sum(__collection.amount), 0) as collected_amount
			,(sum(__invoice.amount_after_tax) - ifnull(sum(__collection.amount), 0) - ifnull(sum(__collection.writeoff), 0)) as balance_to_collect
        FROM invoice __invoice
        left join invoice_collection __collection on __collection.invoice_id = __invoice.id
        -- left join invoice_collection_main __collection_main on __collection_main.id = __collection.collection_main_id
        left join customer __customer on __customer.id = __invoice.customer_id
        WHERE (date(__invoice.inv_date)  between DATE(__start_date) and DATE(__end_date))
			and (CASE WHEN  __customer_id > 0 THEN __invoice.customer_id = __customer_id
				ELSE 1 = 1 END)
			and (CASE 
				WHEN __status = '0' THEN 1 = 1 
                WHEN __status = '1' THEN __collection.amount is null or __collection.amount = 0
                WHEN __status = '2' THEN __collection.amount > 0
                end)
			and __invoice.organisation_id = __organisation_id
            and __customer.id is not null
		group by __customer.id, __customer.name;
	ELSE
		select 
			__customer.id as customer_id
			,__customer.name as customer_name
			,sum(__invoice.amount_before_tax) as amount_before_tax
			,sum(__invoice.cgst*__invoice.amount_before_tax/100) as cgst_amount
			,sum(__invoice.sgst*__invoice.amount_before_tax/100) as sgst_amount
			,sum(__invoice.amount_after_tax)  as amount_after_tax
			,ifnull(sum(__collection.writeoff), 0) as writeoff_amount
			,ifnull(sum(__collection.amount), 0) as collected_amount
			,(sum(__invoice.amount_after_tax) - ifnull(sum(__collection.amount), 0) - ifnull(sum(__collection.writeoff), 0)) as balance_to_collect
        FROM invoice __invoice
        left join invoice_collection __collection on __collection.invoice_id = __invoice.id
        left join customer __customer on __customer.id = __invoice.customer_id
        WHERE __invoice.organisation_id = __organisation_id
        and __invoice.status = '' or __invoice.status is null
        and __customer.id is not null
		group by __customer.id, __customer.name; 
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice_customer_range` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice_customer_range`(
		IN 	__guid	varchar(1000)
        ,IN 	__start_date	varchar(30)
        ,IN 	__end_date	varchar(30)
        ,IN 	__customer_id	INT
        ,IN 	__status varchar(10)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF length(__start_date) > 0 THEN
		SELECT 
			__invoice.id
			,__invoice.organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
            ,__invoice.inv_date -- DATE_FORMAT(, '%d/%m/%Y %H:%i') as inv_date
			,__invoice.customer_id
            ,_customer.name as customer_name
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
            ,__invoice.inv_discount
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
            ,__invoice.status
			,__invoice.comments        
            ,__collection.id as collection_id
            ,__collection_main.id as collection_main_id
            ,__collection_main.pay_mode
            ,(CASE WHEN __collection_main.pay_mode = 1 THEN 'Cash'
			  WHEN __collection_main.pay_mode = 2 THEN 'Cheque'
              WHEN __collection_main.pay_mode = 3 THEN 'NEFT/Wire'
             END) as pay_mode_str            
			,__collection_main.cheque_no
			,__collection_main.cheque_date
			,__collection_main.bank_id
            ,_bank.bankname as bank_name
            ,__collection.amount as collected_amount
            ,__collection.writeoff as writeoff_amount
			,CAST(__collection_main.iscombined AS UNSIGNED) as iscombined
			,__collection.combinedfor
			,__collection.createdon as receivedon
        FROM invoice __invoice
        left join invoice_collection __collection on __collection.invoice_id = __invoice.id
        left join invoice_collection_main __collection_main on __collection_main.id = __collection.collection_main_id
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        left join bank _bank on _bank.id = __collection.bank_id 
        WHERE (date(__invoice.inv_date)  between DATE(__start_date) and DATE(__end_date))
			and (CASE WHEN  __customer_id > 0 THEN __invoice.customer_id = __customer_id
				ELSE 1 = 1 END)
			and (CASE 
				WHEN __status = '0' THEN 1 = 1 
                WHEN __status = '1' THEN __collection.amount is null or __collection.amount = 0
                WHEN __status = '2' THEN __collection.amount > 0
                end)
			and __invoice.organisation_id = __organisation_id
            and __invoice.status != 'cancelled' -- or __invoice.status = '' is null
            order by __invoice.id;
	ELSE
			SELECT
			__invoice.id
			,__invoice.organisation_id
			,__invoice.inv_prefix
			,__invoice.inv_number
			,__invoice.inv_date
			,__invoice.customer_id
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
            ,__invoice.inv_discount
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
			,__invoice.comments     
            ,__collection.id as collection_id
            ,__collection.pay_mode
            ,(CASE WHEN __collection.pay_mode = 1 THEN 'Cash'
			  WHEN __collection.pay_mode = 2 THEN 'Cheque'
              WHEN __collection.pay_mode = 3 THEN 'NEFT/Wire'
             END) as pay_mode_str            
			,__collection.cheque_no
			,__collection.cheque_date
			,__collection.bank_id
            ,_bank.bankname as bank_name
            ,__collection.writeoff as writeoff_amount
			,__collection.amount as collected_amount
			,__collection.iscombined
			,__collection.combinedfor
			,__collection.createdon as receivedon
            ,_customer.id as customer_id
            ,_customer.name as customer_name            
        FROM invoice __invoice
        left join invoice_collection __collection on __collection.invoice_id = __invoice.id
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        left join bank _bank on _bank.id = __collection.bank_id 
        WHERE __invoice.organisation_id = __organisation_id
        and __invoice.status = '' or __invoice.status = '' is null
        order by __invoice.id desc;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice_detail`(
		IN 		__invoice_id INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
	DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __invoice_id > 0 THEN
		SELECT 
			__invoice_detail.id
			,__invoice_detail.invoice_id
            ,__invoice_detail.order_id
            ,__purchaseorder.order_no
            ,__purchaseorder.order_date
			,__invoice_detail.product_id
            ,__product.name as product_name
			,__invoice_detail.hsn_sac
            ,__invoice_detail.process_id as process_id
            ,__process.process_name
			,__invoice_detail.quantity
			,__invoice_detail.unit
			,__invoice_detail.rate
			,__invoice_detail.amount
			,DATE_FORMAT(__invoice_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice_detail.createdby
			,DATE_FORMAT(__invoice_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice_detail.updatedby
			,__invoice_detail.comments        
        FROM invoice_detail __invoice_detail
        join invoice __invoice on __invoice.id = __invoice_detail.invoice_id
        left join jobservice __process on __process.id = __invoice_detail.process_id
        left join purchaseorder __purchaseorder on __purchaseorder.id = __invoice_detail.order_id
        left join product __product on __product.id = __invoice_detail.product_id
        WHERE __invoice.id = __invoice_id 
			and __invoice.organisation_id = __organisation_id
			and __invoice_detail.active = 1;
	ELSEIF __invoice_id = 0 THEN
		SELECT 
			__invoice_detail.id
			,__invoice_detail.invoice_id
            ,__invoice_detail.order_id
            ,__purchaseorder.order_no
            ,__purchaseorder.order_date
			,__invoice_detail.product_id
            ,__product.name as product_name
			,__invoice_detail.hsn_sac
            ,__invoice_detail.process_id as process_id
            ,__process.process_name
			,__invoice_detail.quantity
			,__invoice_detail.unit
			,__invoice_detail.rate
			,__invoice_detail.amount
			,DATE_FORMAT(__invoice_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice_detail.createdby
			,DATE_FORMAT(__invoice_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice_detail.updatedby
			,__invoice_detail.comments        
        FROM invoice_detail __invoice_detail
        join invoice __invoice on __invoice.id = __invoice_detail.invoice_id
        left join jobservice __process on __process.id = __invoice_detail.process_id
        left join purchaseorder __purchaseorder on __purchaseorder.id = __invoice_detail.order_id
        left join product __product on __product.id = __invoice_detail.product_id
        WHERE __invoice.organisation_id = __organisation_id 
			and __invoice_detail.active = 1;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_invoice_pending_collection_by_cstomer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_invoice_pending_collection_by_cstomer`(
		IN __customer_id INT
        ,IN __invoiceId INT
		,IN	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __customer_id > 0 THEN
			SELECT 
				__invoice.id
				,__organisation_id as organisation_id
				,__invoice.inv_prefix
				,__invoice.inv_number
				,__invoice.inv_date
				,__invoice.customer_id
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,__invoice.sgst
				,__invoice.amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.comments
                ,0 as collection_id
				,0 as invoice_id
                ,0 as collection_main_id                
                ,'' as iscombined
                ,'' as combinedfor                
			FROM invoice __invoice
			left join invoice_collection __collection on __collection.invoice_id = __invoice.id
			WHERE __invoice.customer_id = __customer_id
				and __invoice.organisation_id = __organisation_id
				and __collection.invoice_id IS NULL
		union
			SELECT 
				__invoice.id
				,__organisation_id as organisation_id
				,__invoice.inv_prefix
				,__invoice.inv_number
				,__invoice.inv_date
				,__invoice.customer_id
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,__invoice.sgst
				,__invoice.amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.comments
                ,__collection.id as collection_id
                ,__collection.invoice_id
                ,__collection.collection_main_id
                ,CAST(__main.iscombined AS UNSIGNED) as iscombined
                ,__main.combinedfor                
			FROM invoice __invoice
			left join invoice_collection __collection on __collection.invoice_id = __invoice.id  
            left join invoice_collection_main __main on __main.id = __collection.collection_main_id
			WHERE __invoice.customer_id = __customer_id 
				and __invoice.organisation_id = __organisation_id 
                and __invoice.id in 
                (select invoice_id from invoice_collection where collection_main_id in (select collection_main_id from invoice_collection where invoice_id = __invoiceId));
	ELSEIF __customer_id = 0 THEN
			SELECT
				__invoice.id
				,__organisation_id
				,__invoice.inv_prefix
				,__invoice.inv_number
				,__invoice.inv_date
				,__invoice.customer_id
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,__invoice.sgst
				,__invoice.amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.comments        
                ,0 as collection_id
				,0 as invoice_id
                ,0 as collection_main_id                
                ,'' as iscombined
                ,'' as combinedfor                
			FROM invoice __invoice
			left join invoice_collection __collection on __collection.invoice_id = __invoice.id
			WHERE __invoice.organisation_id = __organisation_id
			and __collection.invoice_id IS NULL
		union
			SELECT
				__invoice.id
				,__organisation_id
				,__invoice.inv_prefix
				,__invoice.inv_number
				,__invoice.inv_date
				,__invoice.customer_id
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,__invoice.sgst
				,__invoice.amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.comments      
                ,__collection.id as collection_id
                ,__collection.invoice_id
                ,__collection.collection_main_id                
                ,CAST(__main.iscombined AS UNSIGNED) as iscombined
                ,__main.combinedfor
			FROM invoice __invoice
			left join invoice_collection __collection on __collection.invoice_id = __invoice.id
            left join invoice_collection_main __main on __main.collection_main_id = __collection.collection_main_id
			WHERE __invoice.organisation_id = __organisation_id 
			and __invoice.id in 
                (select invoice_id from invoice_collection where collection_main_id in (select collection_main_id from invoice_collection where invoice_id = __invoiceId));

        
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_jobservices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_jobservices`(
		IN __id int(11),
        IN __guid varchar(1000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;    
    
	IF __id > 0 THEN
		select 
			_jobservice.id, 
			_jobservice.organisation_id, 
			_jobservice.process_name, 
			_jobservice.process_description, 
			_jobservice.createdon, 
			_jobservice.createdby, 
			concat(_user.firstname, ' ', _user.lastname) as username
		from jobservice _jobservice
		left join user _user on _user.id = _jobservice.createdby
        where _jobservice.id = __id and
			_jobservice.organisation_id = __organisation_id
            order by _jobservice.process_name;
	ELSEIF __id = 0 THEN
		select 
			_jobservice.id, 
			_jobservice.organisation_id, 
			_jobservice.process_name, 
			_jobservice.process_description, 
			_jobservice.createdon, 
			_jobservice.createdby, 
			concat(_user.firstname, ' ', _user.lastname) as username
		from jobservice _jobservice
		left join user _user on _user.id = _jobservice.createdby
        where _jobservice.organisation_id = __organisation_id
        order by _jobservice.process_name;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_last_deliverychallan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_last_deliverychallan`(
		IN 	__guid	varchar(1000)
    )
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	
    select ifnull(max(id), 0) as last_challan_id from deliverychallan where organisation_id = __organisation_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_last_invoice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_last_invoice`(
		IN 	__guid	varchar(1000)
    )
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	
    select ifnull(max(inv_number), 0) as last_inv_no from invoice where organisation_id = __organisation_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_operatory_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_operatory_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".operatory limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_operatory_patplan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_operatory_patplan`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".patplan limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_organisation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_organisation`(
			IN 	__id varchar(10),
			IN __guid varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
	DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF __organisation_id >= 0 THEN
		select
			org.id
			,org.name as org_name
			,org.groupof
			,org.address1
			,org.address2
			,org.city
			,org.state
			,org.zip
			,org.ceo_name
			,org.primary_contact
			,org.primary_phone
			,org.secondary_phone
			,org.primary_email
			,org.website
			,org.microsite
			,org.comments
			,DATE_FORMAT(org.createdon, '%m/%d/%Y %H:%i') as createdon
			,org.createdby
			,DATE_FORMAT(org.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,org.updatedby
		from organisation org
        WHERE org.id = __organisation_id;
	ELSEIF __id = '22793049' THEN
		select
			org.id
			,org.name as org_name
			,org.groupof
			,org.address1
			,org.address2
			,org.city
			,org.state
			,org.zip
			,org.ceo_name
			,org.primary_contact
			,org.primary_phone
			,org.secondary_phone
			,org.primary_email
			,org.website
			,org.microsite
			,org.comments
			,DATE_FORMAT(org.createdon, '%m/%d/%Y %H:%i') as createdon
			,org.createdby
			,DATE_FORMAT(org.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,org.updatedby
		from organisation org
        WHERE org.active = 1;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_organisation_bank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_organisation_bank`(
	IN 	__id INT,
    IN __guid varchar(1000)
)
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __id > 0 THEN
		SELECT 
        __orgservice.bank_code as bank_code
		,__orgservice.bank_id as bank_id
        ,__bank.bankname as bank_name
        ,__orgservice.bank_account
        ,__orgservice.bank_ifsc
		,__orgservice.bank_micr
        ,__orgservice.bank_branch
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name
		from organisation_bank __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        left join bank __bank on __bank.id = __orgservice.bank_id
        WHERE __orgservice.organisation_id = __organisation_id
		  and __orgservice.id = __id;
	ELSEIF __id <= 0 THEN
		SELECT 
        __orgservice.bank_code as bank_code
		,__orgservice.bank_id as bank_id
        ,__bank.bankname as bank_name
        ,__orgservice.bank_account
        ,__orgservice.bank_ifsc
		,__orgservice.bank_micr
        ,__orgservice.bank_branch
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name
		from organisation_bank __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        left join bank __bank on __bank.id = __orgservice.bank_id
        WHERE __orgservice.organisation_id = __organisation_id
        and __orgservice.active = 1 limit 1;

	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_organisation_gstin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_organisation_gstin`(
	IN 	__id INT,
    IN __guid varchar(1000)
)
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;

    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __id > 0 THEN
		SELECT 
        __orgservice.gstin as gstin
		,__orgservice.legalname as legalname
        ,__orgservice.constitution_of_business
        ,DATE_FORMAT(__orgservice.liabilityon, '%m/%d/%Y') as liabilityon
		,__orgservice.registration_type
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name
		from organisation_gstin __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        WHERE __orgservice.organisation_id = __organisation_id
		  and __orgservice.id = __id;
	ELSEIF __id <= 0 THEN
		SELECT 
        __orgservice.gstin as gstin
		,__orgservice.legalname as legalname
        ,__orgservice.constitution_of_business
        ,DATE_FORMAT(__orgservice.liabilityon, '%m/%d/%Y') as liabilityon
		,__orgservice.registration_type
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name		
        from organisation_gstin __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        WHERE __orgservice.organisation_id = __organisation_id
        and __orgservice.active = 1 limit 1;

	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_organisation_service` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_organisation_service`(
	IN 	__id INT,
    IN __guid varchar(1000)
)
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;

    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __id > 0 THEN
		SELECT 
        __orgservice.code as service_code
		,__orgservice.name as service_name
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name
		from organisation_service __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        WHERE __orgservice.organisation_id = __organisation_id
		  and __orgservice.id = __id
          and __orgservice.active = 1;
        
	ELSEIF __id <= 0 THEN
		SELECT 
        __orgservice.code as service_code
		,__orgservice.name as service_name
        ,DATE_FORMAT(__orgservice.createdon, '%m/%d/%Y %H:%i') as createdon
		,__orgservice.createdby
        ,DATE_FORMAT(__orgservice.updatedon, '%m/%d/%Y %H:%i') as updatedon
		,__orgservice.updatedby
		,__orgservice.comments
        ,__org.name as org_name
		from organisation_service __orgservice
        left join organisation __org on __org.id = __orgservice.organisation_id
        WHERE __orgservice.organisation_id = __organisation_id
        and __orgservice.active = 1 limit 1;

	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_patientdata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_patientdata`(
	IN __clinic_id bigint(20),
    IN __update_mode char(1),
    IN __updated_after varchar(30)
)
BEGIN
	
    DECLARE __temPatNum bigint(20);
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_patient_by_id` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_patient_by_id`(
	IN __guid varchar(100),
	IN __patient_id varchar(20)
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

	select  
			pat.clinic_id
			,pat.PatNum as patient_id
			,pat.FName as firstName
			,pat.LName as lastName
			,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
			,pat.PatStatus as patstatus
			,CASE
				when pat.PatStatus = 0 then 'Active'
				when pat.PatStatus = 1 then 'Non Patient'
				when pat.PatStatus = 2 then 'Inactive'
				when pat.PatStatus = 3 then 'Archived'
				when pat.PatStatus = 4 then 'Deleted'
				when pat.PatStatus = 5 then 'Deceased'
				when pat.PatStatus = 6 then 'Prospective'
			END as patient_status
			,pat.Gender as gender
			,CASE 
				WHEN pat.gender = 0 then 'Male'
				WHEN pat.gender = 1 then 'Female'
				WHEN pat.gender = 2 then 'Unknown'
				END as 'gendertext'          
			,pat.Position, position
			,pat.Birthdate as dob
			,DATE_FORMAT(pat.Birthdate, "%m/%d/%Y") AS birth_date
			,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
			,pat.Address as address
			,pat.Address2 as address2
			,pat.City as city
			,pat.State as state
			,pat.wirelessphone as cell
			,pat.HmPhone as homephone
			,pat.WkPhone as workphone
			,pat.Email as email
			,TxtMsgOk as sendtext
			,DATE_FORMAT(pat.DateFirstVisit, "%m/%d/%Y") AS firstvisit
			,pat.Zip as zip
			,appt.AptNum as appointment_id
			,appt.AptStatus as appointment_status
			,DATE_FORMAT(appt.AptDateTime, '%m/%d/%Y %h:%i %p')  as apptdatetime
			,(select IFNULL(DATE_FORMAT(max(appt1.AptDateTime), '%m/%d/%Y'), '') from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.AptDateTime < curdate()  and appt1.clinic_id = __clinic_id) as lastvisit
			,(select IFNULL(DATE_FORMAT(max(appt1.AptDateTime), '%m/%d/%Y'), '') from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.AptDateTime >= curdate() and appt1.clinic_id = __clinic_id) as nextvisit
			,(select IFNULL(DATE_FORMAT(max(appt1.AptDateTime), '%m/%d/%Y'), '') from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.IsHygiene = 1 and appt1.AptDateTime < curdate() and appt1.clinic_id = __clinic_id)  as lastHygieneAppt
			,(select IFNULL(DATE_FORMAT(max(appt1.AptDateTime), '%m/%d/%Y'), '') from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.IsHygiene = 1 and appt1.AptDateTime >= curdate() and appt1.clinic_id = __clinic_id) as nextHygieneAppt
			,(select IF(ifnull(max(appt1.AptDateTime), 0) = 0, 0, 1) from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.IsHygiene = 1 and (appt1.AptDateTime < DATE_SUB(curdate(), INTERVAL 6 MONTH)) and appt1.clinic_id = __clinic_id)  as requireHygieneAppt
			,(select DATE_FORMAT(IF(ifnull(max(appt1.AptDateTime), 0) = 0, current_date(), DATE_ADD(max(appt1.AptDateTime), INTERVAL 6 MONTH)), '%m/%d/%Y') from jd_appointment appt1 where appt1.PatNum = pat.PatNum and appt1.IsHygiene = 1 and appt1.AptDateTime < curdate() and appt1.clinic_id = __clinic_id)  as dueHygieneAppt
			,ImageFolder as imagefolder
			from jd_patient pat 
			left join jd_appointment appt on pat.PatNum = appt.PatNum and  appt.AptStatus = 1 
				and appt.AptDateTime = (select max(appt2.AptDateTime) from  jd_appointment appt2 where appt2.PatNum = pat.PatNum) 
			where pat.PatNum = __patient_id and pat.clinic_id = __clinic_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_patient_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_patient_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".patient limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_patplan_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_patplan_original`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".patplan limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_payment_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_payment_original`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".payment limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_paysplit_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_paysplit_original`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".paysplit limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_pending_for_deliverychallan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_pending_for_deliverychallan`(
		IN 	__guid	varchar(1000)
        ,IN __customer_id INT
    )
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;
    set __organisation_id = func_get_organisation_id(__guid);
	

	select 
		__podetail.id as podetail_id
		,__podetail.po_id as order_id
		,__po.order_no as order_no
        ,__po.order_date
		,__podetail.product_id as product_id
        ,__product.name as product_name
        ,__podetail.process as process_id
        ,__process.process_name
		,__podetail.quantity as quantity
        ,__podetail.unit as unit
        ,__podetail.weight_kg
		,__dcdetail.order_id as dc_order_id
		,__dcdetail.product_id as dc_product_id
		,__dcdetail.quantity as dc_quantity
	from purchaseorder_detail __podetail
	left join deliverychallan_detail __dcdetail on __dcdetail.order_id = __podetail.po_id and __dcdetail.product_id = __podetail.product_id
	join purchaseorder __po on __po.id = __podetail.po_id and __po.customer_id = __customer_id
    left join product __product on __product.id = __podetail.product_id
    left join jobservice __process on __process.id = __podetail.process
	where  __dcdetail.product_id is null
		and __po.organisation_id = __organisation_id
		and __po.status != 'invoiced' and __po.status != 'cancelled';
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_procedurecode_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_procedurecode_original`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".procedurecode limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_procedurelog_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_procedurelog_original`(
    IN  __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".procedurelog limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_product`(
	IN __product_id INT(11)
    ,IN  __guid varchar(100)
)
BEGIN
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF __product_id <= 0 THEN
		select 
			prod.id as product_id
            ,prod.name as product_name
            ,prod.category_id
            ,prod.description
            ,prod.createdon
            ,prod.createdby
            ,prod.active
        from product prod
        where prod.organisation_id = __organisation_id
			and prod.active = 1
        order by prod.name;
    else
		select 
			prod.id as product_id
            ,prod.name as product_name
            ,prod.category_id
            ,prod.description
            ,prod.createdon
            ,prod.createdby
            ,prod.active
        from product prod
        where prod.organisation_id = __organisation_id
			and prod.id = __product_id
            and prod.active = 1
        order by prod.name;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_provider_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_provider_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".provider limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_purchaseorder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_purchaseorder`(
		IN 		__id INT
		,IN 	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __id > 0 THEN
		SELECT 
			__invoice.id
            ,__invoice.id as order_id
			,__organisation_id
			,__invoice.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
            ,(CASE 
				WHEN __invoice.status='cancelled' THEN 'Cancelled' 
                WHEN __invoice.status='invoiced' THEN 'Invoiced' 
                ELSE 'Open' END) as status
			,__invoice.comments
        FROM purchaseorder __invoice
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        WHERE __invoice.id = __id
			and __invoice.active = 1
			and __invoice.organisation_id = __organisation_id
		order by __invoice.id desc;
	ELSEIF __id = 0 THEN
			SELECT
			__invoice.id
            ,__invoice.id as order_id
			,__organisation_id
			,__invoice.customer_id
            ,_customer.name as customer_name
            ,_customer.gstin as customer_gstin
            ,_customer.vendorcode as customer_vendor_code
            ,_customer.primaryemail as customer_email
            ,_customer.primarycontact as customer_primary_contact
            ,_customer.Address1  as address1
            ,_customer.Address2  as address2
            ,_customer.city
            ,_customer.state
            ,_customer.zip
			,__invoice.order_no
			,__invoice.order_date
			,__invoice.vendor_code
			,__invoice.amount_before_tax
            ,__invoice.inv_discount
			,__invoice.cgst
            ,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
			,__invoice.sgst
            ,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
			,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
			,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice.createdby
			,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice.updatedby
            ,(CASE WHEN __invoice.status='cancelled' THEN 'Cancelled' 
				   WHEN __invoice.status='invoiced' THEN 'Invoiced' 
                ELSE 'Open' END) as status
			,__invoice.comments  
        FROM purchaseorder __invoice
        left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
        WHERE __invoice.organisation_id = __organisation_id
			and __invoice.active = 1
        order by __invoice.id desc;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_purchaseorder_by_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_purchaseorder_by_customer`(
		IN __customerid INT
        ,IN __invoiceid varchar(500)
		,IN	__guid	varchar(1000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	IF __customerid > 0 THEN
			SELECT 
				__invoice.id
				,__invoice.id as order_id
				,__organisation_id
				,__invoice.customer_id
				,_customer.name as customer_name
				,_customer.gstin as customer_gstin
				,_customer.vendorcode as customer_vendor_code
				,_customer.primaryemail as customer_email
				,_customer.primarycontact as customer_primary_contact
				,_customer.Address1  as address1
				,_customer.Address2  as address2
				,_customer.city
				,_customer.state
				,_customer.zip
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
				,__invoice.sgst
				,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
				,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.status
				,__invoice.comments       
			FROM purchaseorder __invoice
            left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE __invoice.customer_id = __customerid
				and __invoice.active = 1
				and __invoice.organisation_id = __organisation_id
				and (__invoice.status = 'open' or __invoice.status = 'received' or __invoice.status = 'in-progress' or __invoice.status = '')
		union
			SELECT 
				__invoice.id
				,__invoice.id as order_id
				,__organisation_id
				,__invoice.customer_id
				,_customer.name as customer_name
				,_customer.gstin as customer_gstin
				,_customer.vendorcode as customer_vendor_code
				,_customer.primaryemail as customer_email
				,_customer.primarycontact as customer_primary_contact
				,_customer.Address1  as address1
				,_customer.Address2  as address2
				,_customer.city
				,_customer.state
				,_customer.zip
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.cgst
				,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
				,__invoice.sgst
				,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
				,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.status
				,__invoice.comments       
			FROM purchaseorder __invoice
			left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE __invoice.customer_id = __customerid
				and __invoice.active = 1
				and __invoice.organisation_id = __organisation_id
				and __invoice.id in (select order_id from po_invoice_mapping where invoice_id = __invoiceid and organisation_id = __organisation_id)
			order by id;
	ELSEIF __customerid = 0 THEN
				SELECT
				__invoice.id
                ,__invoice.id as order_id
				,__organisation_id
				,__invoice.customer_id
				,_customer.name as customer_name
				,_customer.gstin as customer_gstin
				,_customer.vendorcode as customer_vendor_code
				,_customer.primaryemail as customer_email
				,_customer.primarycontact as customer_primary_contact
				,_customer.Address1  as address1
				,_customer.Address2  as address2
				,_customer.city
				,_customer.state
				,_customer.zip
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.inv_discount
				,__invoice.cgst
				,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
				,__invoice.sgst
				,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
				,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.status
				,__invoice.comments  
			FROM purchaseorder __invoice
			left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE __invoice.organisation_id = __organisation_id
			and (__invoice.status = 'open' or __invoice.status = 'received' or __invoice.status = 'in-progress' or __invoice.status = '')
		union
				SELECT
				__invoice.id
                ,__invoice.id as order_id
				,__organisation_id
				,__invoice.customer_id
				,_customer.name as customer_name
				,_customer.gstin as customer_gstin
				,_customer.vendorcode as customer_vendor_code
				,_customer.primaryemail as customer_email
				,_customer.primarycontact as customer_primary_contact
				,_customer.Address1  as address1
				,_customer.Address2  as address2
				,_customer.city
				,_customer.state
				,_customer.zip
				,__invoice.order_no
				,__invoice.order_date
				,__invoice.vendor_code
				,__invoice.amount_before_tax
				,__invoice.inv_discount
				,__invoice.cgst
				,(__invoice.cgst * __invoice.amount_before_tax / 100) as cgst_amount
				,__invoice.sgst
				,(__invoice.sgst * __invoice.amount_before_tax / 100) as sgst_amount
				,__invoice.amount_before_tax + (__invoice.cgst * __invoice.amount_before_tax / 100) + (__invoice.sgst * __invoice.amount_before_tax / 100) as amount_after_tax
				,DATE_FORMAT(__invoice.createdon, '%m/%d/%Y %H:%i') as createdon
				,__invoice.createdby
				,DATE_FORMAT(__invoice.updatedon, '%m/%d/%Y %H:%i') as updatedon
				,__invoice.updatedby
				,__invoice.status
				,__invoice.comments  
			FROM purchaseorder __invoice
            left join customer _customer on _customer.id = __invoice.customer_id and _customer.organisation_id = __organisation_id
			WHERE __invoice.organisation_id = __organisation_id
			and __invoice.id in (select order_id from po_invoice_mapping where invoice_id = __invoiceid and organisation_id = __organisation_id)
        order by id desc;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_purchaseorder_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_purchaseorder_detail`(
		IN 		__purchaseorder_id INT
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
	IF __purchaseorder_id > 0 THEN
		SELECT 
			__invoice_detail.id
			,__invoice_detail.po_id
            ,__invoice_detail.product_id
			,__product.name as product_name
			,__invoice_detail.hsn_sac
            ,__invoice_detail.process as process_id
            ,__process.process_name
			,__invoice_detail.quantity
			,__invoice_detail.unit
            ,__invoice_detail.weight_kg
			,__invoice_detail.rate
			,__invoice_detail.amount
			,DATE_FORMAT(__invoice_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice_detail.createdby
			,DATE_FORMAT(__invoice_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice_detail.updatedby
			,__invoice_detail.comments        
        FROM purchaseorder_detail __invoice_detail
        join purchaseorder __invoice on __invoice.id = __invoice_detail.po_id
        left join jobservice __process on __process.id = __invoice_detail.process
        left join product __product on __product.id = __invoice_detail.product_id
        WHERE __invoice.id = __purchaseorder_id 
			and __invoice_detail.active = 1;
	ELSEIF __purchaseorder_id = 0 THEN
		SELECT 
			__invoice_detail.id
			,__invoice_detail.po_id
            ,__invoice_detail.product_id
			,__product.name as product_name
            ,__invoice_detail.process as process_id
            ,__process.process_name
			,__invoice_detail.quantity
			,__invoice_detail.unit
            ,__invoice_detail.weight_kg
			,__invoice_detail.rate
			,__invoice_detail.amount
			,DATE_FORMAT(__invoice_detail.createdon, '%m/%d/%Y %H:%i') as createdon
			,__invoice_detail.createdby
			,DATE_FORMAT(__invoice_detail.updatedon, '%m/%d/%Y %H:%i') as updatedon
			,__invoice_detail.updatedby
			,__invoice_detail.comments        
        FROM purchaseorder_detail __invoice_detail
        join purchaseorder __invoice on __invoice.id = __invoice_detail.po_id
        left join jobservice __process on __process.id = __invoice_detail.process
        left join product __product on __product.id = __invoice_detail.product_id
        WHERE __invoice_detail.active = 1;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_quotation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_quotation`(
	IN __quotation_id INT(11)
    ,IN  __guid varchar(100)
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    IF __quotation_id > 0 THEN
		SELECT
			__quotation.id
			,__quotation.organisation_id
            ,__quotation.quote_number
			,__quotation.customer_id
            ,__quotation.quote_date as quote_date_raw
            ,DATE_FORMAT(__quotation.quote_date, '%d/%m/%Y %H:%i') as quote_date
            ,__quotation.quote_valid_until as quote_valid_until_raw
            ,DATE_FORMAT(__quotation.quote_valid_until, '%d/%m/%Y %H:%i') as quote_valid_until
			,__quotation.quote_description
			,__quotation.status_id
            ,(CASE WHEN __quotation.status_id = 1 THEN 'Requested'
				WHEN __quotation.status_id = 2 THEN 'Submitted'
				WHEN __quotation.status_id = 3 THEN 'Confirmed'
				WHEN __quotation.status_id = 4 THEN 'Cancelled'
			END) as status
            ,__quotation.quote_discount
            ,__quotation.quote_cgst
            ,__quotation.quote_sgst            
			,__quotation.createdon
			,__quotation.createdby
			,__quotation.updatedon
			,__quotation.updatedby
			,__quotation.comments
			,__customer.name as customer_name
            ,__customer.Address1 as address1
            ,__customer.Address2 as address2
            ,__customer.city as city
            ,__customer.state as state
            ,__customer.zip as zip
            ,__customer.primarycontact as primarycontact
            ,__customer.contactno as contactno
            ,__customer.primaryemail as primaryemail
        FROM quotation __quotation
        Left JOIN customer __customer on __customer.id = __quotation.customer_id
        WHERE __quotation.id = __quotation_id 
            and __quotation.organisation_id = __organisation_id
			and __quotation.active = 1;
    ELSEIF __quotation_id = 0 THEN
		SELECT
			__quotation.id
			,__quotation.organisation_id
            ,__quotation.quote_number
			,__quotation.customer_id
            ,__quotation.quote_date as quote_date_raw
            ,DATE_FORMAT(__quotation.quote_date, '%d/%m/%Y %H:%i') as quote_date
            ,__quotation.quote_valid_until as quote_valid_until_raw
            ,DATE_FORMAT(__quotation.quote_valid_until, '%d/%m/%Y %H:%i') as quote_valid_until
			,__quotation.quote_description
			,__quotation.status_id
            ,(CASE WHEN __quotation.status_id = 1 THEN 'Requested'
				WHEN __quotation.status_id = 2 THEN 'Submitted'
				WHEN __quotation.status_id = 3 THEN 'Confirmed'
				WHEN __quotation.status_id = 4 THEN 'Cancelled'
			END) as status
            ,__quotation.quote_discount
            ,__quotation.quote_cgst
            ,__quotation.quote_sgst            
			,__quotation.createdon
			,__quotation.createdby
			,__quotation.updatedon
			,__quotation.updatedby
			,__quotation.comments
			,__customer.name as customer_name
            ,__customer.Address1 as address1
            ,__customer.Address2 as address2
            ,__customer.city as city
            ,__customer.state as state
            ,__customer.zip as zip
            ,__customer.primarycontact as primarycontact
            ,__customer.contactno as contactno
            ,__customer.primaryemail as primaryemail
        FROM quotation __quotation
        Left JOIN customer __customer on __customer.id = __quotation.customer_id
        WHERE __quotation.organisation_id = __organisation_id
			and __quotation.active = 1;    
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_quotation_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_quotation_detail`(
	IN __quotation_detail_id INT(11)
	,IN __quotation_id INT(11)
    ,IN  __guid varchar(100)
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF __quotation_detail_id > 0 THEN
		SELECT
			__quotation.id as quotation_id
            ,__quotation_detail.id
            ,__quotation_detail.quotation_item
			,__quotation_detail.quotation_drwaing_number
			,__quotation_detail.quotation_quantity
			,__quotation_detail.quotation_unit
			,__quotation_detail.quotation_rate
			,__quotation_detail.quotation_attahment_filename
			,__quotation_detail.quotation_attahment_url
			,__quotation_detail.createdby
			,__quotation_detail.createdon
			,__quotation_detail.comments
		FROM quotation_detail __quotation_detail
        LEFT JOIN quotation __quotation on __quotation.id = __quotation_detail.quotation_id
        WHERE __quotation.id = __quotation_id 
			and __quotation_detail = __quotation_detail_id
            and __quotation.organisation_id = __organisation_id
			and __quotation.active = 1
            and __quotation_detail.active = 1;
    ELSEIF __quotation_detail_id = 0 THEN
		SELECT
			__quotation.id as quotation_id
            ,__quotation_detail.id
            ,__quotation_detail.quotation_item
			,__quotation_detail.quotation_drwaing_number
			,__quotation_detail.quotation_quantity
			,__quotation_detail.quotation_unit
			,__quotation_detail.quotation_rate
			,__quotation_detail.quotation_attahment_filename
			,__quotation_detail.quotation_attahment_url
			,__quotation_detail.createdby
			,__quotation_detail.createdon
			,__quotation_detail.comments
		FROM quotation_detail __quotation_detail
        LEFT JOIN quotation __quotation on __quotation.id = __quotation_detail.quotation_id
        WHERE __quotation.id = __quotation_id 
            and __quotation.organisation_id = __organisation_id
			and __quotation.active = 1
            and __quotation_detail.active = 1;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_transfer_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_transfer_history`(
	IN __guid varchar(100),
    IN __history_date varchar(30)
)
BEGIN
    DECLARE __clinic_id INT(11);
    
    select id into __clinic_id from clinic where unique_id = __guid;
    
    IF length(__history_date) > 0 THEN
		select 
			clinic_id,
            date_format(start_date_time, '%m/%d/%Y %H:%i') as start_date_time,
            date_format(end_date_time, '%m/%d/%Y %H:%i') as end_date_time,
            duration,
            date_format(updatedon, '%m/%d/%Y %H:%i') as updatedon,
            updatedby
		from data_transfer_history
        where clinic_id = __clinic_id
			and date(start_date_time) = date(__history_date);
	ELSE
		select 
			clinic_id,
            date_format(start_date_time, '%m/%d/%Y %H:%i') as start_date_time,
            date_format(end_date_time, '%m/%d/%Y %H:%i') as end_date_time,
            duration,
            date_format(updatedon, '%m/%d/%Y %H:%i') as updatedon,
            updatedby
		from data_transfer_history
        where clinic_id = __clinic_id;
			
    END IF;
    
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_transfer_hostory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_transfer_hostory`(
	IN __guid varchar(100),
    IN __history_date varchar(30)
)
BEGIN
    DECLARE __temPatNum bigint(20);
    DECLARE __clinic_id INT(11);
    
    select id into __clinic_id from clinic where guid = __guid;
    
    IF length(__history_date) > 0 THEN
		select 
			clinic_id,
            start_date_time,
            end_date_time,
            duration,
            updatedon,
            updatedby
		from data_transfer_history
        where id = __clinic_id
			and date(start_date_time) = date(__history_date);
	ELSE
		select 
			clinic_id,
            start_date_time,
            end_date_time,
            duration,
            updatedon,
            updatedby
		from data_transfer_history
        where id = __clinic_id;
			
    END IF;
    
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_treatplanattach_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_treatplanattach_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".treatplanattach limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_get_treatplan_original` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_get_treatplan_original`(
    IN __updated_after varchar(30),
    IN  __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
    set @sQLStmt = CONCAT("select * from ", __opendentalDB, ".treatplan limit 5");
   
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;	
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hygiene_appointment_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_hygiene_appointment_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
  
	IF(NOT isnull(__reportStartDate)) then
       
		set @sQLStmt = CONCAT("SELECT 
					A.PatNum as 'patient_id'
                    ,A.hygiene_app as 'hygiene_app'
					,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
					,pat.PatStatus as patstatus
					,CASE
						when pat.PatStatus = 0 then 'Active'
						when pat.PatStatus = 1 then 'Non Patient'
						when pat.PatStatus = 2 then 'Inactive'
						when pat.PatStatus = 3 then 'Archived'
						when pat.PatStatus = 4 then 'Deleted'
						when pat.PatStatus = 5 then 'Deceased'
						when pat.PatStatus = 6 then 'Prospective'
					END as patient_status
					,pat.Gender as gender
					,CASE 
						WHEN pat.gender = 0 then 'Male'
						WHEN pat.gender = 1 then 'Female'
						WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'          
					,pat.Position as position
					,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
					,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
					,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
					,pat.Address as address
					,pat.Address2 as address2
					,pat.City as city
					,pat.State as state
					,pat.Zip as zip    
					,pat.wirelessphone as cell
					,pat.HmPhone as homephone
					,pat.WkPhone as workphone
					,pat.Email as email
					,TxtMsgOk as sendtext
					,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
					/* ,DATE_FORMAT(A.ProcDate, '%m/%d/%Y') AS lastvisit*/
				from
					(
						select distinct pl.PatNum, 'C' as hygiene_app
						FROM ", __opendentalDB, ".jd_procedurelog pl
						LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum and pc.clinic_id = ", __clinic_id, "
						LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum and ap.clinic_id = ", __clinic_id, "
						INNER JOIN ", __opendentalDB, ".jd_provider pv ON pl.ProvNum=pv.ProvNum and pv.clinic_id = ", __clinic_id, "
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') AND
							pc.IsHygiene = 1
                            and pl.clinic_id = ", __clinic_id, "
						UNION ALL
						select distinct pl.PatNum, 'O' as hygiene_app
						FROM ", __opendentalDB, ".jd_procedurelog pl
						LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum and pc.clinic_id = ", __clinic_id, "
						LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum and ap.clinic_id = ", __clinic_id, "
						INNER JOIN ", __opendentalDB, ".jd_provider pv ON pl.ProvNum=pv.ProvNum and pv.clinic_id = ", __clinic_id, "
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) < DATE('",__reportStartDate,"') AND
							pc.IsHygiene = 1
                            and pl.clinic_id = ", __clinic_id, "
                            
                    )A
				INNER JOIN ", __opendentalDB, ".jd_patient pat on pat.PatNum = A.PatNum
                ORDER BY pat.FName, pat.LName ASC
				");      
		
        /*
					(
						select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate, 'C' as hygiene_app
						FROM ", __opendentalDB, ".jd_procedurelog pl
						LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum
						LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum
						INNER JOIN ", __opendentalDB, ".jd_provider pv ON pl.ProvNum=pv.ProvNum
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') AND
							pc.IsHygiene = 1
							GROUP BY pl.PatNum
							HAVING MAX(pl.ProcDate)
						UNION ALL
						select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate , 'O' as hygiene_app
						FROM ", __opendentalDB, ".jd_procedurelog pl
						LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum
						LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum
						INNER JOIN ", __opendentalDB, ".jd_provider pv ON pl.ProvNum=pv.ProvNum
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) < DATE('",__reportStartDate,"') AND
							pc.IsHygiene = 1
							GROUP BY pl.PatNum
							HAVING MAX(pl.ProcDate)     
                    )A        
        */
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		select '0' as patient_id, '' as hygiene_type;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hygiene_unscheduled_patients_detail_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_hygiene_unscheduled_patients_detail_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
					SELECT 
						pat.PatNum as patient_id,
						CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name,
						pat.Email as email
						,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
						,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
						,pat.Address as address
						,pat.Address2 as address2
						,pat.City as city
						,pat.State as state
						,pat.Zip as zip                        
						,pat.wirelessphone as cell
						,pat.HmPhone as homephone
						,pat.WkPhone as workphone
						,pat.TxtMsgOk as sendtext
						,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,pat.Gender as gender
						,CASE 
							WHEN pat.gender = 0 then 'Male'
							WHEN pat.gender = 1 then 'Female'
							WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'                           
                        /* ,DATE_FORMAT((A.ProcDate),'%m/%d/%Y') AS 'LastVisit' */
                    FROM
                    (
						select distinct pl.PatNum
						FROM ", __opendentalDB, ".jd_procedurelog pl
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) < (DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
                             AND pl.clinic_id = ", __clinic_id, "
					) A
                    
					/*
                    (
						select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate -- , pl.AptNum, 
						FROM ", __opendentalDB, ".jd_procedurelog pl
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) < (DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
							GROUP BY pl.PatNum
							HAVING MAX(pl.ProcDate)
					) A
                    */
                    /*
					(	select distinct plm.PatNum, MAX(plm.ProcDate) ProcDate FROM ", __opendentalDB, ".jd_procedurelog plm where plm.PatNum in (
							select distinct pl.PatNum 
							FROM ", __opendentalDB, ".jd_procedurelog pl
							LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum
							LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum
							WHERE 
								pl.ProcStatus=2 AND 
								pc.IsHygiene = 1
								GROUP BY pl.PatNum
								HAVING (MAX(pl.ProcDate) < DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
								order by pl.AptNum, pl.ProcDate
							)
							AND plm.PatNum not in 
							(
								select distinct pln.PatNum
								FROM ", __opendentalDB, ".jd_procedurelog pln
								LEFT JOIN ", __opendentalDB, ".jd_procedurecode pcn ON pln.CodeNum= pcn.CodeNum
								WHERE DATE(pln.ProcDate) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') AND
								pcn.IsHygiene = 1
							)
							GROUP BY plm.PatNum
							HAVING (MAX(plm.ProcDate)<=DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
					)A         */      
                    INNER JOIN ", __opendentalDB, ".jd_patient pat on pat.PatNum = A.PatNum  AND pat.clinic_id = ", __clinic_id, "
						ORDER BY pat.FName, pat.LName ASC");
			
        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SELECT 0 as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_hygiene_visits_patients_detail_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_hygiene_visits_patients_detail_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
					SELECT 
						pat.PatNum as patient_id,
						CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name,
						pat.Email as email
						,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
						,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
						,pat.Address as address
						,pat.Address2 as address2
						,pat.City as city
						,pat.State as state
						,pat.Zip as zip                        
						,pat.wirelessphone as cell
						,pat.HmPhone as homephone
						,pat.WkPhone as workphone
						,pat.TxtMsgOk as sendtext
						,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,pat.Gender as gender
						,CASE 
							WHEN pat.gender = 0 then 'Male'
							WHEN pat.gender = 1 then 'Female'
							WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'                           
                        /*,DATE_FORMAT((A.ProcDate),'%m/%d/%Y') AS 'lastvisit'*/
                    FROM
						(
							select distinct pl.PatNum
							FROM ", __opendentalDB, ".jd_procedurelog pl
							LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum AND pc.clinic_id = ", __clinic_id, "
							LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum AND ap.clinic_id = ", __clinic_id, "
							WHERE 
								pl.ProcStatus=2 AND 
								DATE(pl.ProcDate) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') 
                                AND pc.IsHygiene = 1
                                AND pl.clinic_id = ", __clinic_id, "
							) A
                        INNER JOIN ", __opendentalDB, ".jd_patient pat ON pat.PatNum = A.PatNum AND pat.clinic_id = ", __clinic_id, "
                        ORDER BY pat.FName, pat.LName ASC");
			
			/*
							(
							select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate -- , pl.AptNum, 
							FROM ", __opendentalDB, ".jd_procedurelog pl
							LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum
							LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum
							WHERE 
								pl.ProcStatus=2 AND 
								DATE(pl.ProcDate) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') AND
								pc.IsHygiene = 1
								GROUP BY pl.PatNum
								HAVING MAX(pl.ProcDate)
								order by pl.AptNum, pl.ProcDate
							) A
            */
        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SELECT 0 as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_insertlogger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_insertlogger`(
    IN  __clinicId INT
	,IN  __logtimestamp varchar(30)
    ,IN  __loglevel varchar(20)
    ,IN  __logmessage text
    ,IN  __createdon varchar(30)
    ,IN  __createdby INT   
)
BEGIN
	insert into logger (
		clinic_id
		,logtimestamp
		,loglevel
		,logmessage
		,createdon
		,createdby
    ) values (
		__clinicId
		,__logtimestamp
		,__loglevel
		,__logmessage
		,__createdon
		,__createdby
    );
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_lost_patients_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_lost_patients_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
    DECLARE sQLStmt TEXT;
  	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
       
		set @sQLStmt = CONCAT("
				SELECT pat.PatNum as patient_id
					,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
					,pat.PatStatus as patstatus
					,pat.Gender as gender
					,CASE 
						WHEN pat.gender = 0 then 'Male'
						WHEN pat.gender = 1 then 'Female'
						WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'          
					,pat.Position as position
					,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
					,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
					,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
					,pat.Address as address
					,pat.Address2 as address2
					,pat.City as city
					,pat.State as state
					,pat.wirelessphone as cell
					,pat.HmPhone as homephone
					,pat.WkPhone as workphone
					,pat.Email as email
					,TxtMsgOk as sendtext
					,pat.Zip as zip    
					,(CASE WHEN pat.PatStatus= 0 THEN 'Active'
						 WHEN pat.PatStatus IN  (1,2,3,4,5,6) THEN 'Inactive' END) AS 'patient_status'
					,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
					,DATE_FORMAT(procedurelog.ProcDate, '%m/%d/%Y') AS lastvisit
                    ,DATE_FORMAT(lastProc.LastProcDate, '%m/%d/%Y') AS lastProcDate
					FROM ", __opendentalDB, ".jd_patient pat
					INNER JOIN ", __opendentalDB, ".jd_procedurelog procedurelog ON procedurelog.PatNum = pat.PatNum and procedurelog.clinic_id = ", __clinic_id, "
					INNER JOIN (
						SELECT PatNum, MAX(ProcDate) AS LastProcDate
						FROM ", __opendentalDB, ".jd_procedurelog procedurelog
						WHERE procedurelog.ProcStatus=2
						AND procedurelog.ProcDate >= DATE('",__reportStartDate,"') - INTERVAL 2 YEAR
                        and procedurelog.clinic_id = ", __clinic_id, "
						GROUP BY PatNum
					) lastProc ON lastProc.PatNum=pat.PatNum AND lastProc.LastProcDate = procedurelog.ProcDate
					WHERE procedurelog.ProcDate BETWEEN DATE('",__reportStartDate,"') - INTERVAL 2 YEAR  AND DATE('",__reportEndDate,"') - INTERVAL 2 YEAR
					AND procedurelog.ProcStatus=2
                    and pat.clinic_id = ", __clinic_id, "
					GROUP BY procedurelog.PatNum");      
		
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		select '0' as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_new_patients_detail_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_new_patients_detail_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
					SELECT 
						pat.PatNum as patient_id,
						CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name,
						A.ProcDate as procDate, 
						pat.Email as email
						,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
						,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
						,pat.Address as address
						,pat.Address2 as address2
						,pat.City as city
						,pat.State as state
						,pat.Zip as zip                        
						,pat.wirelessphone as cell
						,pat.HmPhone as homephone
						,pat.WkPhone as workphone
						,pat.TxtMsgOk as sendtext
						,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,DATE_FORMAT(A.ProcDate, '%m/%d/%Y') AS lastvisit
						,pat.Gender as gender
						,CASE 
							WHEN pat.gender = 0 then 'Male'
							WHEN pat.gender = 1 then 'Female'
							WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'                          
                    FROM
                    (SELECT pat.PatNum, pat.DateFirstVisit, proc.ProcDate
						FROM ", __opendentalDB, ".jd_patient pat, ", __opendentalDB, ".jd_procedurelog proc
						WHERE proc.PatNum = pat.PatNum 
						AND pat.patstatus = '0' 
						AND proc.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') 
						AND proc.ProcStatus=2 
						AND pat.DateFirstVisit >= DATE_ADD('",__reportStartDate,"', INTERVAL -7 day) 
						AND proc.ProcFee > 0 
                        and pat.clinic_id = ", __clinic_id, "
                        and proc.clinic_id = ", __clinic_id, "
						GROUP BY pat.PatNum 
						ORDER BY pat.DateFirstVisit)A
					JOIN ", __opendentalDB, ".jd_patient pat on A.PatNum = pat.PatNum
                    ");
			
        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SELECT 0 as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_operatory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_operatory`(
	IN __guid varchar(100),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT; -- ", __opendentalDB, ".
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);


    if __opendentalDB = '' or isnull(__opendentalDB) then
		select 'error' as type, 'Invalid database name' as message;
    end if;

	set @sQLStmt = CONCAT("select 
						_operatory.OperatoryNum as operatoryNum
						,_operatory.OpName as opName
						,_operatory.Abbrev as abbrev
						,_operatory.ItemOrder as itemOrder
						,_operatory.IsHidden as isHidden
						,_operatory.ProvDentist as provDentist
						,_operatory.ProvHygienist as provHygienist
						,_operatory.IsHygiene as isHygiene
						,_operatory.ClinicNum as clinicNum
						,_operatory.DateTStamp as dateTStamp
						,_operatory.SetProspective as setProspective
						,_operatory.IsWebSched as isWebSched
						,_operatory.IsNewPatAppt as isNewPatAppt
						from ", __opendentalDB, ".jd_operatory _operatory
                        where _operatory.IsHidden = 0 
							and _operatory.clinic_id = ", __clinic_id, "
                        order by ItemOrder");
	PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
		select 
			(SELECT COUNT(DISTINCT p.PatNum) FROM ", __opendentalDB, ".jd_patient p WHERE  p.PatStatus=0 and p.clinic_id = ", __clinic_id, ") as 'active_patients',
            (SELECT COUNT(DISTINCT p.PatNum) AS 'Patients' FROM ", __opendentalDB, ".jd_patient p WHERE  p.PatStatus=0 and DATE(p.SecDateEntry) < DATE('",__reportStartDate,"')  and p.clinic_id = ", __clinic_id, ") as 'active_patients_tilldate',
			(SELECT count(*) 
				FROM(
					SELECT patient.PatNum, patient.DateFirstVisit
					FROM ", __opendentalDB, ".jd_patient patient, ", __opendentalDB, ".jd_procedurelog procedurelog 
					WHERE procedurelog.PatNum = patient.PatNum 
					AND patient.patstatus = '0' 
					AND procedurelog.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') 
					AND procedurelog.ProcStatus=2 
					AND patient.DateFirstVisit >= DATE_ADD('",__reportStartDate,"', INTERVAL -7 day) 
					AND procedurelog.ProcFee > 0 
                    AND patient.clinic_id = ", __clinic_id, "
                    AND procedurelog.clinic_id = ", __clinic_id, "
					GROUP BY patient.PatNum 
					ORDER BY patient.DateFirstVisit
				)A) as new_patient_count,
			(SELECT count(*) 
				FROM(
					SELECT patient.PatNum, patient.DateFirstVisit
					FROM ", __opendentalDB, ".jd_patient patient, ", __opendentalDB, ".jd_procedurelog procedurelog 
					WHERE procedurelog.PatNum = patient.PatNum 
					AND patient.patstatus = '0' 
					AND procedurelog.ProcDate BETWEEN DATE_ADD('",__reportStartDate,"', INTERVAL -1 YEAR) and DATE_ADD('",__reportEndDate,"', INTERVAL -1 YEAR) 
					AND procedurelog.ProcStatus=2 
					AND patient.DateFirstVisit >= DATE('",__reportStartDate,"') 
					AND procedurelog.ProcFee > 0 
                    AND patient.clinic_id = ", __clinic_id, "
                    AND procedurelog.clinic_id = ", __clinic_id, "
					GROUP BY patient.PatNum 
					ORDER BY patient.DateFirstVisit
				)A) as new_patient_count_previous,
			(select count(*) from ", __opendentalDB, ".jd_patient _patient where DATE(_patient.DateFirstVisit) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')) as new_patient_visit_count,
			(select count(*) from ", __opendentalDB, ".jd_patient _patient where DATE(_patient.DateFirstVisit) between DATE_ADD('",__reportStartDate,"', interval -1 year) and DATE_ADD('",__reportEndDate,"', INTERVAL -1 year)) as new_patient_visit_count_previous,
			(select count(*) from (select distinct _appointment.Patnum from ", __opendentalDB, ".jd_appointment _appointment where DATE(_appointment.AptDateTime) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') ) A ) as new_appointment_count,
			(select count(*) from (select distinct _appointment.Patnum from ", __opendentalDB, ".jd_appointment _appointment where DATE(_appointment.AptDateTime) between DATE_ADD('",__reportStartDate,"', interval -1 year) and DATE_ADD('",__reportEndDate,"', INTERVAL -1 year) ) A ) as new_appointment_count_previous
            ");
			
        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SET temp_status_id = 0;
    END IF;
    -- select DATE(__reportStartDate), DATE(__reportEndDate), DATE_ADD(__reportStartDate, INTERVAL -7 day), DATE_ADD(__reportStartDate, INTERVAL -1 day);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_dashboard_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_dashboard_details`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
					select  pat.PatNum as patient_id
							,pat.FName as firstName
							,pat.LName as lastName
							,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
							,pat.PatStatus as patstatus
							,CASE
								when pat.PatStatus = 0 then 'Active'
								when pat.PatStatus = 1 then 'Non Patient'
								when pat.PatStatus = 2 then 'Inactive'
								when pat.PatStatus = 3 then 'Archived'
								when pat.PatStatus = 4 then 'Deleted'
								when pat.PatStatus = 5 then 'Deceased'
								when pat.PatStatus = 6 then 'Prospective'
							END as patient_status
							,pat.Gender as gender
							,CASE 
								WHEN pat.gender = 0 then 'Male'
								WHEN pat.gender = 1 then 'Female'
								WHEN pat.gender = 2 then 'Unknown'
								END as 'gendertext'          
							,pat.Position as position
							,pat.Birthdate as dob
							,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
							,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
							,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
							,pat.Address as address
							,pat.Address2 as address2
							,pat.City as city
							,pat.State as state
							,pat.wirelessphone as cell
							,pat.HmPhone as homephone
							,pat.WkPhone as workphone
							,pat.Email as email
							,TxtMsgOk as sendtext
							,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
							,pat.Zip as zip
							from ", __opendentalDB, ".jd_patient pat
							WHERE pat.DateFirstVisit >= DATE_ADD('",__reportStartDate,"', INTERVAL -7 day)
							AND pat.patstatus = '0'
                            AND pat.clinic_id = ", __clinic_id, "
							AND pat.PatNum in (
								select procedurelog.PatNum 
								from ", __opendentalDB, ".jd_procedurelog procedurelog
								WHERE procedurelog.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') 
								AND procedurelog.ProcStatus=2 
								AND procedurelog.ProcFee > 0
                                AND procedurelog.clinic_id = ", __clinic_id, "
							)");

		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt;                    
	ELSE
		SET temp_status_id = 0;
    END IF;
    -- select DATE(__reportStartDate), DATE(__reportEndDate), DATE_ADD(__reportStartDate, INTERVAL -7 day), DATE_ADD(__reportStartDate, INTERVAL -1 day);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_family_relationship` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_family_relationship`(
	IN __guid varchar(100),
	IN  __patient_id INT,
    IN __opendentalDB CHAR(100)

)
BEGIN
    -- DECLARE EXIT HANDLER FOR 1062 SELECT 'error' as type, 'Duplicate keys error encountered' Messn
    DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

    if __patient_id <= 0 then
		select 'error' as type, 'Invalid patient id' as message;
    end if;

    set @sQLStmt = CONCAT("select 
		_pat.PatNum patient_id
		,CONCAT(_pat.FName, ' ', IFNULL(CONCAT(_pat.MiddleI, ' '),''), _pat.LName) as patient_name
		,_pat.Guarantor guarantor
		,_pat.Position position
		,CASE 
			WHEN _pat.Position = 0 then 'Single'
			WHEN _pat.Position = 1 then 'Married'
			WHEN _pat.Position = 2 then 'Child'
			WHEN _pat.Position = 3 then 'Widowed'
			WHEN _pat.Position = 4 then 'Divorced'
		END as 'position_text'
		,CASE 
			WHEN _pat.gender = 0 then 'Male'
			WHEN _pat.gender = 1 then 'Female'
			WHEN _pat.gender = 2 then 'Unknown'
		END as 'gender_text'
		,_pat.PatStatus 
		,CASE
			when _pat.PatStatus = 0 then 'Patient'
			when _pat.PatStatus = 1 then 'Non Patient'
			when _pat.PatStatus = 2 then 'Inactive'
			when _pat.PatStatus = 3 then 'Archived'
			when _pat.PatStatus = 4 then 'Deleted'
			when _pat.PatStatus = 5 then 'Deceased'
			when _pat.PatStatus = 6 then 'Prospective'
		END as patient_status
		,DATE_FORMAT(_pat.Birthdate, '%m/%d/%Y') AS birth_date
		,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), _pat.Birthdate)), '%Y')+0 AS age
        ,_pat.clinic_id
		from ", __opendentalDB, ".jd_patient _pat 
		where _pat.Guarantor in (select pat.Guarantor from ", __opendentalDB, ".jd_patient pat where pat.PatNum = ", __patient_id, " and pat.clinic_id = ", __clinic_id, ")
        and _pat.clinic_id = ", __clinic_id);
    PREPARE Stmt FROM @sQLStmt;
    EXECUTE Stmt;
    DEALLOCATE PREPARE Stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_recent_activity` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_recent_activity`(
	IN __guid varchar(100),
	IN  __patient_id INT
)
BEGIN
    
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);


	select 
		_activity.id
		,_activity.patient_id
		,_activity.activity_type_id
		,_activity_type.name as activity_type_name
		,_activity.act_datetime
		,_activity.act_role
		,_activity.act_description
		,_activity.act_other
		,_activity.user_id
		,_activity.createdon
		,_activity.createdby
		from activity _activity
		left join activity_type _activity_type on _activity_type.id = _activity.activity_type_id
		where _activity.active = 1 
		and _activity.patient_id = __patient_id
			and clinic_id = __clinic_id
		order by _activity.act_datetime desc limit 10;
	 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_statistics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_statistics`(
	IN __guid varchar(100),
	IN __patient_id INT,
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

    if __patient_id <= 0 then
		select 'error' as type, 'Invalid patient id' as message;
    end if;

	set @sQLStmt = CONCAT("select pat.PatNum as patient_id
		,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
        ,round(ifnull(pat.EstBalance, 0), 0) as patient_estimated_balance
        ,round(ifnull(pat.InsEst, 0), 0) as insurance_estimation
        ,(select round(ifnull(sum(proclog.ProcFee), 0), 0) from ", __opendentalDB, ".jd_procedurelog proclog where proclog.PatNum = pat.PatNum and proclog.ProcStatus = 1 and proclog.clinic_id = ", __clinic_id, ") as tp_amount
        ,(select round(ifnull(sum(proclog.Discount), 0), 0) from ", __opendentalDB, ".jd_procedurelog proclog where proclog.PatNum = pat.PatNum and proclog.ProcStatus = 1 and proclog.clinic_id = ", __clinic_id, ") as tp_discount
        ,(select round(ifnull(sum(proclog.ProcFee - proclog.Discount), 0), 0) from ", __opendentalDB, ".jd_procedurelog proclog where proclog.PatNum = pat.PatNum and proclog.ProcStatus = 1 and proclog.clinic_id = ", __clinic_id, ") as tp_patient_balance
		,(select round(ifnull(sum(ben.MonetaryAmt), 0), 0) 
			from ", __opendentalDB, ".jd_benefit ben
			where ben.PlanNum in (select inssub.PlanNum from ", __opendentalDB, ".jd_inssub inssub where inssub.Subscriber =  pat.PatNum)
			and ben.BenefitType = 5 and ben.CoverageLevel = 1 and ben.Percent = -1 and ben.clinic_id = ", __clinic_id, ") as annual_max
		,(select round(ifnull(sum(cproc.InsPayAmt), 0), 0)
			from ", __opendentalDB, ".jd_claimproc cproc
			left join ", __opendentalDB, ".jd_inssub inssub on inssub.Subscriber = cproc.PatNum and inssub.InsSubNum = cproc.InsSubNum and  inssub.clinic_id = ", __clinic_id, "
			where cproc.status = 3 and cproc.PatNum = pat.PatNum and cproc.clinic_id = ", __clinic_id, ") as ins_used
		,(select inssub.PlanNum from ", __opendentalDB, ".jd_inssub inssub where inssub.Subscriber = pat.PatNum  and inssub.clinic_id = ", __clinic_id, ") as plan_num  
		from ", __opendentalDB, ".jd_patient pat
		where pat.PatNum = ", __patient_id, " and pat.clinic_id = ", __clinic_id);
	PREPARE Stmt FROM @SQLStmt;
    EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_patient_treatmentplan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_patient_treatmentplan`(
	IN __guid varchar(100),
	IN  __patient_id INT
)
BEGIN

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    if __patient_id <= 0 then
		select 'error' as type, 'Invalid patient id' as message;
    end if;
	
	select claim.ProcNum
		,claim.InsPayEst
		,claim.InsPayAmt
		,claim.PlanNum
		,claim.PatNum 
		,claim.InsEstTotal
		,proclog.ProcFee
		,proclog.ProcStatus
		,CASE
			WHEN proclog.ProcStatus = 1 then 'Treatment Plan'
			WHEN proclog.ProcStatus = 2 then 'Complete'
			WHEN proclog.ProcStatus = 3 then 'Existing Current Provider'
			WHEN proclog.ProcStatus = 4 then 'Existing Other Provider'
			WHEN proclog.ProcStatus = 5 then 'Referred Out'
			WHEN proclog.ProcStatus = 6 then 'Deleted'
			WHEN proclog.ProcStatus = 8 then 'TP Inactive'
		END as proc_log_status
		,proclog.CodeNum
		,procode.ProcCode
		,procode.Descript
		from jd_claimproc claim
		join procedurelog proclog on proclog.ProcNum = claim.ProcNum -- and proclog.ProcStatus = 1
		join procedurecode procode on procode.CodeNum = proclog.CodeNum 
		where claim.PatNum = __patient_id  
        and claim.clinic_id = __clinic_id order by ProcNum;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_payment_collection_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_payment_collection_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __resultType CHAR(1), /* list (L), Total (T) */
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

    
	IF(NOT isnull(__reportStartDate)) then
		IF(__resultType = 'T') THEN /*Consolidated collection*/
			set @sQLStmt = CONCAT("
				SELECT sum(A.PaymentAmt) as payment_collection FROM
				(
					SELECT paysplit.PatNum, definition.ItemName AS PaymentType, paysplit.DatePay AS 'DatePay',
					SUM(paysplit.SplitAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_payment payment, ", __opendentalDB, ".jd_definition definition, ", __opendentalDB, ".jd_paysplit paysplit
					WHERE DATE(paysplit.DatePay) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND payment.PayNum=paysplit.PayNum
					AND definition.DefNum=payment.PayType
                    AND payment.clinic_id = ", __clinic_id, "
                    AND paysplit.clinic_id = ", __clinic_id, "
                    AND definition.clinic_id = ", __clinic_id, "
					GROUP BY payment.PayType,paysplit.PatNum, paysplit.DatePay
					UNION
					SELECT PatNum, 'Ins Checks',claimproc.DateCP AS 'DatePay',SUM(claimproc.InsPayAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_claimproc claimproc
					WHERE DATE(claimproc.DateCP) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND (claimproc.Status=1 OR claimproc.Status=4)
                    AND claimproc.clinic_id = ", __clinic_id, "
					GROUP BY PatNum, DatePay
					ORDER BY DatePay, PaymentType
				)A                        ");
        ELSEIF(__resultType = 'L') THEN /*List all patient base*/
			set @sQLStmt = CONCAT("
				SELECT 
                A.PatNum as patient_id
				,CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name
				,pat.Email as email
				,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
				,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
				,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
				,pat.Address as address
				,pat.Address2 as address2
				,pat.City as city
				,pat.State as state
				,pat.Zip as zip                        
				,pat.wirelessphone as cell
				,pat.HmPhone as homephone
				,pat.WkPhone as workphone
				,pat.TxtMsgOk as sendtext
				,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit                
                ,A.PaymentType as paymentType
                ,DATE_FORMAT(A.DatePay, '%m/%d/%Y') AS payDate
                ,DATE_FORMAT(A.ProcDate, '%m/%d/%Y') AS lastvisit
                ,truncate(IFNULL(A.PaymentAmt, 0), 2) as paymentAmount
                FROM 
                (
					SELECT paysplit.PatNum, definition.ItemName AS PaymentType, paysplit.DatePay AS 'DatePay',  paysplit.DatePay AS 'ProcDate',
					SUM(paysplit.SplitAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_payment payment, ", __opendentalDB, ".jd_definition definition, ", __opendentalDB, ".jd_paysplit paysplit
					WHERE DATE(paysplit.DatePay) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND payment.PayNum=paysplit.PayNum
					AND definition.DefNum=payment.PayType
                    AND payment.clinic_id = ", __clinic_id, "
                    AND paysplit.clinic_id = ", __clinic_id, "
                    AND definition.clinic_id = ", __clinic_id, "                    
					GROUP BY payment.PayType,paysplit.PatNum, paysplit.DatePay
					UNION
					SELECT PatNum, 'Ins Checks',claimproc.DateCP AS 'DatePay', claimproc.ProcDate AS 'ProcDate', SUM(claimproc.InsPayAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_claimproc claimproc
					WHERE DATE(claimproc.DateCP) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND (claimproc.Status=1 OR claimproc.Status=4)
                    AND claimproc.clinic_id = ", __clinic_id, "
					GROUP BY PatNum, DatePay
					ORDER BY DatePay, PaymentType 
				) A
                JOIN ", __opendentalDB, ".jd_patient pat ON pat.PatNum=A.PatNum
                ORDER BY pat.FName, pat.LName
                    ");
        ELSEIF(__resultType = 'P') THEN /*group by paytype wise*/
			set @sQLStmt = CONCAT("
				SELECT 
                A.PaymentType as paymentType
                ,truncate(IFNULL(A.PaymentAmt, 0), 2) as paymentAmount
                FROM 
                (
					SELECT definition.ItemName AS PaymentType, 
					SUM(paysplit.SplitAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_payment payment, ", __opendentalDB, ".jd_definition definition, ", __opendentalDB, ".jd_paysplit paysplit
					WHERE DATE(paysplit.DatePay) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND payment.PayNum=paysplit.PayNum
					AND definition.DefNum=payment.PayType
                    AND payment.clinic_id = ", __clinic_id, "
                    AND paysplit.clinic_id = ", __clinic_id, "
                    AND definition.clinic_id = ", __clinic_id, "                       
					GROUP BY payment.PayType
					UNION
					SELECT 'Ins Checks' as PaymentType, SUM(claimproc.InsPayAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_claimproc claimproc
					WHERE DATE(claimproc.DateCP) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND (claimproc.Status=1 OR claimproc.Status=4)
                    AND claimproc.clinic_id = ", __clinic_id, "
					-- GROUP BY PaymentType 
					ORDER BY PaymentType 
				) A                    ");
        ELSEIF(__resultType = 'D') THEN /*group by pay datewise*/
			set @sQLStmt = CONCAT("
				SELECT 
                A.PaymentType as paymentType
                ,DATE_FORMAT(A.DatePay, '%m/%d/%Y') AS payDate
               ,truncate(IFNULL(A.PaymentAmt, 0), 2) as paymentAmount
                FROM 
                (
					SELECT definition.ItemName AS PaymentType, paysplit.DatePay AS 'DatePay', 
					SUM(paysplit.SplitAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_payment payment, ", __opendentalDB, ".jd_definition definition, ", __opendentalDB, ".jd_paysplit paysplit
					WHERE DATE(paysplit.DatePay) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND payment.PayNum=paysplit.PayNum
					AND definition.DefNum=payment.PayType
                    AND payment.clinic_id = ", __clinic_id, "
                    AND paysplit.clinic_id = ", __clinic_id, "
                    AND definition.clinic_id = ", __clinic_id, "                        
					GROUP BY payment.PayType, paysplit.DatePay
					UNION
					SELECT 'Ins Checks',claimproc.DateCP AS 'DatePay', SUM(claimproc.InsPayAmt) AS PaymentAmt
					FROM ", __opendentalDB, ".jd_claimproc claimproc
					WHERE DATE(claimproc.DateCP) BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND (claimproc.Status=1 OR claimproc.Status=4)
                    AND claimproc.clinic_id = ", __clinic_id, "
					GROUP BY DatePay
					ORDER BY DatePay, PaymentType 
				) A ");                
        END IF;

        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SET temp_status_id = 0;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_practice_data_dashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_practice_data_dashboard`(
	-- IN __reportDate varchar(20)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    
	-- IF(!isnull(__reportDate)) then
		select
			(select count(*)
				from user _user 
				join role _role on _role.id = _user.roleid
				where _user.active = 1 and lcase(_role.rolename) in ('general dentist', 'hygienist', 'orthodontist', 'pediatric dentist')) as dentist_count,
			(select count(*) 
				from user _user 
				join role _role on _role.id = _user.roleid
				where _user.active = 1 and lcase(_role.rolename) in ('dental assistant', 'hygiene assistant', 'hygiene coordinator', 'treatment coordinator')) as nurse_count;		
	-- ELSE
	-- 	SET temp_status_id = 0;
    -- END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_production_by_date_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_production_by_date_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
        set @sQLStmt = CONCAT("    
			SELECT Trans.TransDate AS 'prodDate',
				SUM(CASE WHEN Trans.TranType='Prod' THEN Trans.TranAmount WHEN Trans.TranType='Cap' THEN Trans.Writeoff ELSE 0 END) AS production_,
				SUM(CASE WHEN Trans.TranType='Adj' THEN Trans.TranAmount ELSE 0 END) AS adjustment_,
				SUM(CASE WHEN Trans.TranType='Writeoff' THEN Trans.Writeoff ELSE 0 END) AS writeoff_,
				SUM(CASE WHEN Trans.TranType IN('Prod','Adj') THEN Trans.TranAmount WHEN Trans.TranType IN('Writeoff','Cap') THEN Trans.Writeoff ELSE 0 END) AS netProd_,
				SUM(CASE WHEN Trans.TranType='PatPay' THEN Trans.TranAmount ELSE 0 END) AS patIncome_,
				SUM(CASE WHEN Trans.TranType IN('InsPay') THEN Trans.TranAmount ELSE 0 END) AS insIncome_,
				SUM(CASE WHEN Trans.TranType IN('PatPay','InsPay') THEN Trans.TranAmount ELSE 0 END) AS totalIncome_
				FROM (
					/*Prod*/
					SELECT 'Prod' AS TranType,pl.ProvNum, truncate(pl.ProcFee*(pl.UnitQty+pl.BaseUnits), 2) AS TranAmount,0 AS Writeoff, pl.ProcDate AS TransDate
					FROM ", __opendentalDB, ".jd_procedurelog pl
					INNER JOIN ", __opendentalDB, ".jd_procedurecode pc ON pc.CodeNum=pl.CodeNum AND pc.ProcCode NOT LIKE '99___'
					WHERE pl.ProcStatus=2
					AND pl.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
                    AND pl.clinic_id = ", __clinic_id, "
					UNION ALL
					/*Adj*/
					SELECT 'Adj' AS TranType,a.ProvNum, truncate(a.AdjAmt, 2) AS TranAmount,0 AS Writeoff, a.AdjDate AS TransDate
					FROM ", __opendentalDB, ".jd_adjustment a
					WHERE a.AdjDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
                    AND a.clinic_id = ", __clinic_id, "
					UNION ALL
					/*PatInc*/
					SELECT 'PatPay' AS TranType,ps.ProvNum, truncate(ps.SplitAmt, 2) AS TranAmount,0 AS Writeoff,ps.DatePay AS TransDate
					FROM ", __opendentalDB, ".jd_paysplit ps
					WHERE ps.IsDiscount=0 
					AND ps.DatePay BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
                    AND ps.clinic_id = ", __clinic_id, "
					UNION ALL
					/*InsIncome*/
					SELECT 'InsPay' AS TranType,cp.ProvNum, truncate(cp.InsPayAmt, 2) AS TranAmount,0,cp.DateCP AS TransDate
					FROM ", __opendentalDB, ".jd_claimproc cp
					INNER JOIN ", __opendentalDB, ".jd_procedurelog pl ON cp.ProcNum=pl.ProcNum AND pl.clinic_id = ", __clinic_id, "
					INNER JOIN ", __opendentalDB, ".jd_procedurecode pc ON pc.CodeNum=pl.CodeNum AND pc.ProcCode NOT LIKE '99___' AND pc.clinic_id = ", __clinic_id, "
					INNER JOIN ", __opendentalDB, ".jd_claimpayment cpm ON cp.ClaimPaymentNum=cpm.ClaimPaymentNum AND cpm.clinic_id = ", __clinic_id, "
					WHERE cp.DateCP BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND cp.Status IN(1,4)
                    AND cp.clinic_id = ", __clinic_id, "
					UNION ALL
					/*Writeoff*/
					SELECT 'Writeoff' AS TranType,cp.ProvNum,0 AS TranAmount, truncate(-cp.WriteOff, 2) AS Writeoff, cp.DateCP AS TransDate
					FROM ", __opendentalDB, ".jd_claimproc cp
					INNER JOIN ", __opendentalDB, ".jd_procedurelog pl ON cp.ProcNum=pl.ProcNum AND pl.clinic_id = ", __clinic_id, "
					INNER JOIN ", __opendentalDB, ".jd_procedurecode pc ON pc.CodeNum=pl.CodeNum AND pc.ProcCode NOT LIKE '99___' AND pc.clinic_id = ", __clinic_id, "
					WHERE cp.DateCP BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
					AND cp.Status IN(1,4)
                    AND cp.clinic_id = ", __clinic_id, "
					UNION ALL
					/*Capitation*/
					SELECT 'Cap' AS TranType,cp.ProvNum, truncate(cp.InsPayAmt, 2) AS TranAmount, truncate(-cp.Writeoff, 2) AS Writeoff,cp.DateCP AS TransDate
					FROM ", __opendentalDB, ".jd_claimproc cp
					INNER JOIN ", __opendentalDB, ".jd_procedurelog pl ON cp.ProcNum=pl.ProcNum AND pl.clinic_id = ", __clinic_id, "
					INNER JOIN ", __opendentalDB, ".jd_procedurecode pc ON pc.CodeNum=pl.CodeNum AND pc.ProcCode NOT LIKE '99___' AND pc.clinic_id = ", __clinic_id, "
					WHERE cp.Status=7
					AND cp.DateCP BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
                    AND cp.clinic_id = ", __clinic_id, "
				) Trans
				GROUP BY Trans.TransDate
				ORDER BY Trans.TransDate");

        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SET temp_status_id = 0;
    END IF;
    -- select DATE(__reportStartDate), DATE(__reportEndDate), DATE_ADD(__reportStartDate, INTERVAL -7 day), DATE_ADD(__reportStartDate, INTERVAL -1 day);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_reactivated_patients_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_reactivated_patients_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
    DECLARE sQLStmt TEXT;
  	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

	IF(NOT isnull(__reportStartDate)) then
       
		set @sQLStmt = CONCAT("
					SELECT p.PatNum as patient_id,
						CONCAT(p.FName, ' ', IFNULL(CONCAT(p.MiddleI, ' '),''), p.LName) as patient_name,
						a.ProcDate as procDate, 
						a.AptDateTime as aptDateTime, 
						a.ExamDate as examDate, 
						a.D0150,
						p.Email as email
						,DATE_FORMAT(p.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), p.Birthdate)), '%Y')+0 AS age
						,CONCAT(p.Address, ' ', IFNULL(CONCAT(p.Address2, ' '),''), p.City, ' ', p.State, ' ', p.Zip) as patient_address
						,p.Address as address
						,p.Address2 as address2
						,p.City as city
						,p.State as state
						,p.wirelessphone as cell
						,p.HmPhone as homephone
						,p.WkPhone as workphone
						,TxtMsgOk as sendtext
						,DATE_FORMAT(p.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,p.Zip as zip    
						,p.Gender as gender
						,CASE 
							WHEN p.gender = 0 then 'Male'
							WHEN p.gender = 1 then 'Female'
							WHEN p.gender = 2 then 'Unknown'
						END as 'gendertext'                          
						,SUM(
							CASE WHEN pl.DateTP = a.ExamDate 
							THEN pl.ProcFee * (pl.BaseUnits + pl.UnitQty) 
							ELSE 0 
						END) AS 'treatmentAmt',
						SUM(
							CASE WHEN pl.DateTP = a.ExamDate AND pl.ProcDate BETWEEN a.ExamDate AND (a.ExamDate + INTERVAL 30 DAY) 
								AND pl.ProcStatus = 2 
							THEN pl.ProcFee * (pl.BaseUnits + pl.UnitQty) 
							ELSE 0 
						END) AS 'treatmentCompleted',
						DATE_FORMAT(a.AptDateTime, '%m/%d/%Y') AS lastvisit,
						a.* from
						(select 
							newpat.PatNum, 
							newpat.AptDateTime,
							newpat.ReactDate AS ProcDate,
							MIN(exams.ProcDate) AS 'ExamDate',
							MAX(CASE WHEN exams.ProcCode = 'D0150'  AND exams.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') THEN exams.ProcDate ELSE NULL END) AS 'D0150'
							,newpat.PatNum as __patient_id
							,newpat.ProcDate as __procDate
							,newpat.oldPat
							,newpat.reactDate
							from
							(SELECT pl.PatNum, 
								MIN(apt.AptDateTime) as AptDateTime, 
								MIN(pl.ProcDate) as ProcDate, 
								MAX(CASE WHEN pl.ProcDate < DATE('",__reportStartDate,"')  THEN pl.ProcDate END) AS oldPat,
								MIN(CASE WHEN pl.ProcDate BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"') THEN pl.ProcDate END) AS reactDate
								FROM ", __opendentalDB, ".jd_procedurelog pl
								INNER JOIN ", __opendentalDB, ".jd_procedurecode plc 
									ON plc.CodeNum = pl.CodeNum
                                    and plc.clinic_id = ", __clinic_id, "
									/*AND plc.ProcCode NOT REGEXP @ExcludedCodes*/
								LEFT JOIN ", __opendentalDB, ".jd_appointment apt 
									ON pl.AptNum = apt.AptNum
                                    and apt.clinic_id = ", __clinic_id, "
								WHERE pl.ProcStatus = 2 /*Complete*/
								AND pl.ProcDate <= DATE('",__reportEndDate,"')
                                and pl.clinic_id = ", __clinic_id, "
								GROUP BY pl.PatNum
								HAVING (DATE_FORMAT(OldPat, '%Y-%m') <= DATE_FORMAT('",__reportStartDate,"' - INTERVAL 2 YEAR, '%Y-%m') 
									AND ReactDate IS NOT NULL/*Seen over 2 years ago, but has completed proc in date range*/)
								ORDER BY NULL) newpat
								LEFT JOIN (
									SELECT  pl.PatNum,
									pl.ProcDate,
									pc.ProcCode
									FROM ", __opendentalDB, ".jd_procedurelog pl 
									INNER JOIN ", __opendentalDB, ".jd_procedurecode pc 
										ON pc.CodeNum = pl.CodeNum 
										-- AND pc.ProcCode REGEXP @ExamCodes /*Include exam, limited exam and consult codes*/ 
                                        and pc.clinic_id = ", __clinic_id, "
									WHERE pl.ProcStatus=2/*comp*/
									AND pl.ProcDate < DATE('",__reportEndDate,"')
                                    and pl.clinic_id = ", __clinic_id, "
								)exams
								ON exams.PatNum=newpat.PatNum  
								AND (ISNULL(newpat.oldPat) OR exams.ProcDate > newpat.oldPat)
								GROUP BY newpat.PatNum            
							)a
							INNER JOIN ", __opendentalDB, ".jd_patient p 
								ON p.PatNum = a.PatNum
								-- AND p.DateFirstVisit BETWEEN DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
								AND p.PatStatus = 0 /*Active*/
                                and p.clinic_id = ", __clinic_id, "
							LEFT JOIN ", __opendentalDB, ".jd_procedurelog pl 
								ON pl.PatNum = a.PatNum
								AND pl.DateTP = a.ExamDate
								AND pl.ProcStatus IN ('1','2') /*Treatment Planned, Complete*/
                                and pl.clinic_id = ", __clinic_id, "
							GROUP BY p.PatNum
							ORDER BY a.ExamDate        
				");      
		
        -- select @sQLStmt;
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		select '0' as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_retrieve_opendental_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_retrieve_opendental_configuration`(
	IN __guid varchar(100),
	IN __id INT,
    IN __account_id INT
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0) THEN
		select 
		oc.id
        ,oc.account_id
		,oc.clinic_id
		,oc.image_path
		,oc.review_url
		,oc.feedback_url
		,oc.website_url
		,oc.microsite_url
		,oc.other1_url
		,oc.other2_url
		from opendental_configuration oc
		where oc.clinic_id = __clinic_id
		and oc.active = 1 limit 1;
    ELSE
		select 
		oc.id
		,oc.account_id
		,oc.clinic_id
		,oc.image_path
		,oc.review_url
		,oc.feedback_url
		,oc.website_url
		,oc.microsite_url
		,oc.other1_url
		,oc.other2_url
		from opendental_configuration oc
		where oc.id = __id 
        and oc.clinic_id = __clinic_id
		and oc.active = 1;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_retrieve_template` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_retrieve_template`(
	IN __guid varchar(100),
	IN __templatetypename_id INT
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	select tmpl.id
			,typename.id as typename_id
			,typename.name as typename
			,tmpl.subject 
			,tmpl.templatefor 
			,tmpl.bodycontent 
			,tmpl.createdby
			,tmpl.updatedby
			,tmpl.createdon
			,tmpl.updatedon
			,tmpl.category_id
			,tc.name as category_name
			,tmpl.subcategory_id
			,tsc.name as sub_category_name
			,tmpl.leadtime_number as leadTimeNumber
			,tmpl.leadtime_interval as leadTimeInterval
			,tmpl.leadtime_mode as leadTimeMode
			,tmpl.comments
			from templates tmpl
			join templatetypename typename on typename.id = tmpl.templatetypename_id and typename.clinic_id = __clinic_id
			left join templatecategory tc on tc.id = tmpl.category_id 
			left join templatesubcategory tsc on tsc.id = tmpl.subcategory_id
			where templatetypename_id = __templatetypename_id
            and tmpl.clinic_id = __clinic_id
			and tmpl.active = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_retrieve_treatment_plan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_retrieve_treatment_plan`(
	IN __guid varchar(100),
	IN __patient_id INT,
	IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    set @sQLStmt = CONCAT("
					select tp.TreatPlanNum as treatPlanNum
                            ,tp.PatNum as patient_id
                            ,tp.Heading as heading
                            ,tpattach.TreatPlanAttachNum as treatPlanAttachNum
                            ,tpattach.ProcNum as procNum
                            ,tpattach.Priority as priority
                            ,tpattach.TreatPlanNum as treatPlan_number
                            ,plog.PatNum as patNum
                            ,plog.ProcStatus as procStatus
                            ,plog.CodeNum as codeNum
                            ,plog.ToothNum as toothNum
                            ,plog.DateTStamp as dateTStamp
                            ,plog.Discount as procDiscount
                            ,DATE_FORMAT(plog.DateComplete, '%m/%d/%Y') as dateComplete
                            ,pc.ProcCode as procCode
                            ,pc.Descript as descript
                            ,plog.ProcFee as procFee
                            ,(CASE when pctp.FeeBilled <= 0 THEN 0 ELSE pctp.FeeBilled END) as feeBilled
                            ,(CASE when pctp.InsPayEst <= 0 THEN 0 ELSE ifnull(pctp.InsPayEst,0) END) as priInsAmt
                            ,(CASE when pctp.PaidOtherIns <= 0 THEN 0 ELSE ifnull(pctp.PaidOtherIns, 0) END) as PaidOtherIns
                            ,(
								select InsPayEst 
								from ", __opendentalDB, ".jd_claimproc _icp 
								left join ", __opendentalDB, ".jd_patplan _ipp on _ipp.PatNum = _icp.patnum and _ipp.InsSubNum = _icp.InsSubNum and _ipp.clinic_id = ", __clinic_id, "
								where _ipp.ordinal = 2 and _icp.ProcNum = pctp.ProcNum and _icp.clinic_id = ", __clinic_id, "
							) as secInsAmt                            
                            ,(CASE when pctp.WriteOffEst <= 0  THEN 0 ELSE ifnull(pctp.WriteOffEst, 0) END) as discount
                            ,(
								select (CASE when WriteOffEst <= 0  THEN 0 ELSE WriteOffEst END) 
								from ", __opendentalDB, ".jd_claimproc _icp 
								left join ", __opendentalDB, ".jd_patplan _ipp on _ipp.PatNum = _icp.patnum and _ipp.InsSubNum = _icp.InsSubNum and _ipp.clinic_id = ", __clinic_id, "
								where _ipp.ordinal = 2 and _icp.ProcNum = pctp.ProcNum and _icp.clinic_id = ", __clinic_id, "
							) as secdiscount                            
                            ,ifnull(pctp.BaseEst, 0) as feeAllowed1
                            ,(ifnull(plog.ProcFee, 0) - (CASE when pctp.WriteOffEst <= 0 THEN 0 ELSE ifnull(pctp.WriteOffEst, plog.Discount) END)) as feeAllowed
                            ,(plog.ProcFee - 
                            (CASE when pctp.InsPayEst <= 0 THEN 0 ELSE ifnull(pctp.InsPayEst, 0) END) - 
                            (CASE when pctp.PaidOtherIns <= 0 THEN 0 ELSE ifnull(pctp.PaidOtherIns, 0) END) - 
                            (CASE when pctp.WriteOffEst <= 0 THEN 0 ELSE ifnull(pctp.WriteOffEst, plog.Discount) END) ) as 'patientEst'
                            ,p.FName as firstName
                            ,p.LName as lastName
							,CASE
								WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), p.Birthdate)), '%Y')+0 < 19 OR p.Email = ''  THEN 
								(select p1.Email from ", __opendentalDB, ".jd_patient p1 join ", __opendentalDB, ".jd_patient p2 on p1.Guarantor = p2.PatNum  and p2.clinic_id = ", __clinic_id, " where p1.PatNum = p.Guarantor  and p1.clinic_id = ", __clinic_id, ")
								WHEN DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), p.Birthdate)), '%Y')+0 >= 19 THEN p.Email
							END as email
                            ,CONCAT(p.FName, ' ', IFNULL(CONCAT(p.MiddleI, ' '),''), p.LName) as patient_name
                            ,ifnull(def.DefNum,0) as definition_number
							,ifnull(def.ItemName,0) as definition_item_name
                            from ", __opendentalDB, ".jd_treatplan tp		
                            inner join ", __opendentalDB, ".jd_treatplanattach tpattach on tpattach.TreatPlanNum = tp.TreatPlanNum
                            left join ", __opendentalDB, ".jd_procedurelog plog on plog.ProcNum = tpattach.ProcNum  and plog.clinic_id = ", __clinic_id, "
                            left join ", __opendentalDB, ".jd_procedurecode pc on pc.CodeNum = plog.CodeNum and pc.clinic_id = ", __clinic_id, "
                            left join ", __opendentalDB, ".jd_claimproc pctp on pctp.ProcNum = tpattach.ProcNum and pctp.clinic_id = ", __clinic_id, " 
                            left join ", __opendentalDB, ".jd_definition def on def.DefNum = tpattach.Priority and def.clinic_id = ", __clinic_id, "
                            join ", __opendentalDB, ".jd_patient p on p.PatNum = tp.PatNum and p.clinic_id = ", __clinic_id, "
                            where tp.PatNum = ", __patient_id , " and plog.ProcStatus = 1
                             and tp.clinic_id = ", __clinic_id, "
                            -- and pctp.insSubNum in (select insSubNum from ", __opendentalDB, ".jd_patplan where patnum = ", __patient_id , " and ordinal = 1)
                            order by def.ItemName");
    
	PREPARE Stmt FROM @sQLStmt;
	EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_schdule_goal_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_schdule_goal_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
    DECLARE sQLStmt TEXT;
    DECLARE __workHours, __daysRange int;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		SET __workHours = 8;
        SET __daysRange = workdays(__reportStartDate, __reportEndDate);
        
		set @sQLStmt = CONCAT("select '", __daysRange, "' as days
			,(select (sum(_provider.HourlyProdGoalAmt)) from ", __opendentalDB, ".jd_provider _provider where _provider.IsHidden = 0 and _provider.clinic_id = ", __clinic_id, ") as hourly_goal
            ,(select (sum(_provider.HourlyProdGoalAmt)) * ", __workHours, " from ", __opendentalDB, ".jd_provider _provider where _provider.IsHidden = 0 and _provider.clinic_id = ", __clinic_id, ") as day_goal
            ,(select (sum(_provider.HourlyProdGoalAmt)) * ", __workHours * __daysRange, " from ", __opendentalDB, ".jd_provider _provider where _provider.IsHidden = 0 and _provider.clinic_id = ", __clinic_id, ") as weekly_goal
            
			,(SELECT sum(ProcFee)  FROM  ", __opendentalDB, ".jd_patient patient
			INNER JOIN  ", __opendentalDB, ".jd_procedurelog pl ON patient.PatNum=pl.PatNum  and pl.clinic_id = ", __clinic_id, "
			INNER JOIN  ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum  and pc.clinic_id = ", __clinic_id, "
			INNER JOIN  ", __opendentalDB, ".jd_appointment ap ON pl.AptNum=ap.AptNum and ap.clinic_id = ", __clinic_id, "
			AND AptStatus=1 AND PatStatus=0
			WHERE DATE(ap.AptDateTime) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')  and patient.clinic_id = ", __clinic_id, ") as scheduled");      
            
		
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		select '0' as days, '0' as day_goal, '0' as hourly_goal, '0' as weekly_goal, '0' as scheduled;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_account_registration_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_account_registration_status`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __guid varchar(100),
    IN __iscompleted INT,
    IN __createdon varchar(30)
)
ThisSP:BEGIN
    DECLARE __result_id INT DEFAULT 0;
    DECLARE __status_id INT DEFAULT 0;
    DECLARE __userEmail VARCHAR(250) ;
    
	IF __iscompleted = 1 THEN
        select id into __status_id from account_registration_status where guid = __guid and iscompleted = 0;
        IF __status_id > 0 THEN
			update account_registration_status set iscompleted = __iscompleted, completedon = __createdon, active = 0 where guid = __guid;
		ELSE
			select userame into __userEmail from user where id = __user_id and clinic_id = __paged;
			select __result_id as resultId, CONCAT("Registration for account ",  __userEmail, " was completed already") as response;
			Leave ThisSP;
        END IF;
    ELSE
		insert into account_registration_status
        (clinic_id, user_id, guid, createon, iscompleted)
        values
        (__paged, __user_id, __guid, __createdon, __iscompleted);
        SET __result_id = LAST_INSERT_ID();
       
        select 
            __guid as guid,
			__result_id as resultId, 
			'success' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_commlog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_commlog`(
	IN __PatNum INT(11),
        IN __opendentalDB CHAR(100)
    )
BEGIN
   DECLARE __def_id INT;
   DECLARE sQLStmt TEXT;

	set @sQLStmt = CONCAT('select 
		DefNum as defnum
		,Category as category
		,ItemOrder as itemOrder
		,ItemName as itemName
        from ', __opendentalDB, '.definition
        where IsHidden = 0
        and Category = 27
        order by ItemOrder
	');
	
	PREPARE Stmt FROM @sQLStmt;
	EXECUTE Stmt;
	DEALLOCATE PREPARE Stmt; 
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_commlog_notes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_commlog_notes`(
		IN __guid varchar(100),
		IN __update_mode varchar(100),
		IN __CommlogNum INT(11),
		IN __patnum INT(11),
		IN __CommDateTime varchar(30),
        IN __CommType int(11),
        IN __Note text,
        IN __Mode int,
        IN __SentOrReceived int,
        IN __UserNum int,
        IN __Signature int,
		IN __SigIsTopaz int,
        IN __CommSource int,
        IN __ProgramNum int,
        IN __opendentalDB CHAR(100)
    )
BEGIN
	DECLARE __def_id INT;
	DECLARE sQLStmt TEXT;
	DECLARE __noteresult_id INT DEFAULT 0;
    DECLARE __CommlogNum INT DEFAULT 0;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF __CommlogNum > 0 THEN
		set @sQLStmt = CONCAT("
		update ", __opendentalDB, ".jd_commlog set
			PatNum = ", __patnum,
			",CommDateTime = STR_TO_DATE('",__CommDateTime, "', '%Y-%m-%d %H:%i:%s')
			,CommType = ", __CommType,
			",Note = '", __Note,
			"',Mode_ = ", __Mode, 
			",SentOrReceived = ", __SentOrReceived,
			",UserNum = ", __UserNum,
			",Signature = ", __Signature,
			",SigIsTopaz = ", __SigIsTopaz,
			",CommSource = ", __CommSource,
			",ProgramNum = ", __ProgramNum,
		" where CommlogNum = ", __CommlogNum, " and clinic_id = ", __clinic_id);
        set __noteresult_id = __CommlogNum;
	ELSE
		select max(CommlogNum) into __CommlogNum from jd_commlog where clinic_id = __clinic_id;
        IF __CommlogNum is null THEN
			SET __CommlogNum = 1;
        ELSE
			SET __CommlogNum = __CommlogNum + 1;
        END IF;
		
		INSERT into jd_commlog (
			CommlogNum
			,PatNum
			,CommDateTime
			,CommType
			,Note
			,Mode_
			,SentOrReceived
			,UserNum
			,Signature
			,SigIsTopaz
            ,CommSource
            ,ProgramNum
            ,clinic_id
            ,update_mode
        ) values (
			__CommlogNum
			,__patnum
			,STR_TO_DATE(__CommDateTime, '%Y-%m-%d %H:%i:%s')
			,__CommType
			,__Note
			,__Mode
			,__SentOrReceived
			,__UserNum
			,__Signature
			,__SigIsTopaz
			,__CommSource
			,__ProgramNum
			,__clinic_id
			,__update_mode
        );
		SET __noteresult_id = 1;
	END IF;
    select __noteresult_id as noteid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_historyappointment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_historyappointment`(
	
	IN __HistUserNum INT(10), 
	IN __aptTimestamp varchar(30), 
    IN __HistApptAction INT   , 
    IN __ApptSource INT, 
	IN __AptNum INT, 
    IN __PatNum INT, 
    IN __AptStatus INT, 
    IN __Pattern  varchar(255), 
    IN __Confirmed int, 
    IN __TimeLocked int, 

    IN __operatorId int, 
    IN __Note text, 
    IN __ProvNum int, 
    IN __ProvHyg int, 
    IN __reAptDateTime  varchar(30), 
    IN __NextAptNum int, 
    IN __UnschedStatus int, 
    IN __IsNewPatient int, 
    IN __ProcDescript  varchar(255), 
    IN __Assistant int, 

    IN __ClinicNum int, 
    IN __IsHygiene int, 
    IN __DateTimeArrived  varchar(30), 
    IN __DateTimeSeated varchar(30), 
    IN __DateTimeDismissed varchar(30), 
    IN __InsPlan1 int, 
    IN __InsPlan2 int, 
    IN __DateTimeAskedToArrive varchar(30), 
    IN __ProcsColored text, 
    IN __ColorOverride int, 

    IN __AppointmentTypeNum int, 
    IN __SecUserNumEntry int, 
    IN __SecDateEntry varchar(30), 
    IN __Priority int, 
	IN __ProvBarText varchar(60), 
	IN __PatternSecondary varchar(255), 
    IN __guid varchar(100),
    IN __updatemode varchar(1)
)
BEGIN
    DECLARE __clinic_id INT DEFAULT 0;
	DECLARE __NextHistAptNum INT DEFAULT 1;
	DECLARE __result_id INT DEFAULT 0;

    SET __clinic_id = func_get_clinic_id(__guid);
    
	select ifnull(max(HistApptNum), 0) into __NextHistAptNum from jd_histappointment where clinic_id = __clinic_id;
    IF __NextHistAptNum = 0 THEN
		SET __NextHistAptNum = 1;
	ELSE
		SET __NextHistAptNum = __NextHistAptNum + 1;
    END IF;

    
	IF length(__AptNum)  > 0 THEN

		insert into jd_histappointment (
				HistUserNum
				,HistDateTStamp
				,HistApptAction
				,ApptSource
				,AptNum
				,PatNum
				,AptStatus
				,Pattern
				,Confirmed
				,TimeLocked

				,Op
				,Note
				,ProvNum
				,ProvHyg
				,AptDateTime
				,NextAptNum
				,UnschedStatus
				,IsNewPatient
				,ProcDescript
				,Assistant

				,ClinicNum
				,IsHygiene
				,DateTStamp
				,DateTimeArrived
				,DateTimeSeated
				,DateTimeDismissed
				,InsPlan1
				,InsPlan2
				,DateTimeAskedToArrive
				,ProcsColored

				,ColorOverride
				,AppointmentTypeNum
				,SecUserNumEntry
				,SecDateTEntry
				,Priority
				,ProvBarText
				,PatternSecondary
				,clinic_id
				,update_mode
				,updatedon
				,HistApptNum
			) values (
				__HistUserNum
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__HistApptAction
				,__ApptSource
				,__AptNum
				,__PatNum
				,__AptStatus
				,__Pattern
				,__Confirmed
				,__TimeLocked

				,__operatorId
				,__Note
				,__ProvNum
				,__ProvHyg
				,STR_TO_DATE(__reAptDateTime, '%c/%e/%Y %H:%i')
				,__NextAptNum
				,__UnschedStatus
				,__IsNewPatient
				,__ProcDescript
				,__Assistant

				,__clinic_id
				,__IsHygiene
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__DateTimeArrived
				,__DateTimeSeated
				,__DateTimeDismissed
				,__InsPlan1
				,__InsPlan2
				,__DateTimeAskedToArrive
				,__ProcsColored

				,__ColorOverride
				,__AppointmentTypeNum
				,__SecUserNumEntry
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__Priority
				,__ProvBarText
				,__PatternSecondary
				,__clinic_id
				,__updatemode
				,STR_TO_DATE(__aptTimestamp, '%c/%e/%Y %H:%i')
				,__NextHistAptNum
			);
			SET __result_id = LAST_INSERT_ID();
	END IF;
	select __result_id as resultId, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_user_code_verification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_user_code_verification`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __secretcode varchar(10),
    IN __verifystatus char(1),
    IN __createdon varchar(30)
)
BEGIN
    DECLARE __result_id INT DEFAULT 0;
    call proc_create_user_code_verification(__user_id, __paged, __secretcode, __verifystatus, __createdon);
    SET __result_id = LAST_INSERT_ID();
    
    IF __result_id is null THEN
		select 0 as resultId, 'failure' as response;
	ELSEIF __result_id > 0 THEN
		select __result_id as resultId, 'success' as response;
	ELSE
    	select __result_id as resultId, 'Failure' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_set_user_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_set_user_status`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __active INT,
    IN __createdon varchar(30)
)
BEGIN
    DECLARE __result_id INT DEFAULT 0;
    
	IF __user_id > 0 THEN
		update user set active = __active, updatedon = __createdon where id = __user_id and clinic_id = __paged;
        update clinic set active = 1 where id = __paged;
        
        SET __result_id = __user_id;
        select 
			__result_id as resultId, 
			'success' as response,
			_user.id as user_id,
			_user.clinic_id,
			_clinic.name as clinic_name,
			_user.username,
			_user.phone as userphone
        from user _user
        left join clinic _clinic on _clinic.id = _user.clinic_id and _clinic.active = 1
        where _user.id = __user_id and _user.active = 1;
        
	ELSE
    	select __result_id as resultId, 'User id is missing' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_signature_content_draft` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_signature_content_draft`(
)
BEGIN
	select 
		td.id
		,td.type
		,td.subject
		,td.bodycontent
		FROM template_draft td
		WHERE td.category_id = (select id from templatecategory where lcase(name) like '%signature%');

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_signup_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_signup_account`(
	IN __useremail varchar(200),
    IN __password varchar(200), -- Clinic Id
	IN __phone varchar(10),
    IN __clinicname varchar(250),
    IN __secretcode varchar(10),
    IN __guid varchar(100),
    IN __currenttime varchar(30)
)
ThisSP:BEGIN
	DECLARE __clinic_id INT;
    DECLARE __user_id INT;
    DECLARE __user_exist INT;
    DECLARE __result_id INT DEFAULT 0;
    DECLARE __verification_id INT DEFAULT 0;
    
    IF length(__clinicname) > 0 THEN

        select id into __clinic_id from clinic where lcase(name) = lcase(__clinicname) limit 1;
        
        select id into __user_id from user where lcase(username) = lcase(trim(__useremail)) and active = 1 limit 1;
        IF __user_id is not null and __user_id > 0 THEN
			set __user_exist = -1;
            select __user_exist as resultId, 'failure' as response;
            leave ThisSP;
        END IF;
        
        select id into __user_id from user where lcase(phone) = lcase(trim(__phone)) and active = 1 limit 1;
        IF __user_id is not null and __user_id > 0 THEN
			set __user_exist = -2;
            select __user_exist as resultId, 'failure' as response;
            leave ThisSP;
        END IF;
		
        select id into __user_id from user where lcase(username) = lcase(trim(__useremail)) and active = 0 limit 1;        
        
        IF __clinic_id is null THEN
			insert into clinic (name, createdon, active, unique_id) values (trim(__clinicname), __currenttime, 0, __guid);
            SET __clinic_id = LAST_INSERT_ID();
        END IF;
        
        IF __clinic_id > 0 THEN
			IF __user_id is null THEN
				insert into user (
					clinic_id,
					username,
					password,
					phone,
					roleid,
                    profile_picture_url,
					active,
                    createdon
				) 
				values (
					__clinic_id
					,__useremail
					,__password
					,__phone
					,1
                    ,''
					,0
                    ,__currenttime
				);
				SET __result_id = LAST_INSERT_ID(); 
			ELSE
				update user set password = __password, phone = __phone where id = __user_id;
				SET __result_id  = __user_id;
			END IF;	
            
            IF __result_id > 0 THEN
				call proc_create_user_code_verification(__result_id, __clinic_id, __secretcode, 'N',  __currenttime);
                SET __verification_id = LAST_INSERT_ID();
            ELSE
				select 0 as resultId, 'Failed to add user' as response;
                leave ThisSP;
            END IF;
        END IF;
    END IF;
    select __verification_id as resultId, __result_id as user_id, __clinic_id as paged, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_template_draft` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_template_draft`(
	IN __guid varchar(100),
	IN __id INT
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;
	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0 ) THEN
		select
			td.id
			,td.type
			,td.category_id
			,tc.name as category_name
			,td.subject
			,td.bodycontent as body_content
			,td.bodycontent_text as body_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active
		from template_draft td
        LEFT JOIN templatecategory tc ON td.category_id = tc.id -- AND tc.clinic_id = __clinic_id 
        WHERE td.clinic_id = __clinic_id 
        ORDER BY td.category_id;
	ELSE
		select
			td.id
			,td.type
			,td.category_id
			,tc.name as category_name
			,td.subject
			,td.bodycontent as body_content
			,td.bodycontent_text as body_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active
		from template_draft td
        JOIN templatecategory tc ON td.category_id = tc.id -- AND tc.clinic_id = __clinic_id 
        where td.id = __id
        AND td.clinic_id = __clinic_id 
        ORDER BY td.category_id;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_template_signature` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_template_signature`(
	IN __guid varchar(100),
	IN __id INT
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0 ) THEN
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,td.content_text as signature_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
		from template_signature td
        where td.clinic_id = __clinic_id 
        ORDER BY td.name;
	ELSE
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,td.content_text as signature_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
		from template_signature td
        where td.id = __id
			AND td.clinic_id = __clinic_id 
        ORDER BY td.name;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_template_signature_activate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_template_signature_activate`(
	IN __guid varchar(100),
	IN __id INT
)
BEGIN
	DECLARE __result varchar(1000);
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id > 0 ) THEN
		update template_signature set active = 0 and clinic_id = __clinic_id;
        update template_signature set active = 1 where id = __id and clinic_id = __clinic_id;
        Select name into __result  from template_signature where id = __id and clinic_id = __clinic_id;
        select __id as signature_id, concat(__result, ' is activated') as response; 
	else
        select __id as signature_id, 'Signature id is missing' as response; 
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_template_signature_with_media` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_template_signature_with_media`(
	IN __guid varchar(100),
	IN __id INT
)
BEGIN
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0 ) THEN
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,td.content_text as signature_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
			,tsml.id as social_media_id
			,tsml.type as social_media_type
			,tsml.address as social_media_address
		from template_signature td
        left JOIN template_signature_media_links tsml ON tsml.signature_id = td.id
        where td.clinic_id = __clinic_id 
        ORDER BY td.name;
	ELSE
		select
			td.id
			,td.name as signature_name
			,td.content as signature_content
			,td.content_text as signature_content_text
			,DATE_FORMAT(td.createdon, "%m/%d/%Y") AS created_date
			,td.createdby
			,(select CONCAT(firstname, ' ', lastname) from user where id = td.createdby) as created_user
			,DATE_FORMAT((CASE WHEN td.updatedon is null THEN td.createdon
				ELSE td.updatedon END), "%m/%d/%Y") AS updated_date
			,td.updatedby
			,(select CONCAT(firstname, ' ', lastname) from user where id = (
				CASE WHEN td.updatedby is null  or td.updatedby = '' then td.createdby
					ELSE td.updatedby
				END
            )) as updated_user
			,td.comments
            ,td.active as signature_active
			,tsml.id as social_media_id
			,tsml.type as social_media_type
			,tsml.address as social_media_address            
		from template_signature td
                left JOIN template_signature_media_links tsml ON tsml.signature_id = td.id
        where td.id = __id
			and td.clinic_id = __clinic_id
        ORDER BY td.name;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_unscheduled_patients_detail_dashboard_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_unscheduled_patients_detail_dashboard_data`(
	IN __guid varchar(100),
	IN __reportStartDate varchar(20),
    IN __reportEndDate varchar(20),
    IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE temp_status_id INT DEFAULT 0;
    DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF(NOT isnull(__reportStartDate)) then
		set @sQLStmt = CONCAT("
					SELECT 
						pat.PatNum as patient_id,
						CONCAT(pat.FName, ' ', IFNULL(CONCAT(pat.MiddleI, ' '),''), pat.LName) as patient_name,
						pat.Email as email
						,DATE_FORMAT(pat.Birthdate, '%m/%d/%Y') AS birth_date
						,DATE_FORMAT(FROM_DAYS(DATEDIFF(CURDATE(), pat.Birthdate)), '%Y')+0 AS age
						,CONCAT(pat.Address, ' ', IFNULL(CONCAT(pat.Address2, ' '),''), pat.City, ' ', pat.State, ' ', pat.Zip) as patient_address
						,pat.Address as address
						,pat.Address2 as address2
						,pat.City as city
						,pat.State as state
						,pat.Zip as zip                        
						,pat.wirelessphone as cell
						,pat.HmPhone as homephone
						,pat.WkPhone as workphone
						,pat.TxtMsgOk as sendtext
						,DATE_FORMAT(pat.DateFirstVisit, '%m/%d/%Y') AS firstvisit
						,pat.Gender as gender
						,CASE 
							WHEN pat.gender = 0 then 'Male'
							WHEN pat.gender = 1 then 'Female'
							WHEN pat.gender = 2 then 'Unknown'
						END as 'gendertext'                          
                        /* ,DATE_FORMAT((A.ProcDate),'%m/%d/%Y') AS 'LastVisit' */
                    FROM
                    (
						select distinct pl.PatNum
						FROM ", __opendentalDB, ".jd_procedurelog pl
						WHERE 
							pl.ProcStatus=2 
                            AND DATE(pl.ProcDate) < (DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
							AND pl.clinic_id = ", __clinic_id, "
					) A                    
                    INNER JOIN ", __opendentalDB, ".jd_patient pat on pat.PatNum = A.PatNum AND pat.clinic_id = ", __clinic_id, "
						ORDER BY pat.FName, pat.LName ASC");

                    /*
                    (
						select distinct pl.PatNum, MAX(pl.ProcDate) as ProcDate -- , pl.AptNum, 
						FROM ", __opendentalDB, ".jd_procedurelog pl
						WHERE 
							pl.ProcStatus=2 AND 
							DATE(pl.ProcDate) < (DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
							GROUP BY pl.PatNum
							HAVING MAX(pl.ProcDate)
					) A */
                    /*
					(	select distinct plm.PatNum, MAX(plm.ProcDate) ProcDate FROM ", __opendentalDB, ".jd_procedurelog plm where plm.PatNum in (
							select distinct pl.PatNum -- , MAX(pl.ProcDate) as ProcDate -- , pl.AptNum, 
							FROM ", __opendentalDB, ".jd_procedurelog pl
							LEFT JOIN ", __opendentalDB, ".jd_procedurecode pc ON pl.CodeNum= pc.CodeNum
							LEFT JOIN ", __opendentalDB, ".jd_appointment ap ON pl.PatNum = ap.PatNum
							WHERE 
								pl.ProcStatus=2 
								GROUP BY pl.PatNum
								HAVING (MAX(pl.ProcDate)< DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
								order by pl.AptNum, pl.ProcDate
							)
							AND plm.PatNum not in 
							(
								select distinct pln.PatNum
								FROM ", __opendentalDB, ".jd_procedurelog pln
								LEFT JOIN ", __opendentalDB, ".jd_procedurecode pcn ON pln.CodeNum= pcn.CodeNum
								WHERE DATE(pln.ProcDate) between DATE('",__reportStartDate,"') and DATE('",__reportEndDate,"')
							)
							GROUP BY plm.PatNum
							HAVING (MAX(plm.ProcDate)<=DATE('",__reportStartDate,"') - INTERVAL 1 YEAR)
					)A               */

        PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
	ELSE
		SELECT 0 as patient_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_account` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_account`(
    IN __paged INT, -- Clinic Id
    IN __user_id INT,
    IN __user_firstname varchar(150),
    IN __user_lastname varchar(150),
    
    IN __clinic_groupof varchar(200),
    IN __clinic_dentistname varchar(200),
    IN __clinic_adress1 varchar(200),
    IN __clinic_adress2 varchar(200),
    IN __clinic_city varchar(50),
    IN __clinic_state 		varchar(50),
    IN __clinic_zip 		varchar(10),
    IN __clinic_contactperson varchar(200),
    IN __clinic_primaryphone varchar(10),
    IN __clinic_primaryemail varchar(250),
    IN __clinic_website 	varchar(250),
    IN __clinic_appt_request_page varchar(200),
    IN __currenttime 		varchar(30)
)
ThisSP:BEGIN

	DECLARE __result_id INT DEFAULT 0;

	IF __paged > 0 and __user_id > 0 THEN
		update clinic set 
			groupof 		= __clinic_groupof,
            address1 		= __clinic_adress1,
            address2 		= __clinic_adress2,
            city 			= __clinic_city,
            state 			= __clinic_state,
            zip 			= __clinic_zip,
            dentist_name 	= __clinic_dentistname,
            primary_contact = __clinic_contactperson,
            primary_phone 	= __clinic_primaryphone,
            primary_email 	= __clinic_primaryemail,
            website 		= __clinic_website,
            appt_request_page = __clinic_appt_request_page,
            active 			= 1
		where id = __paged;
		
		
		update user set 
			firstname = __user_firstname,
            lastname = __user_lastname,
            updatedon = __currenttime,
            updatedby = __user_id,
            active = 1
            where id = __user_id 
				and clinic_id = __paged;
                
		update account_registration_status set 
			iscompleted = 1,
            completedon = __currenttime,
            active = 0;
        
        select 1 as resultId, 'success' as response;
	ELSE
		select 0 as resultId, 'failure' as response;
	END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_adjustment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_adjustment`(
		IN __AdjNum bigint(20),
		IN __AdjDate varchar(30),
		IN __AdjAmt double,
		IN __PatNum bigint(20),
		IN __AdjType bigint(20),
		IN __ProvNum bigint(20),
		IN __AdjNote text,
		IN __ProcDate varchar(30),
		IN __ProcNum bigint(20),
		IN __DateEntry varchar(30),
		IN __ClinicNum bigint(20),
		IN __StatementNum bigint(20),
		IN __SecUserNumEntry bigint(20),
		IN __SecDateTEdit varchar(30),
		IN __TaxTransID bigint(20),
		IN __clinic_id INT(10),
		IN __update_mode char(1), -- R - Remote, D - Direct
		IN __updatedon varchar(30)
)
BEGIN
    DECLARE __temPatNum bigint(20);
    
    Select AdjNum into __temPatNum from jd_adjustment where AdjNum = __AdjNum and clinic_id = __clinic_id limit 1;
    
    IF __temPatNum > 0 THEN
		UPDATE jd_adjustment set 
			AdjDate = __AdjDate
			,AdjAmt = __AdjAmt
			,PatNum = __PatNum
			,AdjType = __AdjType
			,ProvNum = __ProvNum
			,AdjNote = __AdjNote
			,ProcDate = __ProcDate
			,ProcNum = __ProcNum
			,DateEntry = __DateEntry
			,ClinicNum = __ClinicNum
			,StatementNum = __StatementNum
			,SecUserNumEntry = __SecUserNumEntry
			,SecDateTEdit = __SecDateTEdit
			,TaxTransID = __TaxTransID
			,updatedon = __updatedon
        WHERE AdjNum = __AdjNum 
			and clinic_id = __clinic_id;
	ELSE
		insert into jd_adjustment (
			AdjNum,
			AdjDate,
			AdjAmt,
			PatNum,
			AdjType,
			ProvNum,
			AdjNote,
			ProcDate,
			ProcNum,
			DateEntry,
			ClinicNum,
			StatementNum,
			SecUserNumEntry,
			SecDateTEdit,
			TaxTransID,
			clinic_id,
			update_mode,
			updatedon
        ) values(
			__AdjNum,
			__AdjDate,
			__AdjAmt,
			__PatNum,
			__AdjType,
			__ProvNum,
			__AdjNote,
			__ProcDate,
			__ProcNum,
			__DateEntry,
			__ClinicNum,
			__StatementNum,
			__SecUserNumEntry,
			__SecDateTEdit,
			__TaxTransID,
			__clinic_id,
			__update_mode,
			__updatedon
        );
	END IF;
    select '1' as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_appointment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_appointment`(
		IN __AptNum bigint(20),
		IN __PatNum bigint(20),
		IN __AptStatus tinyint(3) unsigned,
		IN __Pattern varchar(255),
		IN __Confirmed bigint(20),
		IN __TimeLocked tinyint(1),
		IN __Op bigint(20),
		IN __Note text,
		IN __ProvNum bigint(20),
		IN __ProvHyg bigint(20),
		IN __AptDateTime varchar(30),
		IN __NextAptNum bigint(20),
		IN __UnschedStatus bigint(20),
		IN __IsNewPatient tinyint(3) unsigned,
		IN __ProcDescript varchar(255),
		IN __Assistant bigint(20),
		IN __ClinicNum bigint(20),
		IN __IsHygiene tinyint(3) unsigned,
		IN __DateTStamp timestamp,
		IN __DateTimeArrived datetime,
		IN __DateTimeSeated datetime,
		IN __DateTimeDismissed datetime,
		IN __InsPlan1 bigint(20),
		IN __InsPlan2 bigint(20),
		IN __DateTimeAskedToArrive varchar(30),
		IN __ProcsColored text,
		IN __ColorOverride int(11),
		IN __AppointmentTypeNum bigint(20),
		IN __SecUserNumEntry bigint(20),
		IN __SecDateTEntry varchar(30),
		IN __Priority tinyint(4),
		IN __ProvBarText varchar(60),
		IN __PatternSecondary varchar(255),
		IN __clinic_id INT(10),
		IN __update_mode char(1),
		IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select AptNum into __temAptNum from jd_appointment where AptNum = __AptNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_appointment set
				PatNum = __PatNum
				,AptStatus = __AptStatus
				,Pattern = __Pattern
				,Confirmed = __Confirmed
				,TimeLocked = __TimeLocked
				,Op = __Op
				,Note = __Note
				,ProvNum = __ProvNum
				,ProvHyg = __ProvHyg
				,AptDateTime = __AptDateTime
				,NextAptNum = __NextAptNum
				,UnschedStatus = __UnschedStatus
				,IsNewPatient = __IsNewPatient
				,ProcDescript = __ProcDescript
				,Assistant = __Assistant
				,ClinicNum = __ClinicNum
				,IsHygiene = __IsHygiene
				,DateTStamp = __DateTStamp
				,DateTimeArrived = __DateTimeArrived
				,DateTimeSeated = __DateTimeSeated
				,DateTimeDismissed = __DateTimeDismissed
				,InsPlan1 = __InsPlan1
				,InsPlan2 = __InsPlan2
				,DateTimeAskedToArrive = __DateTimeAskedToArrive
				,ProcsColored = __ProcsColored
				,ColorOverride = __ColorOverride
				,AppointmentTypeNum = __AppointmentTypeNum
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateTEntry = __SecDateTEntry
				,Priority = __Priority
				,ProvBarText = __ProvBarText
				,PatternSecondary = __PatternSecondary
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE AptNum = __temAptNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_appointment (
				AptNum,
				PatNum,
				AptStatus,
				Pattern,
				Confirmed,
				TimeLocked,
				Op,
				Note,
				ProvNum,
				ProvHyg,
				AptDateTime,
				NextAptNum,
				UnschedStatus,
				IsNewPatient,
				ProcDescript,
				Assistant,
				ClinicNum,
				IsHygiene,
				DateTStamp,
				DateTimeArrived,
				DateTimeSeated,
				DateTimeDismissed,
				InsPlan1,
				InsPlan2,
				DateTimeAskedToArrive,
				ProcsColored,
				ColorOverride,
				AppointmentTypeNum,
				SecUserNumEntry,
				SecDateTEntry,
				Priority,
				ProvBarText,
				PatternSecondary,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__AptNum,
				__PatNum,
				__AptStatus,
				__Pattern,
				__Confirmed,
				__TimeLocked,
				__Op,
				__Note,
				__ProvNum,
				__ProvHyg,
				__AptDateTime,
				__NextAptNum,
				__UnschedStatus,
				__IsNewPatient,
				__ProcDescript,
				__Assistant,
				__ClinicNum,
				__IsHygiene,
				__DateTStamp,
				__DateTimeArrived,
				__DateTimeSeated,
				__DateTimeDismissed,
				__InsPlan1,
				__InsPlan2,
				__DateTimeAskedToArrive,
				__ProcsColored,
				__ColorOverride,
				__AppointmentTypeNum,
				__SecUserNumEntry,
				__SecDateTEntry,
				__Priority,
				__ProvBarText,
				__PatternSecondary,
				__clinic_id,
				__update_mode,
				__updatedon            
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_apptremindersent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_apptremindersent`(
		IN __ApptReminderSentNum bigint(20),
		IN __ApptNum bigint(20),
		IN __ApptDateTime varchar(30),
		IN __DateTimeSent varchar(30),
		IN __TSPrior bigint(20),
		IN __ApptReminderRuleNum bigint(20),
		IN __IsSmsSent tinyint(4),
		IN __IsEmailSent tinyint(4),
		IN __clinic_id INT(10),
		IN __update_mode char(1),
		IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ApptReminderSentNum into __temAptNum from jd_apptremindersent where ApptReminderSentNum = __ApptReminderSentNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_apptremindersent set
				ApptNum = __ApptNum
				,ApptDateTime = __ApptDateTime
				,DateTimeSent = __DateTimeSent
				,TSPrior = __TSPrior
				,ApptReminderRuleNum = __ApptReminderRuleNum
				,IsSmsSent = __IsSmsSent
				,IsEmailSent = __IsEmailSent
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE ApptReminderSentNum = __ApptReminderSentNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_apptremindersent (
				ApptReminderSentNum,
				ApptNum,
				ApptDateTime,
				DateTimeSent,
				TSPrior,
				ApptReminderRuleNum,
				IsSmsSent,
				IsEmailSent,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__ApptReminderSentNum,
				__ApptNum,
				__ApptDateTime,
				__DateTimeSent,
				__TSPrior,
				__ApptReminderRuleNum,
				__IsSmsSent,
				__IsEmailSent,
				__clinic_id,
				__update_mode,
				__updatedon            
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_benefit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_benefit`(
			IN __BenefitNum bigint(20),
			IN __PlanNum bigint(20),
			IN __PatPlanNum bigint(20),
			IN __CovCatNum bigint(20),
			IN __BenefitType tinyint(3) unsigned,
			IN __Percent tinyint(4),
			IN __MonetaryAmt double,
			IN __TimePeriod tinyint(3) unsigned,
			IN __QuantityQualifier tinyint(3) unsigned,
			IN __Quantity tinyint(3) unsigned,
			IN __CodeNum bigint(20),
			IN __CoverageLevel int(11),
			IN __SecDateTEntry varchar(30),
			IN __SecDateTEdit varchar(30),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select BenefitNum into __temAptNum from jd_benefit where BenefitNum = __BenefitNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_benefit set
				PlanNum = __PlanNum
				,PatPlanNum = __PatPlanNum
				,CovCatNum = __CovCatNum
				,BenefitType = __BenefitType
				,Percent = __Percent
				,MonetaryAmt = __MonetaryAmt
				,TimePeriod = __TimePeriod
				,QuantityQualifier = __QuantityQualifier
				,Quantity = __Quantity
				,CodeNum = __CodeNum
				,CoverageLevel = __CoverageLevel
				,SecDateTEntry = __SecDateTEntry
				,SecDateTEdit = __SecDateTEdit
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE BenefitNum = __BenefitNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_benefit (
				BenefitNum,
				PlanNum,
				PatPlanNum,
				CovCatNum,
				BenefitType,
				Percent,
				MonetaryAmt,
				TimePeriod,
				QuantityQualifier,
				Quantity,
				CodeNum,
				CoverageLevel,
				SecDateTEntry,
				SecDateTEdit,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__BenefitNum,
				__PlanNum,
				__PatPlanNum,
				__CovCatNum,
				__BenefitType,
				__Percent,
				__MonetaryAmt,
				__TimePeriod,
				__QuantityQualifier,
				__Quantity,
				__CodeNum,
				__CoverageLevel,
				__SecDateTEntry,
				__SecDateTEdit,
				__clinic_id,
				__update_mode,
				__updatedon            
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_carrier` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_carrier`(
		IN __CarrierNum bigint(20),
		IN __CarrierName varchar(255),
		IN __Address varchar(255),
		IN __Address2 varchar(255),
		IN __City varchar(255),
		IN __State varchar(255),
		IN __Zip varchar(255),
		IN __Phone varchar(255),
		IN __ElectID varchar(255),
		IN __NoSendElect tinyint(3) unsigned,
		IN __IsCDA tinyint(3) unsigned,
		IN __CDAnetVersion varchar(100),
		IN __CanadianNetworkNum bigint(20),
		IN __IsHidden tinyint(4),
		IN __CanadianEncryptionMethod tinyint(4),
		IN __CanadianSupportedTypes int(11),
		IN __SecUserNumEntry bigint(20),
		IN __SecDateEntry varchar(30),
		IN __SecDateTEdit varchar(30),
		IN __TIN varchar(255),
		IN __CarrierGroupName bigint(20),
		IN __ApptTextBackColor int(11),
		IN __IsCoinsuranceInverted tinyint(4),
		IN __TrustedEtransFlags tinyint(4),
		IN __clinic_id INT(10),
		IN __update_mode char(1),
		IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select CarrierNum into __temAptNum from jd_carrier where CarrierNum = __CarrierNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_carrier set
				CarrierName = __CarrierName
				,Address = __Address
				,Address2 = __Address2
				,City = __City
				,State = __State
				,Zip = __Zip
				,Phone = __Phone
				,ElectID = __ElectID
				,NoSendElect = __NoSendElect
				,IsCDA = __IsCDA
				,CDAnetVersion = __CDAnetVersion
				,CanadianNetworkNum = __CanadianNetworkNum
				,IsHidden = __IsHidden
				,CanadianEncryptionMethod = __CanadianEncryptionMethod
				,CanadianSupportedTypes = __CanadianSupportedTypes
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateEntry = __SecDateEntry
				,SecDateTEdit = __SecDateTEdit
				,TIN = __TIN
				,CarrierGroupName = __CarrierGroupName
				,ApptTextBackColor = __ApptTextBackColor
				,IsCoinsuranceInverted = __IsCoinsuranceInverted
				,TrustedEtransFlags = __TrustedEtransFlags
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE CarrierNum = __CarrierNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_carrier (
				CarrierNum,
				CarrierName,
				Address,
				Address2,
				City,
				State,
				Zip,
				Phone,
				ElectID,
				NoSendElect,
				IsCDA,
				CDAnetVersion,
				CanadianNetworkNum,
				IsHidden,
				CanadianEncryptionMethod,
				CanadianSupportedTypes,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				TIN,
				CarrierGroupName,
				ApptTextBackColor,
				IsCoinsuranceInverted,
				TrustedEtransFlags,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__CarrierNum,
				__CarrierName,
				__Address,
				__Address2,
				__City,
				__State,
				__Zip,
				__Phone,
				__ElectID,
				__NoSendElect,
				__IsCDA,
				__CDAnetVersion,
				__CanadianNetworkNum,
				__IsHidden,
				__CanadianEncryptionMethod,
				__CanadianSupportedTypes,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__TIN,
				__CarrierGroupName,
				__ApptTextBackColor,
				__IsCoinsuranceInverted,
				__TrustedEtransFlags,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_chat_access_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_chat_access_history`(
		IN __guid varchar(100),
        IN __patient_id INT,
        IN __last_accessed_on varchar(30),
        IN __last_accessed_by INT
    )
BEGIN
	DECLARE __access_id INT;
    DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF __patient_id > 0 THEN
		select id into __access_id from chat_message_access where patient_id = __patient_id;
        IF isnull(__access_id) THEN
			INSERT into chat_message_access 
				(clinic_id, account_id, patient_id, last_accessed_on, last_accessed_by) values 
				(
					__clinic_id
                    ,__clinic_id
					,__patient_id
					,STR_TO_DATE(__last_accessed_on, '%Y-%m-%d %H:%i:%s')
					,__last_accessed_by
				);
			SET __access_id = LAST_INSERT_ID();
		ELSE
			update chat_message_access set 
			last_accessed_on = STR_TO_DATE(__last_accessed_on, '%Y-%m-%d %H:%i:%s'), 
			last_accessed_by = __last_accessed_by
			where id = __access_id and clinic_id = __clinic_id;
		END IF;
	END IF;
	select __access_id as id;
    
    IF __access_id > 0 then
		INSERT into chat_message_access_history 
        (clinic_id, account_id, chat_message_access_id, patient_id, last_accessed_on, last_accessed_by)
        values
        (
			__clinic_id
            ,__clinic_id
            ,__access_id
			,__patient_id
			,STR_TO_DATE(__last_accessed_on, '%Y-%m-%d %H:%i:%s')
			,__last_accessed_by
        );
    END IF;
    
    select __access_id as access_id, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_claimpayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_claimpayment`(
		IN __ClaimPaymentNum bigint(20),
		IN __CheckDate varchar(30),
		IN __CheckAmt double,
		IN __CheckNum varchar(25),
		IN __BankBranch varchar(25),
		IN __Note varchar(255),
		IN __ClinicNum bigint(20),
		IN __DepositNum bigint(20),
		IN __CarrierName varchar(255),
		IN __DateIssued varchar(30),
		IN __IsPartial tinyint(4),
		IN __PayType bigint(20),
		IN __SecUserNumEntry bigint(20),
		IN __SecDateEntry varchar(30),
		IN __SecDateTEdit varchar(30),
		IN __PayGroup bigint(20),
		IN __clinic_id INT(10),
		IN __update_mode char(1),
		IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ClaimPaymentNum into __temAptNum from jd_claimpayment where ClaimPaymentNum = __ClaimPaymentNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_claimpayment set

			CheckDate = __CheckDate
			,CheckAmt = __CheckAmt
			,CheckNum = __CheckNum
			,BankBranch = __BankBranch
			,Note = __Note
			,ClinicNum = __ClinicNum
			,DepositNum = __DepositNum
			,CarrierName = __CarrierName
			,DateIssued = __DateIssued
			,IsPartial = __IsPartial
			,PayType = __PayType
			,SecUserNumEntry = __SecUserNumEntry
			,SecDateEntry = __SecDateEntry
			,SecDateTEdit = __SecDateTEdit
			,PayGroup = __PayGroup
			,clinic_id = __clinic_id
			,update_mode = __update_mode
			,updatedon = __updatedon
			WHERE ClaimPaymentNum = __ClaimPaymentNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_claimpayment (
				ClaimPaymentNum,
				CheckDate,
				CheckAmt,
				CheckNum,
				BankBranch,
				Note,
				ClinicNum,
				DepositNum,
				CarrierName,
				DateIssued,
				IsPartial,
				PayType,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				PayGroup,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__ClaimPaymentNum,
				__CheckDate,
				__CheckAmt,
				__CheckNum,
				__BankBranch,
				__Note,
				__ClinicNum,
				__DepositNum,
				__CarrierName,
				__DateIssued,
				__IsPartial,
				__PayType,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__PayGroup,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_claimproc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_claimproc`(
			IN __ClaimProcNum bigint(20),
			IN __ProcNum bigint(20),
			IN __ClaimNum bigint(20),
			IN __PatNum bigint(20),
			IN __ProvNum bigint(20),
			IN __FeeBilled double,
			IN __InsPayEst double,
			IN __DedApplied double,
			IN __Status tinyint(3) unsigned,
			IN __InsPayAmt double,
			IN __Remarks varchar(255),
			IN __ClaimPaymentNum bigint(20),
			IN __PlanNum bigint(20),
			IN __DateCP varchar(30),
			IN __WriteOff double,
			IN __CodeSent varchar(15),
			IN __AllowedOverride double,
			IN __Percentage tinyint(4),
			IN __PercentOverride tinyint(4),
			IN __CopayAmt double,
			IN __NoBillIns tinyint(3) unsigned,
			IN __PaidOtherIns double,
			IN __BaseEst double,
			IN __CopayOverride double,
			IN __ProcDate varchar(30),
			IN __DateEntry varchar(30),
			IN __LineNumber tinyint(3) unsigned,
			IN __DedEst double,
			IN __DedEstOverride double,
			IN __InsEstTotal double,
			IN __InsEstTotalOverride double,
			IN __PaidOtherInsOverride double,
			IN __EstimateNote varchar(255),
			IN __WriteOffEst double,
			IN __WriteOffEstOverride double,
			IN __ClinicNum bigint(20),
			IN __InsSubNum bigint(20),
			IN __PaymentRow int(11),
			IN __PayPlanNum bigint(20),
			IN __ClaimPaymentTracking bigint(20),
			IN __SecUserNumEntry bigint(20),
			IN __SecDateEntry varchar(30),
			IN __SecDateTEdit varchar(30), -- timestamp
			IN __DateSuppReceived varchar(30),
			IN __DateInsFinalized varchar(30),
			IN __IsTransfer tinyint(4),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ClaimProcNum into __temAptNum from jd_claimproc where ClaimProcNum = __ClaimProcNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_claimproc set
				ProcNum = __ProcNum
				,ClaimNum = __ClaimNum
				,PatNum = __PatNum
				,ProvNum = __ProvNum
				,FeeBilled = __FeeBilled
				,InsPayEst = __InsPayEst
				,DedApplied = __DedApplied
				,Status = __Status
				,InsPayAmt = __InsPayAmt
				,Remarks = __Remarks
				,ClaimPaymentNum = __ClaimPaymentNum
				,PlanNum = __PlanNum
				,DateCP = __DateCP
				,WriteOff = __WriteOff
				,CodeSent = __CodeSent
				,AllowedOverride = __AllowedOverride
				,Percentage = __Percentage
				,PercentOverride = __PercentOverride
				,CopayAmt = __CopayAmt
				,NoBillIns = __NoBillIns
				,PaidOtherIns = __PaidOtherIns
				,BaseEst = __BaseEst
				,CopayOverride = __CopayOverride
				,ProcDate = __ProcDate
				,DateEntry = __DateEntry
				,LineNumber = __LineNumber
				,DedEst = __DedEst
				,DedEstOverride = __DedEstOverride
				,InsEstTotal = __InsEstTotal
				,InsEstTotalOverride = __InsEstTotalOverride
				,PaidOtherInsOverride = __PaidOtherInsOverride
				,EstimateNote = __EstimateNote
				,WriteOffEst = __WriteOffEst
				,WriteOffEstOverride = __WriteOffEstOverride
				,ClinicNum = __ClinicNum
				,InsSubNum = __InsSubNum
				,PaymentRow = __PaymentRow
				,PayPlanNum = __PayPlanNum
				,ClaimPaymentTracking = __ClaimPaymentTracking
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateEntry = __SecDateEntry
				,SecDateTEdit = __SecDateTEdit
				,DateSuppReceived = __DateSuppReceived
				,DateInsFinalized = __DateInsFinalized
				,IsTransfer = __IsTransfer
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE ClaimProcNum = __ClaimProcNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_claimproc (
				ClaimProcNum,
				ProcNum,
				ClaimNum,
				PatNum,
				ProvNum,
				FeeBilled,
				InsPayEst,
				DedApplied,
				Status,
				InsPayAmt,
				Remarks,
				ClaimPaymentNum,
				PlanNum,
				DateCP,
				WriteOff,
				CodeSent,
				AllowedOverride,
				Percentage,
				PercentOverride,
				CopayAmt,
				NoBillIns,
				PaidOtherIns,
				BaseEst,
				CopayOverride,
				ProcDate,
				DateEntry,
				LineNumber,
				DedEst,
				DedEstOverride,
				InsEstTotal,
				InsEstTotalOverride,
				PaidOtherInsOverride,
				EstimateNote,
				WriteOffEst,
				WriteOffEstOverride,
				ClinicNum,
				InsSubNum,
				PaymentRow,
				PayPlanNum,
				ClaimPaymentTracking,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				DateSuppReceived,
				DateInsFinalized,
				IsTransfer,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__ClaimProcNum,
				__ProcNum,
				__ClaimNum,
				__PatNum,
				__ProvNum,
				__FeeBilled,
				__InsPayEst,
				__DedApplied,
				__Status,
				__InsPayAmt,
				__Remarks,
				__ClaimPaymentNum,
				__PlanNum,
				__DateCP,
				__WriteOff,
				__CodeSent,
				__AllowedOverride,
				__Percentage,
				__PercentOverride,
				__CopayAmt,
				__NoBillIns,
				__PaidOtherIns,
				__BaseEst,
				__CopayOverride,
				__ProcDate,
				__DateEntry,
				__LineNumber,
				__DedEst,
				__DedEstOverride,
				__InsEstTotal,
				__InsEstTotalOverride,
				__PaidOtherInsOverride,
				__EstimateNote,
				__WriteOffEst,
				__WriteOffEstOverride,
				__ClinicNum,
				__InsSubNum,
				__PaymentRow,
				__PayPlanNum,
				__ClaimPaymentTracking,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__DateSuppReceived,
				__DateInsFinalized,
				__IsTransfer,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_clinic` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_clinic`(
	IN __id INT,
	IN __name varchar(2000),
	IN __groupof varchar(255),
	IN __address1 varchar(255),
	IN __address2 varchar(255),
	IN __city varchar(55),
	IN __state varchar(55),
	IN __zip varchar(10),
	IN __dentist_name varchar(255),
	IN __primary_contact varchar(255),
	IN __primary_phone varchar(20),
	IN __secondary_phone varchar(20),
	IN __primary_email varchar(255),
	IN __website varchar(2000),
	IN __appt_request_page varchar(2000),
	IN __comments varchar(255),
	IN __created_by INT,
    IN __guid varchar(100)
)
BEGIN
	DECLARE __result varchar(100);
    
    set __result = '';
	IF __id <= 0 THEN
    INSERT INTO clinic (
			name
			,groupof
			,address1
			,address2
			,city
			,state
			,zip
			,dentist_name
			,primary_contact
			,primary_phone
			,secondary_phone
			,primary_email
			,website
			,appt_request_page
			,comments
			,created_by    
            ,unique_id
    ) values (
		__name
		,__groupof
		,__address1
		,__address2
		,__city
		,__state
		,__zip
		,__dentist_name
		,__primary_contact
		,__primary_phone
		,__secondary_phone
		,__primary_email
		,__website
		,__appt_request_page
		,__comments
		,__created_by    
        ,__guid
    );
    set __result = 'success';
    ELSE
		update clinic set 
        name = __name
		,groupof = __groupof
		,address1 = __address1
		,address2 = __address2 
		,city = __city
		,state = __state
		,zip = __zip
		,dentist_name = __dentist_name
		,primary_contact = __primary_contact
		,primary_phone = __primary_phone
		,secondary_phone = __secondary_phone
		,primary_email = __primary_email
		,website = __website
		,appt_request_page = __appt_request_page
		,comments = __comments
		,created_by = __created_by
        where id = __id;
        set __result = 'success';
    END IF;
    select __result as result; 
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_commlog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_commlog`(
				IN __CommlogNum bigint(20),
				IN __PatNum bigint(20),
				IN __CommDateTime datetime,
				IN __CommType bigint(20),
				IN __Note text,
				IN __Mode_ tinyint(3) unsigned,
				IN __SentOrReceived tinyint(3) unsigned,
				IN __UserNum bigint(20),
				IN __Signature text,
				IN __SigIsTopaz tinyint(4),
				IN __DateTStamp timestamp,
				IN __DateTimeEnd datetime,
				IN __CommSource tinyint(4),
				IN __ProgramNum bigint(20),
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select CommlogNum into __temAptNum from jd_commlog where CommlogNum = __CommlogNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_commlog set
				PatNum = __PatNum
				,CommDateTime = __CommDateTime
				,CommType = __CommType
				,Note = __Note
				,Mode_ = __Mode_
				,SentOrReceived = __SentOrReceived
				,UserNum = __UserNum
				,Signature = __Signature
				,SigIsTopaz = __SigIsTopaz
				,DateTStamp = __DateTStamp
				,DateTimeEnd = __DateTimeEnd
				,CommSource = __CommSource
				,ProgramNum = __ProgramNum
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE CommlogNum = __CommlogNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_commlog (
				CommlogNum,
				PatNum,
				CommDateTime,
				CommType,
				Note,
				Mode_,
				SentOrReceived,
				UserNum,
				Signature,
				SigIsTopaz,
				DateTStamp,
				DateTimeEnd,
				CommSource,
				ProgramNum,
				clinic_id,
				update_mode,
				updatedon
			) values(
				__CommlogNum,
				__PatNum,
				__CommDateTime,
				__CommType,
				__Note,
				__Mode_,
				__SentOrReceived,
				__UserNum,
				__Signature,
				__SigIsTopaz,
				__DateTStamp,
				__DateTimeEnd,
				__CommSource,
				__ProgramNum,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_confirmationrequest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_confirmationrequest`(
				IN __ConfirmationRequestNum bigint(20),
				IN __ClinicNum bigint(20),
				IN __IsForSms tinyint(4),
				IN __IsForEmail tinyint(4),
				IN __PatNum bigint(20),
				IN __ApptNum bigint(20),
				IN __PhonePat varchar(255),
				IN __DateTimeConfirmExpire varchar(30),
				IN __SecondsFromEntryToExpire int(11),
				IN __ShortGUID varchar(255),
				IN __ConfirmCode varchar(255),
				IN __MsgTextToMobileTemplate text,
				IN __MsgTextToMobile text,
				IN __EmailSubjTemplate text,
				IN __EmailSubj text,
				IN __EmailTextTemplate text,
				IN __EmailText text,
				IN __DateTimeEntry varchar(30),
				IN __DateTimeConfirmTransmit varchar(30),
				IN __DateTimeRSVP varchar(30),
				IN __RSVPStatus tinyint(4),
				IN __ResponseDescript text,
				IN __GuidMessageToMobile text,
				IN __GuidMessageFromMobile text,
				IN __ShortGuidEmail varchar(255),
				IN __AptDateTimeOrig varchar(30),
				IN __TSPrior bigint(20),
				IN __DoNotResend tinyint(4),
				IN __SmsSentOk tinyint(4),
				IN __EmailSentOk tinyint(4),
				IN __ApptReminderRuleNum bigint(20),
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ConfirmationRequestNum into __temAptNum from jd_confirmationrequest where ConfirmationRequestNum = __ConfirmationRequestNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_confirmationrequest set
				ClinicNum = __ClinicNum
				,IsForSms = __IsForSms
				,IsForEmail = __IsForEmail
				,PatNum = __PatNum
				,ApptNum = __ApptNum
				,PhonePat = __PhonePat
				,DateTimeConfirmExpire = __DateTimeConfirmExpire
				,SecondsFromEntryToExpire = __SecondsFromEntryToExpire
				,ShortGUID = __ShortGUID
				,ConfirmCode = __ConfirmCode
				,MsgTextToMobileTemplate = __MsgTextToMobileTemplate
				,MsgTextToMobile = __MsgTextToMobile
				,EmailSubjTemplate = __EmailSubjTemplate
				,EmailSubj = __EmailSubj
				,EmailTextTemplate = __EmailTextTemplate
				,EmailText = __EmailText
				,DateTimeEntry = __DateTimeEntry
				,DateTimeConfirmTransmit = __DateTimeConfirmTransmit
				,DateTimeRSVP = __DateTimeRSVP
				,RSVPStatus = __RSVPStatus
				,ResponseDescript = __ResponseDescript
				,GuidMessageToMobile = __GuidMessageToMobile
				,GuidMessageFromMobile = __GuidMessageFromMobile
				,ShortGuidEmail = __ShortGuidEmail
				,AptDateTimeOrig = __AptDateTimeOrig
				,TSPrior = __TSPrior
				,DoNotResend = __DoNotResend
				,SmsSentOk = __SmsSentOk
				,EmailSentOk = __EmailSentOk
				,ApptReminderRuleNum = __ApptReminderRuleNum
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE ConfirmationRequestNum = __ConfirmationRequestNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_confirmationrequest (
				ConfirmationRequestNum,
				ClinicNum,
				IsForSms,
				IsForEmail,
				PatNum,
				ApptNum,
				PhonePat,
				DateTimeConfirmExpire,
				SecondsFromEntryToExpire,
				ShortGUID,
				ConfirmCode,
				MsgTextToMobileTemplate,
				MsgTextToMobile,
				EmailSubjTemplate,
				EmailSubj,
				EmailTextTemplate,
				EmailText,
				DateTimeEntry,
				DateTimeConfirmTransmit,
				DateTimeRSVP,
				RSVPStatus,
				ResponseDescript,
				GuidMessageToMobile,
				GuidMessageFromMobile,
				ShortGuidEmail,
				AptDateTimeOrig,
				TSPrior,
				DoNotResend,
				SmsSentOk,
				EmailSentOk,
				ApptReminderRuleNum,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__ConfirmationRequestNum,
				__ClinicNum,
				__IsForSms,
				__IsForEmail,
				__PatNum,
				__ApptNum,
				__PhonePat,
				__DateTimeConfirmExpire,
				__SecondsFromEntryToExpire,
				__ShortGUID,
				__ConfirmCode,
				__MsgTextToMobileTemplate,
				__MsgTextToMobile,
				__EmailSubjTemplate,
				__EmailSubj,
				__EmailTextTemplate,
				__EmailText,
				__DateTimeEntry,
				__DateTimeConfirmTransmit,
				__DateTimeRSVP,
				__RSVPStatus,
				__ResponseDescript,
				__GuidMessageToMobile,
				__GuidMessageFromMobile,
				__ShortGuidEmail,
				__AptDateTimeOrig,
				__TSPrior,
				__DoNotResend,
				__SmsSentOk,
				__EmailSentOk,
				__ApptReminderRuleNum,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_content_signature` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_content_signature`(
	IN __guid varchar(100),
	IN __id INT
    ,IN __name varchar(1000)
	,IN __content mediumtext
	,IN __content_text mediumtext
	,IN __updatedon datetime
	,IN __updatedby INT
	,IN __comments varchar(5000)
)
BEGIN
	DECLARE __temp_template_signature_id INT DEFAULT 0;
    DECLARE __result varchar(100);
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0 ) THEN
		insert into template_signature (
		name
        ,content
		,content_text
		,createdby
		,comments
        ,clinic_id
        )
        values (
			__name
            ,__content
			,__content_text
            ,__updatedby
            ,__comments
            ,__clinic_id
        );
		SET __temp_template_signature_id = LAST_INSERT_ID();
        SET __result = 'success';
	ELSE
		update template_signature set
		name = __name
        ,content = __content
		,content_text = __content_text
		,updatedon = __updatedon
		,updatedby = __updatedby
		,comments = __comments
        where id = __id and clinic_id = __clinic_id;
        SET __temp_template_signature_id = __id;
        SET __result = 'success';
	END IF;
	select __temp_template_signature_id as signature_id, __result as result;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_customer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_customer`(
			IN 	__id INT
			,IN __guid varchar(1000)
			,IN __name varchar(2250)
			,IN __Address1 varchar(1250)
			,IN __Address2 varchar(1250)
			,IN __city varchar(250)
			,IN __state varchar(250)
			,IN __zip varchar(20)
			,IN __gstin varchar(50)
			,IN __vendorcode varchar(50)
            ,IN __primarycontact varchar(250)
            ,IN __contactno varchar(50)
            ,IN __primaryemail varchar(250)
			,IN __createdon varchar(30)
			,IN __createdby INT
			,IN __comments varchar(2000)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;

    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF length(__name) > 0  or length(__gstin) > 0 THEN
		select id into __temp_id from customer where lcase(name) = lcase(__name) and lcase(gstin) = lcase(__gstin);
    END IF;
    
    IF __id > 0 THEN
		Update customer  set
        name = __name
        ,Address1 	= __Address1
        ,Address2 	= __Address2
        ,city = __city
        ,state 	= __state
        ,zip	= __zip
        ,gstin = __gstin
        ,vendorcode = __vendorcode
        ,primarycontact = __primarycontact
        ,contactno = __contactno
        ,primaryemail = __primaryemail
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __id;
        set __custresult_id = __id ;
	ELSEIF __temp_id > 0 THEN
		Update customer  set
        name = __name
        ,Address1 	= __Address1
        ,Address2 	= __Address2
        ,city = __city
        ,state 	= __state
        ,zip	= __zip
        ,gstin = __gstin
        ,vendorcode = __vendorcode
        ,primarycontact = __primarycontact
        ,contactno = __contactno
        ,primaryemail = __primaryemail
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __temp_id;
        set __custresult_id = __temp_id ;    
	ELSEIF __id = 0 THEN
		IF length(__name) > 0 THEN
			INSERT INTO customer (
				organisation_id
				,name
				,Address1
				,Address2
				,city
				,state
				,zip
				,gstin
				,vendorcode
                ,primarycontact
                ,contactno
                ,primaryemail
				,createdon
				,createdby
				,comments
			) values (
				__organisation_id
				,__name
				,__Address1
				,__Address2
				,__city
				,__state
				,__zip
				,__gstin
				,__vendorcode
                ,__primarycontact
                ,__contactno
                ,__primaryemail                
				,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
				,__createdby
				,__comments
			);
		END IF;
		SET __custresult_id = LAST_INSERT_ID();
    END IF;
	select __custresult_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_definition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_definition`(
			IN __DefNum bigint(20),
			IN __Category tinyint(3) unsigned,
			IN __ItemOrder smallint(5) unsigned,
			IN __ItemName varchar(255),
			IN __ItemValue varchar(255),
			IN __ItemColor int(11),
			IN __IsHidden tinyint(3) unsigned,
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select DefNum into __temAptNum from jd_definition where DefNum = __DefNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_definition set
				Category = __Category
				,ItemOrder = __ItemOrder
				,ItemName = __ItemName
				,ItemValue = __ItemValue
				,ItemColor = __ItemColor
				,IsHidden = __IsHidden
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE DefNum = __DefNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_definition (
				DefNum,
				Category,
				ItemOrder,
				ItemName,
				ItemValue,
				ItemColor,
				IsHidden,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__DefNum,
				__Category,
				__ItemOrder,
				__ItemName,
				__ItemValue,
				__ItemColor,
				__IsHidden,
				__clinic_id,
				__update_mode,
				__updatedon

            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_deliverychallan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_deliverychallan`(
		IN __id int(11),
        IN __guid varchar(1000),
		IN __dc_prefix varchar(20),
		IN __dc_number bigint(11),
		IN __dc_date varchar(30),
		IN __customer_id int(11),
        IN __order_id varchar(200),
		IN __order_no varchar(200),
		IN __order_date datetime,
		IN __vendor_code varchar(20),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
        IN __status varchar(20),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
	set __organisation_id = func_get_organisation_id(__guid);
    
    IF __dc_number > 0 THEN
		select id into __temp_id from deliverychallan where dc_number = __dc_number and lcase(dc_prefix) = lcase(__dc_prefix)  and organisation_id = __organisation_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE deliverychallan_detail set active = 0 where dc_id = __id;
		UPDATE deliverychallan set
			dc_prefix = __dc_prefix
			,dc_number = __dc_number
			,dc_date = STR_TO_DATE(__dc_date, '%Y-%m-%d %H:%i:%s')
			,customer_id = __customer_id
            ,order_id = __order_id
			,order_no = __order_no
			,order_date = __order_date
			,vendor_code = __vendor_code
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,status = __status
			,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE deliverychallan_detail set active = 0 where dc_id = __temp_id;
		UPDATE deliverychallan set 
			dc_prefix = __dc_prefix
			,dc_number = __dc_number
			,dc_date = STR_TO_DATE(__dc_date, '%Y-%m-%d %H:%i:%s')
			,customer_id = __customer_id
            ,order_id = __order_id
			,order_no = __order_no
			,order_date = __order_date
			,vendor_code = __vendor_code
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,status = __status
			,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;
    
	ELSEIF __id = 0 THEN
		INSERT INTO deliverychallan (
			organisation_id
			,dc_prefix
			,dc_number
			,dc_date
			,customer_id
            ,order_id
			,order_no
			,order_date
			,vendor_code
			,createdon
			,createdby
            ,status
			,comments
        ) values (
			__organisation_id
			,__dc_prefix
			,__dc_number
			,STR_TO_DATE(__dc_date, '%Y-%m-%d %H:%i:%s')
			,__customer_id
            ,__order_id
			,__order_no
			,__order_date
			,__vendor_code
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
            ,__status
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    
	select __result_id as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_deliverychallan_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_deliverychallan_detail`(
		IN __id int(11),
		IN __dc_id int(11),
        IN __order_id int(11),
        IN __product_id int(11),
		IN __product_name varchar(1000),
        IN __process_id int(11),
		IN __hsn_sac varchar(100),
		IN __quantity bigint(11),
        IN __unit varchar(100),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;

    IF __product_id > 0 && __id = 0 THEN
		select id into __temp_id from deliverychallan_detail where product_id = __product_id and order_id = __order_id and dc_id = __dc_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE deliverychallan_detail set
			order_id = __order_id
            ,product_id = __product_id
			,product_name = __product_name
            ,process_id = __process_id
			,hsn_sac = __hsn_sac
			,quantity = __quantity
            ,unit = __unit
			,amount = __amount
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __id
			and dc_id = __dc_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE deliverychallan_detail set
			order_id = __order_id
            ,product_id = __product_id
			,product_name = __product_name
            ,process_id = __process_id
			,hsn_sac = __hsn_sac
			,quantity = __quantity
            ,unit = __unit
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __temp_id
			and dc_id = __dc_id;
		set __result_id = __temp_id;
	ELSEIF __id = 0 THEN
		INSERT INTO deliverychallan_detail (
			dc_id
            ,order_id
            ,product_id
			,product_name
            ,process_id
			,hsn_sac
			,quantity
            ,unit
			,createdon
			,createdby
			,comments
        ) values (
			__dc_id
            ,__order_id
            ,__product_id
			,__product_name
            ,__process_id
			,__hsn_sac
			,__quantity
            ,__unit
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_document` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_document`(
			IN __DocNum bigint(20),
			IN __Description varchar(255),
			IN __DateCreated datetime,
			IN __DocCategory bigint(20),
			IN __PatNum bigint(20),
			IN __FileName varchar(255),
			IN __ImgType tinyint(3) unsigned,
			IN __IsFlipped tinyint(3) unsigned,
			IN __DegreesRotated smallint(6),
			IN __ToothNumbers varchar(255),
			IN __Note text,
			IN __SigIsTopaz tinyint(3) unsigned,
			IN __Signature text,
			IN __CropX int(11),
			IN __CropY int(11),
			IN __CropW int(11),
			IN __CropH int(11),
			IN __WindowingMin int(11),
			IN __WindowingMax int(11),
			IN __MountItemNum bigint(20),
			IN __DateTStamp timestamp,
			IN __RawBase64 mediumtext,
			IN __Thumbnail text,
			IN __ExternalGUID varchar(255),
			IN __ExternalSource varchar(255),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temDocNum bigint(20);
        
		Select DocNum into __temDocNum from jd_document where DocNum = __DocNum and clinic_id = __clinic_id limit 1;

		IF __temDocNum > 0 THEN
			UPDATE jd_document set
				Description = __Description
				,DateCreated = __DateCreated
				,DocCategory = __DocCategory
				,PatNum = __PatNum
				,FileName = __FileName
				,ImgType = __ImgType
				,IsFlipped = __IsFlipped
				,DegreesRotated = __DegreesRotated
				,ToothNumbers = __ToothNumbers
				,Note = __Note
				,SigIsTopaz = __SigIsTopaz
				,Signature = __Signature
				,CropX = __CropX
				,CropY = __CropY
				,CropW = __CropW
				,CropH = __CropH
				,WindowingMin = __WindowingMin
				,WindowingMax = __WindowingMax
				,MountItemNum = __MountItemNum
				,DateTStamp = __DateTStamp
				,RawBase64 = __RawBase64
				,Thumbnail = __Thumbnail
				,ExternalGUID = __ExternalGUID
				,ExternalSource = __ExternalSource
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE DocNum = __DocNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_document (
				DocNum,
				Description,
				DateCreated,
				DocCategory,
				PatNum,
				FileName,
				ImgType,
				IsFlipped,
				DegreesRotated,
				ToothNumbers,
                
				Note,
                SigIsTopaz,
				Signature,
				CropX,
				CropY,
				CropW,
				CropH,
				WindowingMin,
				WindowingMax,
				MountItemNum,
                
				DateTStamp,
				RawBase64,
				Thumbnail,
				ExternalGUID,
				ExternalSource,

				clinic_id,
				update_mode,
				updatedon

            ) values(
				__DocNum,
				__Description,
				__DateCreated,
				__DocCategory,
				__PatNum,
				__FileName,
				__ImgType,
				__IsFlipped,
				__DegreesRotated,
				__ToothNumbers,
                
				__Note,
				__SigIsTopaz,
				__Signature,
				__CropX,
				__CropY,
				__CropW,
				__CropH,
				__WindowingMin,
				__WindowingMax,
				__MountItemNum,
                
				__DateTStamp,
				__RawBase64,
				__Thumbnail,
				__ExternalGUID,
				__ExternalSource,

				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_forgot_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_forgot_password`(
    IN __accountId INT,
    IN __userId INT,
    IN __guid varchar(255),
    IN __expiry varchar(30)
)
BEGIN
	DECLARE __emailId varchar(200);
    
    select username into __emailId from user where id = __userId limit 1;
    
    IF isnull(__userId) THEN
		select '0' as id, Concat('User with Email ''', __emailId, ''' does not exist. \n please try again with valid email.')  as response ;
    ELSE 
		IF __userId > 0 THEN
			insert into histforgotpassword 
			(
				accountId
				,clinic_id
				,userId
				,emailId
				,guid
				,expirydatetime
			) 
			values 
			(
				0
				,__accountId
				,__userId
				,__emailId
				,__guid
				,date_format(__expiry, '%Y-%m-%d %H:%i')
			);
            select __userId as id, __emailId as email , 'guid has updated' as response;
        ELSE
            select '-1' as id, Concat('Email id ''', __emailId, ''' does not exist. please try with valid email id')  as response ;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_guardian` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_guardian`(
		IN __GuardianNum bigint(20),
		IN __PatNumChild bigint(20),
		IN __PatNumGuardian bigint(20),
		IN __Relationship tinyint(4),
		IN __IsGuardian tinyint(4),
		IN __clinic_id INT(10),
		IN __update_mode char(1),
		IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select GuardianNum into __temAptNum from jd_guardian where GuardianNum = __GuardianNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_guardian set
				PatNumChild = __PatNumChild
				,PatNumGuardian = __PatNumGuardian
				,Relationship = __Relationship
				,IsGuardian = __IsGuardian
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
			WHERE GuardianNum = __GuardianNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_guardian (
				GuardianNum,
				PatNumChild,
				PatNumGuardian,
				Relationship,
				IsGuardian,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__GuardianNum,
				__PatNumChild,
				__PatNumGuardian,
				__Relationship,
				__IsGuardian,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_histappointment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_histappointment`(
			IN __HistApptNum bigint(20),
			IN __HistUserNum bigint(20),
			IN __HistDateTStamp varchar(30),
			IN __HistApptAction tinyint(4),
			IN __ApptSource tinyint(4),
			IN __AptNum bigint(20),
			IN __PatNum bigint(20),
			IN __AptStatus tinyint(4),
			IN __Pattern varchar(255),
			IN __Confirmed bigint(20),
            
			IN __TimeLocked tinyint(4),
			IN __Op bigint(20),
			IN __Note text,
			IN __ProvNum bigint(20),
			IN __ProvHyg bigint(20),
			IN __AptDateTime varchar(30),
			IN __NextAptNum bigint(20),
			IN __UnschedStatus bigint(20),
			IN __IsNewPatient tinyint(4),
			IN __ProcDescript varchar(255),
            
			IN __Assistant bigint(20),
			IN __ClinicNum bigint(20),
			IN __IsHygiene tinyint(4),
			IN __DateTStamp varchar(30),
			IN __DateTimeArrived varchar(30),
			IN __DateTimeSeated varchar(30),
			IN __DateTimeDismissed varchar(30),
			IN __InsPlan1 bigint(20),
			IN __InsPlan2 bigint(20),
			IN __DateTimeAskedToArrive varchar(30),
            
			IN __ProcsColored text,
			IN __ColorOverride int(11),
			IN __AppointmentTypeNum bigint(20),
			IN __SecUserNumEntry bigint(20),
			IN __SecDateTEntry varchar(30),
			IN __Priority tinyint(4),
			IN __ProvBarText varchar(60),
			IN __PatternSecondary varchar(255),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
            
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select HistApptNum into __temAptNum from jd_histappointment where HistApptNum = __HistApptNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_histappointment set
				HistUserNum = __HistUserNum
				,HistDateTStamp = __HistDateTStamp
				,HistApptAction = __HistApptAction
				,ApptSource = __ApptSource
				,AptNum = __AptNum
				,PatNum = __PatNum
				,AptStatus = __AptStatus
				,Pattern = __Pattern
				,Confirmed = __Confirmed
				,TimeLocked = __TimeLocked
				,Op = __Op
				,Note = __Note
				,ProvNum = __ProvNum
				,ProvHyg = __ProvHyg
				,AptDateTime = __AptDateTime
				,NextAptNum = __NextAptNum
				,UnschedStatus = __UnschedStatus
				,IsNewPatient = __IsNewPatient
				,ProcDescript = __ProcDescript
				,Assistant = __Assistant
				,ClinicNum = __ClinicNum
				,IsHygiene = __IsHygiene
				,DateTStamp = __DateTStamp
				,DateTimeArrived = __DateTimeArrived
				,DateTimeSeated = __DateTimeSeated
				,DateTimeDismissed = __DateTimeDismissed
				,InsPlan1 = __InsPlan1
				,InsPlan2 = __InsPlan2
				,DateTimeAskedToArrive = __DateTimeAskedToArrive
				,ProcsColored = __ProcsColored
				,ColorOverride = __ColorOverride
				,AppointmentTypeNum = __AppointmentTypeNum
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateTEntry = __SecDateTEntry
				,Priority = __Priority
				,ProvBarText = __ProvBarText
				,PatternSecondary = __PatternSecondary
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE HistApptNum = __HistApptNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_histappointment (
					HistApptNum,
					HistUserNum,
					HistDateTStamp,
					HistApptAction,
					ApptSource,
					AptNum,
					PatNum,
					AptStatus,
					Pattern,
					Confirmed,
					TimeLocked,
					Op,
					Note,
					ProvNum,
					ProvHyg,
					AptDateTime,
					NextAptNum,
					UnschedStatus,
					IsNewPatient,
					ProcDescript,
					Assistant,
					ClinicNum,
					IsHygiene,
					DateTStamp,
					DateTimeArrived,
					DateTimeSeated,
					DateTimeDismissed,
					InsPlan1,
					InsPlan2,
					DateTimeAskedToArrive,
					ProcsColored,
					ColorOverride,
					AppointmentTypeNum,
					SecUserNumEntry,
					SecDateTEntry,
					Priority,
					ProvBarText,
					PatternSecondary,
					clinic_id,
					update_mode,
					updatedon
            ) values(
					__HistApptNum,
					__HistUserNum,
					__HistDateTStamp,
					__HistApptAction,
					__ApptSource,
					__AptNum,
					__PatNum,
					__AptStatus,
					__Pattern,
					__Confirmed,
					__TimeLocked,
					__Op,
					__Note,
					__ProvNum,
					__ProvHyg,
					__AptDateTime,
					__NextAptNum,
					__UnschedStatus,
					__IsNewPatient,
					__ProcDescript,
					__Assistant,
					__ClinicNum,
					__IsHygiene,
					__DateTStamp,
					__DateTimeArrived,
					__DateTimeSeated,
					__DateTimeDismissed,
					__InsPlan1,
					__InsPlan2,
					__DateTimeAskedToArrive,
					__ProcsColored,
					__ColorOverride,
					__AppointmentTypeNum,
					__SecUserNumEntry,
					__SecDateTEntry,
					__Priority,
					__ProvBarText,
					__PatternSecondary,
					__clinic_id,
					__update_mode,
					__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_insplan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_insplan`(
				IN __PlanNum bigint(20),
				IN __GroupName varchar(50),
				IN __GroupNum varchar(25),
				IN __PlanNote text,
				IN __FeeSched bigint(20),
				IN __PlanType char(1),
				IN __ClaimFormNum bigint(20),
				IN __UseAltCode tinyint(3) unsigned,
				IN __ClaimsUseUCR tinyint(3) unsigned,
				IN __CopayFeeSched bigint(20),
				IN __EmployerNum bigint(20),
				IN __CarrierNum bigint(20),
				IN __AllowedFeeSched bigint(20),
				IN __TrojanID varchar(100),
				IN __DivisionNo varchar(255),
				IN __IsMedical tinyint(3) unsigned,
				IN __FilingCode bigint(20),
				IN __DentaideCardSequence tinyint(3) unsigned,
				IN __ShowBaseUnits tinyint(1),
				IN __CodeSubstNone tinyint(1),
				IN __IsHidden tinyint(4),
				IN __MonthRenew tinyint(4),
				IN __FilingCodeSubtype bigint(20),
				IN __CanadianPlanFlag varchar(5),
				IN __CanadianDiagnosticCode varchar(255),
				IN __CanadianInstitutionCode varchar(255),
				IN __RxBIN varchar(255),
				IN __CobRule tinyint(4),
				IN __SopCode varchar(255),
				IN __SecUserNumEntry bigint(20),
				IN __SecDateEntry varchar(30),
				IN __SecDateTEdit varchar(30),
				IN __HideFromVerifyList tinyint(4),
				IN __OrthoType tinyint(4),
				IN __OrthoAutoProcFreq tinyint(4),
				IN __OrthoAutoProcCodeNumOverride bigint(20),
				IN __OrthoAutoFeeBilled double,
				IN __OrthoAutoClaimDaysWait int(11),
				IN __BillingType bigint(20),
				IN __HasPpoSubstWriteoffs tinyint(4),
				IN __ExclusionFeeRule tinyint(4),
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select PlanNum into __temAptNum from jd_insplan where PlanNum = __PlanNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_insplan set
				GroupName = __GroupName
				,GroupNum = __GroupNum
				,PlanNote = __PlanNote
				,FeeSched = __FeeSched
				,PlanType = __PlanType
				,ClaimFormNum = __ClaimFormNum
				,UseAltCode = __UseAltCode
				,ClaimsUseUCR = __ClaimsUseUCR
				,CopayFeeSched = __CopayFeeSched
				,EmployerNum = __EmployerNum
				,CarrierNum = __CarrierNum
				,AllowedFeeSched = __AllowedFeeSched
				,TrojanID = __TrojanID
				,DivisionNo = __DivisionNo
				,IsMedical = __IsMedical
				,FilingCode = __FilingCode
				,DentaideCardSequence = __DentaideCardSequence
				,ShowBaseUnits = __ShowBaseUnits
				,CodeSubstNone = __CodeSubstNone
				,IsHidden = __IsHidden
				,MonthRenew = __MonthRenew
				,FilingCodeSubtype = __FilingCodeSubtype
				,CanadianPlanFlag = __CanadianPlanFlag
				,CanadianDiagnosticCode = __CanadianDiagnosticCode
				,CanadianInstitutionCode = __CanadianInstitutionCode
				,RxBIN = __RxBIN
				,CobRule = __CobRule
				,SopCode = __SopCode
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateEntry = __SecDateEntry
				,SecDateTEdit = __SecDateTEdit
				,HideFromVerifyList = __HideFromVerifyList
				,OrthoType = __OrthoType
				,OrthoAutoProcFreq = __OrthoAutoProcFreq
				,OrthoAutoProcCodeNumOverride = __OrthoAutoProcCodeNumOverride
				,OrthoAutoFeeBilled = __OrthoAutoFeeBilled
				,OrthoAutoClaimDaysWait = __OrthoAutoClaimDaysWait
				,BillingType = __BillingType
				,HasPpoSubstWriteoffs = __HasPpoSubstWriteoffs
				,ExclusionFeeRule = __ExclusionFeeRule
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon
				
			WHERE PlanNum = __PlanNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_insplan (
				PlanNum,
				GroupName,
				GroupNum,
				PlanNote,
				FeeSched,
				PlanType,
				ClaimFormNum,
				UseAltCode,
				ClaimsUseUCR,
				CopayFeeSched,
				EmployerNum,
				CarrierNum,
				AllowedFeeSched,
				TrojanID,
				DivisionNo,
				IsMedical,
				FilingCode,
				DentaideCardSequence,
				ShowBaseUnits,
				CodeSubstNone,
				IsHidden,
				MonthRenew,
				FilingCodeSubtype,
				CanadianPlanFlag,
				CanadianDiagnosticCode,
				CanadianInstitutionCode,
				RxBIN,
				CobRule,
				SopCode,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				HideFromVerifyList,
				OrthoType,
				OrthoAutoProcFreq,
				OrthoAutoProcCodeNumOverride,
				OrthoAutoFeeBilled,
				OrthoAutoClaimDaysWait,
				BillingType,
				HasPpoSubstWriteoffs,
				ExclusionFeeRule,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__PlanNum,
				__GroupName,
				__GroupNum,
				__PlanNote,
				__FeeSched,
				__PlanType,
				__ClaimFormNum,
				__UseAltCode,
				__ClaimsUseUCR,
				__CopayFeeSched,
				__EmployerNum,
				__CarrierNum,
				__AllowedFeeSched,
				__TrojanID,
				__DivisionNo,
				__IsMedical,
				__FilingCode,
				__DentaideCardSequence,
				__ShowBaseUnits,
				__CodeSubstNone,
				__IsHidden,
				__MonthRenew,
				__FilingCodeSubtype,
				__CanadianPlanFlag,
				__CanadianDiagnosticCode,
				__CanadianInstitutionCode,
				__RxBIN,
				__CobRule,
				__SopCode,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__HideFromVerifyList,
				__OrthoType,
				__OrthoAutoProcFreq,
				__OrthoAutoProcCodeNumOverride,
				__OrthoAutoFeeBilled,
				__OrthoAutoClaimDaysWait,
				__BillingType,
				__HasPpoSubstWriteoffs,
				__ExclusionFeeRule,
				__clinic_id,
				__update_mode,
				__updatedon

            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_inssub` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_inssub`(
			IN __InsSubNum bigint(20),
			IN __PlanNum bigint(20),
			IN __Subscriber bigint(20),
			IN __DateEffective varchar(30),
			IN __DateTerm varchar(30),
			IN __ReleaseInfo tinyint(4),
			IN __AssignBen tinyint(4),
			IN __SubscriberID varchar(255),
			IN __BenefitNotes text,
			IN __SubscNote text,
			IN __SecUserNumEntry bigint(20),
			IN __SecDateEntry varchar(30),
			IN __SecDateTEdit varchar(30),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select InsSubNum into __temAptNum from jd_inssub where InsSubNum = __InsSubNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_inssub set
				PlanNum = __PlanNum
				,Subscriber = __Subscriber
				,DateEffective = __DateEffective
				,DateTerm = __DateTerm
				,ReleaseInfo = __ReleaseInfo
				,AssignBen = __AssignBen
				,SubscriberID = __SubscriberID
				,BenefitNotes = __BenefitNotes
				,SubscNote = __SubscNote
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateEntry = __SecDateEntry
				,SecDateTEdit = __SecDateTEdit
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE InsSubNum = __InsSubNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_inssub (
				InsSubNum,
				PlanNum,
				Subscriber,
				DateEffective,
				DateTerm,
				ReleaseInfo,
				AssignBen,
				SubscriberID,
				BenefitNotes,
				SubscNote,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__InsSubNum,
				__PlanNum,
				__Subscriber,
				__DateEffective,
				__DateTerm,
				__ReleaseInfo,
				__AssignBen,
				__SubscriberID,
				__BenefitNotes,
				__SubscNote,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__clinic_id,
				__update_mode,
				__updatedon

            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_invoice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_invoice`(
		IN __id int(11),
        IN __guid varchar(1000),
		IN __inv_prefix varchar(20),
		IN __inv_number bigint(11),
		IN __inv_date varchar(30),
		IN __customer_id int(11),
        IN __order_id varchar(200),
		IN __order_no varchar(200),
		IN __order_date datetime,
		IN __vendor_code varchar(20),
		IN __amount_before_tax double(11,2),
        IN __inv_discount double(11,2),
		IN __cgst double(11,2),
		IN __sgst double(11,2),
		IN __amount_after_tax double(11,2),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
        IN __status varchar(20),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
	DECLARE strIDs varchar(150);
    DECLARE strNos varchar(150);
	DECLARE element_order_id varchar(150);    
    DECLARE element_order_no varchar(150);    
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;    
    
    IF __inv_number > 0 THEN
		select id into __temp_id from invoice where inv_number = __inv_number and lcase(inv_prefix) = lcase(__inv_prefix)  and organisation_id = __organisation_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE invoice_detail set active = 0 where invoice_id = __id;
		UPDATE invoice set
			inv_prefix = __inv_prefix
			,inv_number = __inv_number
			,inv_date = STR_TO_DATE(__inv_date, '%Y-%m-%d %H:%i:%s')
			,customer_id = __customer_id
            ,order_id = __order_id
			,order_no = __order_no
			,order_date = __order_date
			,vendor_code = __vendor_code
			,amount_before_tax = __amount_before_tax
            ,inv_discount = __inv_discount
			,cgst = __cgst
			,sgst = __sgst
			,amount_after_tax = __amount_after_tax
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,status = __status
			,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE invoice_detail set active = 0 where invoice_id = __temp_id;
		UPDATE invoice set 
			inv_prefix = __inv_prefix
			,inv_number = __inv_number
			,inv_date = STR_TO_DATE(__inv_date, '%Y-%m-%d %H:%i:%s')
			,customer_id = __customer_id
            ,order_id = __order_id
			,order_no = __order_no
			,order_date = __order_date
			,vendor_code = __vendor_code
			,amount_before_tax = __amount_before_tax
            ,inv_discount = __inv_discount
			,cgst = __cgst
			,sgst = __sgst
			,amount_after_tax = __amount_after_tax
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,status = __status
			,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;
    
	ELSEIF __id = 0 THEN
		INSERT INTO invoice (
			organisation_id
			,inv_prefix
			,inv_number
			,inv_date
			,customer_id
            ,order_id
			,order_no
			,order_date
			,vendor_code
			,amount_before_tax
            ,inv_discount
			,cgst
			,sgst
			,amount_after_tax
			,createdon
			,createdby
            ,status
			,comments
        ) values (
			__organisation_id
			,__inv_prefix
			,__inv_number
			,STR_TO_DATE(__inv_date, '%Y-%m-%d %H:%i:%s')
			,__customer_id
            ,__order_id
			,__order_no
			,__order_date
			,__vendor_code
			,__amount_before_tax
            ,__inv_discount
			,__cgst
			,__sgst
			,__amount_after_tax
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
            ,__status
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    
	UPDATE po_invoice_mapping set active = 0 where invoice_id = __result_id;

	SET strIDs = __order_id;
	SET strNos = __order_no;

	WHILE strIDs != '' DO
		SET element_order_id = SUBSTRING_INDEX(strIDs, ',', 1);      
		SET element_order_no = SUBSTRING_INDEX(strNos, ',', 1);      

		 insert into po_invoice_mapping (organisation_id, invoice_id, order_id, order_no) 
		 values (__organisation_id, __result_id, element_order_id, element_order_no);

		update purchaseorder set status = 'invoiced' where id = element_order_id;
        
		IF LOCATE(',', strIDs) > 0 THEN
		  SET strIDs = SUBSTRING(strIDs, LOCATE(',', strIDs) + 1);
		  SET strNos = SUBSTRING(strNos, LOCATE(',', strNos) + 1);
		ELSE
		  SET strIDs = '';
		  SET strNos = '';
		END IF;
	END WHILE;
    
    select __result_id as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_invoice_collection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_invoice_collection`(
		IN __id int(11),
        IN __collection_main_id int(11),
		IN __invoice_id int(11),
		IN __pay_mode varchar(20),
		IN __cheque_no varchar(50),
		IN __cheque_date varchar(30),
		IN __bank_id INT(11),
		IN __amount  double(11,2),
        IN __writeoff  double(11,2),
        IN __iscombined	bit(1),
        IN __combinedfor	varchar(1000),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    IF length(__cheque_no) > 0 THEN
		select id into __temp_id from invoice_collection where lcase(cheque_no) = lcase(__cheque_no) and bank_id = __bank_id and invoice_id = __invoice_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE invoice_collection set
			collection_main_id = __collection_main_id
			,pay_mode = __pay_mode
			,cheque_no = __cheque_no
			,cheque_date = STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,bank_id = __bank_id
			,amount = __amount
            ,writeoff = __writeoff
			,iscombined = __iscombined
			,combinedfor = __combinedfor
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __id
			and invoice_id = __invoice_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE invoice_collection set
			collection_main_id = __collection_main_id
			,pay_mode = __pay_mode
			,cheque_no = __cheque_no
			,cheque_date = STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,bank_id = __bank_id
			,amount = __amount
            ,writeoff = __writeoff
			,iscombined = __iscombined
			,combinedfor = __combinedfor
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
             ,active = 1
        WHERE id = __temp_id
			and invoice_id = __invoice_id;
		set __result_id = __temp_id;
	ELSEIF __id = 0 THEN
		INSERT INTO invoice_collection (
			collection_main_id
			,invoice_id
            ,pay_mode
			,cheque_no
			,cheque_date
			,bank_id
			,amount
            ,writeoff
			,iscombined
			,combinedfor
			,createdon
			,createdby
			,comments
        ) values (
			__collection_main_id
			,__invoice_id
			,__pay_mode
			,__cheque_no
			,STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,__bank_id
			,__amount
            ,__writeoff
			,__iscombined
			,__combinedfor
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    IF __result_id > 0 THEN
		Update invoice set status = 'completed' where id = __invoice_id;
		select __result_id as responseid, 'success' as response;	
	ELSE
		select __result_id as responseid, 'Failed to update collection details' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_invoice_collection_main` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_invoice_collection_main`(
		IN __id int(11),
		IN __guid varchar(100),
        IN __customer_id int(11),
		IN __pay_mode varchar(20),
		IN __cheque_no varchar(50),
		IN __cheque_date varchar(30),
		IN __bank_id INT(11),
		IN __amount  double(11,2),
        IN __writeoff  double(11,2),
        IN __iscombined	bit(1),
        IN __combinedfor	varchar(1000),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    DECLARE __bankName varchar(200) DEFAULT '';
    DECLARE __customerName varchar(200) DEFAULT '';
    

    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF; 
    
    IF length(__cheque_no) > 0 THEN
		select id into __temp_id from invoice_collection_main 
        where lcase(cheque_no) = lcase(__cheque_no) and bank_id = __bank_id and customer_id = __customer_id
        and organisation_id =  __organisation_id;
    END IF;    
    
	IF __id > 0 THEN
		Update invoice_collection set active = 0 where collection_main_id = __id;
		UPDATE invoice_collection_main set
			customer_id = __customer_id 
			,pay_mode = __pay_mode
			,cheque_no = __cheque_no
			,cheque_date = STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,bank_id = __bank_id
			,amount = __amount
            ,writeoff = __writeoff
			,iscombined = __iscombined
			,combinedfor = __combinedfor
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
        WHERE id = __id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		/*UPDATE invoice_collection_main set
			pay_mode = __pay_mode
			,cheque_no = __cheque_no
			,cheque_date = STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,bank_id = __bank_id
			,amount = __amount
            ,writeoff = __writeoff
			,iscombined = __iscombined
			,combinedfor = __combinedfor
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
        WHERE id = __temp_id
			and customer_id = __customer_id;*/
		set __result_id = -1; -- __temp_id;
        select bankname into __bankName from bank where id = __bank_id;
        select name into __customerName from customer where id = __customer_id;
	ELSEIF __id = 0 THEN
		INSERT INTO invoice_collection_main (
			organisation_id
			,customer_id
            ,pay_mode
			,cheque_no
			,cheque_date
			,bank_id
			,amount
            ,writeoff
			,iscombined
			,combinedfor
			,createdon
			,createdby
			,comments
        ) values (
			__organisation_id
			,__customer_id
			,__pay_mode
			,__cheque_no
			,STR_TO_DATE(__cheque_date, '%Y-%m-%d')
			,__bank_id
			,__amount
            ,__writeoff
			,__iscombined
			,__combinedfor
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    IF __result_id > 0 THEN
		select __result_id as responseid, 'success' as response;	
	ELSEIF __result_id = -1 THEN
        select 0 as responseid, Concat('Check number ', __cheque_no, ' for bank ', __bankName, ' already exist for customer ', __customerName)  as response;	
	ELSE
		select __result_id as responseid, 'Failed to update collection details' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_invoice_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_invoice_detail`(
		IN __id int(11),
		IN __invoice_id int(11),
        IN __order_id int(11),
        IN __product_id int(11),
		IN __product_name varchar(1000),
        IN __process_id int(11),
		IN __hsn_sac varchar(100),
		IN __quantity bigint(11),
        IN __unit varchar(100),
		IN __rate double(11,2),
		IN __amount  double(11,2),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;

    IF __product_id > 0 && __id = 0 THEN
		select id into __temp_id from invoice_detail where lcase(product_id) = __product_id and invoice_id = __invoice_id and order_id = __order_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE invoice_detail set
			order_id = __order_id
            ,product_id = __product_id
			,product_name = __product_name
            ,process_id = __process_id
			,hsn_sac = __hsn_sac
			,quantity = __quantity
            ,unit = __unit
			,rate = __rate
			,amount = __amount
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __id
			and invoice_id = __invoice_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE invoice_detail set
			order_id = __order_id
            ,product_id = __product_id
			,product_name = __product_name
            ,process_id = __process_id
			,hsn_sac = __hsn_sac
			,quantity = __quantity
            ,unit = __unit
			,rate = __rate
			,amount = __amount
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __temp_id
			and invoice_id = __invoice_id;
		set __result_id = __temp_id;
	ELSEIF __id = 0 THEN
		INSERT INTO invoice_detail (
			invoice_id
            ,order_id
            ,product_id
			,product_name
            ,process_id
			,hsn_sac
			,quantity
            ,unit
			,rate
			,amount
			,createdon
			,createdby
			,comments
        ) values (
			__invoice_id
            ,__order_id
            ,__product_id
			,__product_name
            ,__process_id
			,__hsn_sac
			,__quantity
            ,__unit
			,__rate
			,__amount
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_notes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_notes`(
		IN __note_id INT,
		IN __guid varchar(100),
        IN __patient_id INT,
		IN __title VARCHAR(255),
		IN __summary VARCHAR(2000),
		IN __category VARCHAR(20),
		IN __createdon VARCHAR(20),
		IN __createdby INT,
        IN __comments varchar(2000)
    )
BEGIN
	DECLARE __noteresult_id INT DEFAULT 0;

	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    IF __note_id > 0 THEN
		Update patient_notes  set
        patient_id = __patient_id
        ,title 	= __title
        ,summary 	= __summary
        ,category = __category
        ,updatedon 	= __createdon
        ,updatedby	= __createdby
        WHERE id = __note_id and clinic_id = __clinic_id;
        set __noteresult_id = __note_id ;
	ELSEIF __note_id = 0 THEN
		IF length(__title) > 0 THEN
			INSERT INTO patient_notes (
				clinic_id
                ,patient_id 
				,title
				,summary
				,category
				,createdon
				,createdby
                ,comments
			) values (
				__clinic_id
                ,__patient_id
				,__title
				,__summary
				,__category
				,__createdon
				,__createdby
				,__comments
			);
		END IF;
		SET __noteresult_id = LAST_INSERT_ID();
    END IF;
	select __noteresult_id as noteid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_od_document` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_od_document`(
		IN __guid varchar(100),
        IN __update_mode varchar(100),
		IN __dateCreated VARCHAR(30),
		IN __docCategory VARCHAR(155),
		IN __patientId INT,
		IN __fileName VARCHAR(255),
		IN __imageType INT,
        IN __externalSource CHAR(100)
    )
BEGIN
   DECLARE __def_id INT;
   DECLARE __item_order INT;
   DECLARE __document_id INT;
   DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);

   set @_def_id = 0;
   set @_DocNum = 0;
   
	IF __docCategory = 'consentform' THEN
		Select DefNum into @_def_id from jd_definition where lcase(ItemName) = lcase('consents') limit 1;
		
		IF @_def_id = 0 THEN
			select max(ItemOrder) +1 into @_item_order from jd_definition where Category = 18;
			
			insert into jd_definition (
					Category
					,ItemOrder
					,ItemName
					,ItemValue
					,ItemColor
					,IsHidden
					,clinic_id
					,update_mode
					,updatedon
				) values (
					18
					,@_item_order
					,'Consents'
					,'E'
					,0
					,0
					,__clinic_id
					,__update_mode
					,__dateCreated
				);
            
			Select DefNum into @_def_id from jd_definition where lcase(ItemName) = lcase('consents') and clinic_id = __clinic_id limit 1;
        END IF;
		
    ELSEIF __docCategory = 'treatmentplan' THEN
		Select DefNum into @_def_id from jd_definition where lcase(ItemName) = lcase('treatment plans') and clinic_id = __clinic_id limit 1;
        
		IF @_def_id = 0 THEN
			select max(ItemOrder) +1 into @_item_order from jd_definition where Category = 18 and clinic_id = __clinic_id;
            
				insert into jd_definition (
					Category
					,ItemOrder
					,ItemName
					,ItemValue
					,ItemColor
					,IsHidden
                    ,clinic_id
                    ,update_mode
                    ,updatedon                    
				) values (
					18
					,@_item_order
					,'Treatment Plans'
					,'E'
					,0
					,0
					,__clinic_id
                    ,__update_mode
                    ,__dateCreated);

			Select DefNum into @_def_id from jd_definition where lcase(ItemName) = lcase('treatment plans')  and clinic_id = __clinic_id limit 1;
        END IF;        
    END IF;
	select max(DocNum) into @_DocNum from jd_document;
    IF @_DocNum is null THEN
		set @_DocNum = 1;
	else
		set @_DocNum = @_DocNum + 1;
	End If;
    
    insert into jd_document 
				(
                DocNum,
                DateCreated, 
                DocCategory, 
                PatNum, 
                FileName, 
                ImgType, 
                DegreesRotated, 
                SigIsTopaz, 
                CropX, 
                CropY, 
                CropW, 
                CropH, 
                WindowingMin, 
                WindowingMax, 
                MountItemNum, 
                RawBase64, 
                Thumbnail, 
                ExternalGUID, 
                ExternalSource, 
                clinic_id, 
                update_mode, 
                updatedon) 
				values 
				(
					@_DocNum
                    ,STR_TO_DATE(__dateCreated, '%Y-%m-%d %H:%i:%s')
					,@_def_id
                    ,__patientId
                    ,__fileName
                    ,__imageType
					,0
                    ,0
					,0
					,0
					,0
					,0
					,0
					,0
                    ,0
					,''
                    ,''
					,''
					,__externalSource
					,__clinic_id
                    ,__update_mode
                    ,STR_TO_DATE(__dateCreated, '%Y-%m-%d %H:%i:%s')                     
				);
                
	SET __document_id = LAST_INSERT_ID();
	select __document_id as documentid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_opendental_configuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_opendental_configuration`(
	IN __guid varchar(100),
	IN __id INT,
    IN __image_path VARCHAR(2000),
	IN __reviewLink VARCHAR(2000),
    IN __feedbackLink VARCHAR(2000),
	IN __websiteLink VARCHAR(2000),
    IN __micrositeLink VARCHAR(2000),
	IN __other1Link VARCHAR(2000),
    IN __other2Link VARCHAR(2000),
    IN __createdby INT,
	IN __createdon varchar(30)
)
BEGIN
	DECLARE __result varchar(100);
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0) THEN
		INSERT INTO opendental_configuration (
			clinic_id
			,image_path
			,review_url
			,feedback_url
			,website_url
			,microsite_url
			,other1_url
			,other2_url
			,createdby
			,createdon
        ) values (
			__clinic_id
			,__image_path
			,__reviewLink
			,__feedbackLink
			,__websiteLink
			,__micrositeLink
			,__other1Link
			,__other2Link
			,__createdby
			,__createdon
        );
    ELSE
		UPDATE opendental_configuration set 
        image_path = __image_path
		,review_url = __reviewLink
		,feedback_url = __feedbackLink
		,website_url = __websiteLink
		,microsite_url = __micrositeLink
		,other1_url = __other1Link
		,other2_url = __other2Link
		,createdby = __createdby
		,createdon = __createdon
        WHERE id = __id and clinic_id = __clinic_id;
        SET __result = 'success';
    END IF;
	SET __result = 'success';
    select __result  as result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_operatory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_operatory`(
			IN __OperatoryNum bigint(20),
			IN __OpName varchar(255),
			IN __Abbrev varchar(255),
			IN __ItemOrder smallint(5) unsigned,
			IN __IsHidden tinyint(3) unsigned,
			IN __ProvDentist bigint(20),
			IN __ProvHygienist bigint(20),
			IN __IsHygiene tinyint(3) unsigned,
			IN __ClinicNum bigint(20),
			IN __DateTStamp timestamp,
			IN __SetProspective tinyint(4),
			IN __IsWebSched tinyint(4),
			IN __IsNewPatAppt tinyint(4),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select OperatoryNum into __temAptNum from jd_operatory where OperatoryNum = __OperatoryNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_operatory set
				OpName = __OpName
				,Abbrev = __Abbrev
				,ItemOrder = __ItemOrder
				,IsHidden = __IsHidden
				,ProvDentist = __ProvDentist
				,ProvHygienist = __ProvHygienist
				,IsHygiene = __IsHygiene
				,ClinicNum = __ClinicNum
				,DateTStamp = __DateTStamp
				,SetProspective = __SetProspective
				,IsWebSched = __IsWebSched
				,IsNewPatAppt = __IsNewPatAppt
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon


			WHERE OperatoryNum = __OperatoryNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_operatory (
				OperatoryNum,
				OpName,
				Abbrev,
				ItemOrder,
				IsHidden,
				ProvDentist,
				ProvHygienist,
				IsHygiene,
				ClinicNum,
				DateTStamp,
				SetProspective,
				IsWebSched,
				IsNewPatAppt,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__OperatoryNum,
				__OpName,
				__Abbrev,
				__ItemOrder,
				__IsHidden,
				__ProvDentist,
				__ProvHygienist,
				__IsHygiene,
				__ClinicNum,
				__DateTStamp,
				__SetProspective,
				__IsWebSched,
				__IsNewPatAppt,
				__clinic_id,
				__update_mode,
				__updatedon

            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_organisation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_organisation`(
			IN __id	int(11),
			IN __name	varchar(2000),
			IN __groupof	varchar(255),
			IN __address1	varchar(255),
			IN __address2	varchar(255),
			IN __city	varchar(55),
			IN __state	varchar(55),
			IN __zip	varchar(10),
			IN __ceo_name	varchar(255),
			IN __primary_contact	varchar(255),
			IN __primary_phone		varchar(20),
			IN __secondary_phone	varchar(20),
			IN __primary_email	varchar(255),
			IN __website	varchar(2000),
			IN __microsite	varchar(2000),
			IN __comments	varchar(2000),
			IN __createdon	varchar(30),
			IN __createdby	int(11)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    IF length(__name) > 0 THEN
		select id into __temp_id from organisation where lcase(name) = lcase(__name);
    END IF;
    
    IF __temp_id > 0 THEN
		UPDATE organisation SET 
			name = __name
			,groupof = __groupof 
			,address1 = __address1
			,address2 = __address2
			,city = __city
			,state = __state
			,zip = __zip
			,ceo_name = __ceo_name
			,primary_contact = __primary_contact
			,primary_phone = __primary_phone
			,secondary_phone = __secondary_phone
			,primary_email = __primary_email
			,website = __website
			,microsite = __microsite
			,comments = __comments
			,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __createdby
			WHERE id = __temp_id;
			set __result_id = __temp_id;
    ELSEIF __id > 0 THEN
		UPDATE organisation SET 
			name = __name
			,groupof = __groupof 
			,address1 = __address1
			,address2 = __address2
			,city = __city
			,state = __state
			,zip = __zip
			,ceo_name = __ceo_name
			,primary_contact = __primary_contact
			,primary_phone = __primary_phone
			,secondary_phone = __secondary_phone
			,primary_email = __primary_email
			,website = __website
			,microsite = __microsite
			,comments = __comments
			,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __createdby
			WHERE id = __id;
			set __result_id = __id;            
	ELSEIF __id = 0 THEN
		IF length(__name) > 0 THEN
			INSERT INTO organisation
			(
				name
				,groupof
				,address1
				,address2
				,city
				,state
				,zip
				,ceo_name
				,primary_contact
				,primary_phone
				,secondary_phone
				,primary_email
				,website
				,microsite
				,comments
				,createdon
				,createdby
			)
			values
			(
				__name
				,__groupof
				,__address1
				,__address2
				,__city
				,__state
				,__zip
				,__ceo_name
				,__primary_contact
				,__primary_phone
				,__secondary_phone
				,__primary_email
				,__website
				,__microsite
				,__comments
				,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
				,__createdby
			);   
        END IF;
        set __result_id = LAST_INSERT_ID();
    END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_organisation_bank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_organisation_bank`(
		IN 	__id INT
		,IN 	__organisation_id	int(11)
		,IN 	__bank_code	varchar(50)
		,IN 	__bank_id	INT(11)
        ,IN  	__bank_account varchar(250)
        ,IN  	__bank_ifsc varchar(30)
        ,IN  	__bank_micr varchar(30)
        ,IN  	__bank_branch varchar(500)
		,IN 	__createdon	varchar(30)
		,IN 	__createdby	int(11)    
        ,IN 	__comments	varchar(2000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    IF __bank_id > 0 THEN
		select id into __temp_id from organisation_bank where bank_id = __bank_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE organisation_bank set
		bank_code = __bank_code
        ,bank_id = __bank_id
        ,bank_account = __bank_account
        ,bank_ifsc = __bank_ifsc
        ,bank_micr = __bank_micr
        ,bank_branch = __bank_branch
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE organisation_bank set
		bank_code = __bank_code
        ,bank_id = __bank_id
        ,bank_account = __bank_account
        ,bank_ifsc = __bank_ifsc
        ,bank_micr = __bank_micr
        ,bank_branch = __bank_branch
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;
    
	ELSEIF __id = 0 THEN
		INSERT INTO organisation_bank (
			organisation_id
			,bank_code
			,bank_id
			,bank_account
			,bank_ifsc
			,bank_micr
			,bank_branch
			,comments
			,createdon
			,createdby
        ) values (
			__organisation_id
			,__bank_code
			,__bank_id
			,__bank_account
			,__bank_ifsc
			,__bank_micr
			,__bank_branch
            ,__comments
            ,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
            ,__createdby
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_organisation_gstin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_organisation_gstin`(
		IN 	__id INT
		,IN 	__organisation_id	int(11)
		,IN 	__gstin	varchar(50)
		,IN 	__legalname	varchar(2250)
        ,IN  	__constitution_of_business varchar(500)
        ,IN  	__liabilityon varchar(30)
        ,IN  	__registration_type varchar(500)
		,IN 	__createdon	varchar(30)
		,IN 	__createdby	int(11)    
        ,IN 	__comments	varchar(2000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    IF length(__gstin) > 0 THEN
		select id into __temp_id from organisation_gstin where lcase(gstin) = lcase(__gstin);
    END IF;
    
	IF __id > 0 THEN
		UPDATE organisation_gstin set
		gstin = __gstin
        ,legalname = legalname
        ,constitution_of_business = __constitution_of_business
        ,liabilityon = DATE(__liabilityon)
        ,registration_type = __registration_type
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE organisation_gstin set
		gstin = __gstin
        ,legalname = legalname
        ,constitution_of_business = __constitution_of_business
        ,liabilityon = DATE(__liabilityon)
        ,registration_type = __registration_type
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;    
	ELSEIF __id = 0 THEN
		INSERT INTO organisation_gstin (
			organisation_id
			,gstin
			,legalname
            ,constitution_of_business
            ,liabilityon
            ,registration_type
			,comments
			,createdon
			,createdby
        ) values (
			__organisation_id
            ,__gstin
            ,__legalname
            ,__constitution_of_business
            ,DATE(__liabilityon)
            ,__registration_type
            ,__comments
            ,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
            ,__createdby
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_organisation_service` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_organisation_service`(
		IN 	__id INT
		,IN 	__organisation_id	int(11)
		,IN 	__code	varchar(50)
		,IN 	__name	varchar(2250)
		,IN 	__createdon	varchar(30)
		,IN 	__createdby	int(11)    
        ,IN 	__comments	varchar(2000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    IF length(__name) > 0 THEN
		select id into __temp_id from organisation_service where lcase(name) = lcase(__name);
    END IF;
    
	IF __id > 0 THEN
		UPDATE organisation_service set
		code = __code
        ,name = __name
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE organisation_service set
		code = __code
        ,name = __name
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        ,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;    
	ELSEIF __id = 0 THEN
		INSERT INTO organisation_service (
			organisation_id
			,code
			,name
			,comments
			,createdon
			,createdby
        ) values (
			__organisation_id
            ,__code
            ,__name
            ,__comments
            ,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
            ,__createdby
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_patientdata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_patientdata`(
	IN __PatNum bigint(20),
	IN __LName varchar(100),
	IN __FName varchar(100),
	IN __MiddleI varchar(100),
	IN __Preferred varchar(100),
	IN __PatStatus tinyint(3) unsigned,
	IN __Gender tinyint(3) unsigned,
	IN __Position tinyint(3) unsigned,
	IN __Birthdate varchar(30),
	IN __SSN varchar(100),
	IN __Address varchar(100),
	IN __Address2 varchar(100),
	IN __City varchar(100),
	IN __State varchar(100),
	IN __Zip varchar(100),
	IN __HmPhone varchar(30),
	IN __WkPhone varchar(30),
	IN __WirelessPhone varchar(30),
	IN __Guarantor bigint(20),
	IN __CreditType char(1),
	IN __Email varchar(100),
	IN __Salutation varchar(100),
	IN __EstBalance double,
	IN __PriProv bigint(20),
	IN __SecProv bigint(20),
	IN __FeeSched bigint(20),
	IN __BillingType bigint(20),
	IN __ImageFolder varchar(100),
	IN __AddrNote text,
	IN __FamFinUrgNote text,
	IN __MedUrgNote varchar(255),
	IN __ApptModNote varchar(255),
	IN __StudentStatus char(1),
	IN __SchoolName varchar(255),
	IN __ChartNumber varchar(20),
	IN __MedicaidID varchar(20),
	IN __Bal_0_30 double,
	IN __Bal_31_60 double,
	IN __Bal_61_90 double,
	IN __BalOver90 double,
	IN __InsEst double,
	IN __BalTotal double,
	IN __EmployerNum bigint(20),
	IN __EmploymentNote varchar(255),
	IN __County varchar(255),
	IN __GradeLevel tinyint(4),
	IN __Urgency tinyint(4),
	IN __DateFirstVisit  varchar(30),
	IN __ClinicNum bigint(20),
	IN __HasIns varchar(255),
	IN __TrophyFolder varchar(255),
	IN __PlannedIsDone tinyint(3) unsigned,
	IN __Premed tinyint(3) unsigned,
	IN __Ward varchar(255),
	IN __PreferConfirmMethod tinyint(3) unsigned,
	IN __PreferContactMethod tinyint(3) unsigned,
	IN __PreferRecallMethod tinyint(3) unsigned,
	IN __SchedBeforeTime  varchar(30),
	IN __SchedAfterTime  varchar(30),
	IN __SchedDayOfWeek tinyint(3) unsigned,
	IN __Language varchar(100),
	IN __AdmitDate  varchar(30),
	IN __Title varchar(15),
	IN __PayPlanDue double,
	IN __SiteNum bigint(20),
	IN __DateTStamp varchar(30),
	IN __ResponsParty bigint(20),
	IN __CanadianEligibilityCode tinyint(4),
	IN __AskToArriveEarly int(11),
	IN __PreferContactConfidential tinyint(4),
	IN __SuperFamily bigint(20),
	IN __TxtMsgOk tinyint(4),
	IN __SmokingSnoMed varchar(32),
	IN __Country varchar(255),
	IN __DateTimeDeceased  varchar(30),
	IN __BillingCycleDay int(11),
	IN __SecUserNumEntry bigint(20),
	IN __SecDateEntry  varchar(30),
	IN __HasSuperBilling tinyint(4),
	IN __PatNumCloneFrom bigint(20),
	IN __DiscountPlanNum bigint(20),
	IN __HasSignedTil tinyint(4),
	IN __ShortCodeOptIn tinyint(4),
    IN __clinic_id INT(10),
    IN __update_mode char(1), -- R - Remote, D - Direct
    IN __updatedon varchar(30)
)
BEGIN
	
    DECLARE __temPatNum bigint(20);
    
    Select PatNum into __temPatNum from jd_patient where PatNum = __PatNum and clinic_id = __clinic_id limit 1;
    IF __temPatNum > 0 THEN
		UPDATE jd_patient set 
			LName = __LName
			,FName = __FName
			,MiddleI = __MiddleI
			,Preferred = __Preferred
			,PatStatus = __PatStatus
			,Gender = __Gender
			,Position = __Position
			,Birthdate = __Birthdate
			,SSN = __SSN
			,Address = __Address
			,Address2 = __Address2
			,City = __City
			,State = __State
			,Zip = __Zip
			,HmPhone = __HmPhone
			,WkPhone = __WkPhone
			,WirelessPhone = __WirelessPhone
			,Guarantor = __Guarantor
			,CreditType = __CreditType
			,Email = __Email
			,Salutation = __Salutation
			,EstBalance = __EstBalance
			,PriProv = __PriProv
			,SecProv = __SecProv
			,FeeSched = __FeeSched
			,BillingType = __BillingType
			,ImageFolder = __ImageFolder
			,AddrNote = __AddrNote
			,FamFinUrgNote = __FamFinUrgNote
			,MedUrgNote = __MedUrgNote
			,ApptModNote = __ApptModNote
			,StudentStatus = __StudentStatus
			,SchoolName = __SchoolName
			,ChartNumber = __ChartNumber
			,MedicaidID = __MedicaidID
			,Bal_0_30 = __Bal_0_30
			,Bal_31_60 = __Bal_31_60
			,Bal_61_90 = __Bal_61_90
			,BalOver90 = __BalOver90
			,InsEst = __InsEst
			,BalTotal = __BalTotal
			,EmployerNum = __EmployerNum
			,EmploymentNote = __EmploymentNote
			,County = __County
			,GradeLevel = __GradeLevel
			,Urgency = __Urgency
			,DateFirstVisit = __DateFirstVisit
			,ClinicNum = __ClinicNum
			,HasIns = __HasIns
			,TrophyFolder = __TrophyFolder
			,PlannedIsDone = __PlannedIsDone
			,Premed = __Premed
			,Ward = __Ward
			,PreferConfirmMethod = __PreferConfirmMethod
			,PreferContactMethod = __PreferContactMethod
			,PreferRecallMethod = __PreferRecallMethod
			,SchedBeforeTime = __SchedBeforeTime
			,SchedAfterTime = __SchedAfterTime
			,SchedDayOfWeek = __SchedDayOfWeek
			,Language = __Language
			,AdmitDate = __AdmitDate
			,Title = __Title
			,PayPlanDue = __PayPlanDue
			,SiteNum = __SiteNum
			,DateTStamp = __DateTStamp
			,ResponsParty = __ResponsParty
			,CanadianEligibilityCode = __CanadianEligibilityCode
			,AskToArriveEarly = __AskToArriveEarly
			,PreferContactConfidential = __PreferContactConfidential
			,SuperFamily = __SuperFamily
			,TxtMsgOk = __TxtMsgOk
			,SmokingSnoMed = __SmokingSnoMed
			,Country = __Country
			,DateTimeDeceased = __DateTimeDeceased
			,BillingCycleDay = __BillingCycleDay
			,SecUserNumEntry = __SecUserNumEntry
			,SecDateEntry = __SecDateEntry
			,HasSuperBilling = __HasSuperBilling
			,PatNumCloneFrom = __PatNumCloneFrom
			,DiscountPlanNum = __DiscountPlanNum
			,HasSignedTil = __HasSignedTil
			,ShortCodeOptIn = __ShortCodeOptIn
            ,updatedon = __updatedon
		WHERE PatNum = __PatNum 
			and clinic_id = __clinic_id;
	ELSE
		INSERT INTO  jd_patient (
			PatNum,
			LName,
			FName,
			MiddleI,
			Preferred,
			PatStatus,
			Gender,
			Position,
			Birthdate,
			SSN,
			Address,
			Address2,
			City,
			State,
			Zip,
			HmPhone,
			WkPhone,
			WirelessPhone,
			Guarantor,
			CreditType,
			Email,
			Salutation,
			EstBalance,
			PriProv,
			SecProv,
			FeeSched,
			BillingType,
			ImageFolder,
			AddrNote,
			FamFinUrgNote,
			MedUrgNote,
			ApptModNote,
			StudentStatus,
			SchoolName,
			ChartNumber,
			MedicaidID,
			Bal_0_30,
			Bal_31_60,
			Bal_61_90,
			BalOver90,
			InsEst,
			BalTotal,
			EmployerNum,
			EmploymentNote,
			County,
			GradeLevel,
			Urgency,
			DateFirstVisit,
			ClinicNum,
			HasIns,
			TrophyFolder,
			PlannedIsDone,
			Premed,
			Ward,
			PreferConfirmMethod,
			PreferContactMethod,
			PreferRecallMethod,
			SchedBeforeTime,
			SchedAfterTime,
			SchedDayOfWeek,
			Language,
			AdmitDate,
			Title,
			PayPlanDue,
			SiteNum,
			DateTStamp,
			ResponsParty,
			CanadianEligibilityCode,
			AskToArriveEarly,
			PreferContactConfidential,
			SuperFamily,
			TxtMsgOk,
			SmokingSnoMed,
			Country,
			DateTimeDeceased,
			BillingCycleDay,
			SecUserNumEntry,
			SecDateEntry,
			HasSuperBilling,
			PatNumCloneFrom,
			DiscountPlanNum,
			HasSignedTil,
			ShortCodeOptIn,
			clinic_id,
            update_mode,
            updatedon
        ) values (
			__PatNum,
			__LName,
			__FName,
			__MiddleI,
			__Preferred,
			__PatStatus,
			__Gender,
			__Position,
			__Birthdate,
			__SSN,
			__Address,
			__Address2,
			__City,
			__State,
			__Zip,
			__HmPhone,
			__WkPhone,
			__WirelessPhone,
			__Guarantor,
			__CreditType,
			__Email,
			__Salutation,
			__EstBalance,
			__PriProv,
			__SecProv,
			__FeeSched,
			__BillingType,
			__ImageFolder,
			__AddrNote,
			__FamFinUrgNote,
			__MedUrgNote,
			__ApptModNote,
			__StudentStatus,
			__SchoolName,
			__ChartNumber,
			__MedicaidID,
			__Bal_0_30,
			__Bal_31_60,
			__Bal_61_90,
			__BalOver90,
			__InsEst,
			__BalTotal,
			__EmployerNum,
			__EmploymentNote,
			__County,
			__GradeLevel,
			__Urgency,
			__DateFirstVisit,
			__ClinicNum,
			__HasIns,
			__TrophyFolder,
			__PlannedIsDone,
			__Premed,
			__Ward,
			__PreferConfirmMethod,
			__PreferContactMethod,
			__PreferRecallMethod,
			__SchedBeforeTime,
			__SchedAfterTime,
			__SchedDayOfWeek,
			__Language,
			__AdmitDate,
			__Title,
			__PayPlanDue,
			__SiteNum,
			__DateTStamp,
			__ResponsParty,
			__CanadianEligibilityCode,
			__AskToArriveEarly,
			__PreferContactConfidential,
			__SuperFamily,
			__TxtMsgOk,
			__SmokingSnoMed,
			__Country,
			__DateTimeDeceased,
			__BillingCycleDay,
			__SecUserNumEntry,
			__SecDateEntry,
			__HasSuperBilling,
			__PatNumCloneFrom,
			__DiscountPlanNum,
			__HasSignedTil,
			__ShortCodeOptIn,
			__clinic_id,
            __update_mode,
            __updatedon
        );
    END IF;
    select '1' as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_patplan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_patplan`(
			IN __PatPlanNum bigint(20),
			IN __PatNum bigint(20),
			IN __Ordinal tinyint(3) unsigned,
			IN __IsPending tinyint(3) unsigned,
			IN __Relationship tinyint(3) unsigned,
			IN __PatID varchar(100),
			IN __InsSubNum bigint(20),
			IN __OrthoAutoFeeBilledOverride double,
			IN __OrthoAutoNextClaimDate varchar(30),
			IN __SecDateTEntry varchar(30),
			IN __SecDateTEdit varchar(30),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)


)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select PatPlanNum into __temAptNum from jd_patplan where PatPlanNum = __PatPlanNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_patplan set
				PatNum = __PatNum
				,Ordinal = __Ordinal
				,IsPending = __IsPending
				,Relationship = __Relationship
				,PatID = __PatID
				,InsSubNum = __InsSubNum
				,OrthoAutoFeeBilledOverride = __OrthoAutoFeeBilledOverride
				,OrthoAutoNextClaimDate = __OrthoAutoNextClaimDate
				,SecDateTEntry = __SecDateTEntry
				,SecDateTEdit = __SecDateTEdit
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE PatPlanNum = __PatPlanNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_patplan (
				PatPlanNum,
				PatNum,
				Ordinal,
				IsPending,
				Relationship,
				PatID,
				InsSubNum,
				OrthoAutoFeeBilledOverride,
				OrthoAutoNextClaimDate,
				SecDateTEntry,
				SecDateTEdit,
				clinic_id,
				update_mode,
				updatedon


            ) values(
				__PatPlanNum,
				__PatNum,
				__Ordinal,
				__IsPending,
				__Relationship,
				__PatID,
				__InsSubNum,
				__OrthoAutoFeeBilledOverride,
				__OrthoAutoNextClaimDate,
				__SecDateTEntry,
				__SecDateTEdit,
				__clinic_id,
				__update_mode,
				__updatedon

            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_payment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_payment`(
			IN __PayNum bigint(20),
			IN __PayType bigint(20),
			IN __PayDate varchar(30),
			IN __PayAmt double,
			IN __CheckNum varchar(25),
			IN __BankBranch varchar(25),
			IN __PayNote text,
			IN __IsSplit tinyint(3) unsigned,
			IN __PatNum bigint(20),
			IN __ClinicNum bigint(20),
			IN __DateEntry varchar(30),
			IN __DepositNum bigint(20),
			IN __Receipt text,
			IN __IsRecurringCC tinyint(4),
			IN __SecUserNumEntry bigint(20),
			IN __SecDateTEdit varchar(30),
			IN __PaymentSource tinyint(4),
			IN __ProcessStatus tinyint(4),
			IN __RecurringChargeDate varchar(30),
			IN __ExternalId varchar(255),
			IN __PaymentStatus tinyint(4),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        DECLARE __isExternalIdExist INT;
        
		Select PayNum into __temAptNum from jd_payment where PayNum = __PayNum and clinic_id = __clinic_id limit 1;
        SELECT IF(count(*) > 0, TRUE, FALSE) INTO __isExternalIdExist
		  FROM information_schema.COLUMNS c
		  WHERE 
		  c.TABLE_SCHEMA    = 'justdentaldb'
		  AND c.TABLE_NAME  = 'jd_payment'
		  AND c.COLUMN_NAME = 'ExternalId';
		
        IF __isExternalIdExist >= 1 THEN
			IF __temAptNum > 0 THEN
				UPDATE jd_payment set
					PayType = __PayType
					,PayDate = __PayDate
					,PayAmt = __PayAmt
					,CheckNum = __CheckNum
					,BankBranch = __BankBranch
					,PayNote = __PayNote
					,IsSplit = __IsSplit
					,PatNum = __PatNum
					,ClinicNum = __ClinicNum
					,DateEntry = __DateEntry
					,DepositNum = __DepositNum
					,Receipt = __Receipt
					,IsRecurringCC = __IsRecurringCC
					,SecUserNumEntry = __SecUserNumEntry
					,SecDateTEdit = __SecDateTEdit
					,PaymentSource = __PaymentSource
					,ProcessStatus = __ProcessStatus
					,RecurringChargeDate = __RecurringChargeDate
					,ExternalId = __ExternalId
					,PaymentStatus = __PaymentStatus
					,clinic_id = __clinic_id
					,update_mode = __update_mode
					,updatedon = __updatedon

				WHERE PayNum = __PayNum
					and clinic_id = __clinic_id;
			ELSE
				insert into jd_payment (
					PayNum,
					PayType,
					PayDate,
					PayAmt,
					CheckNum,
					BankBranch,
					PayNote,
					IsSplit,
					PatNum,
					ClinicNum,
					DateEntry,
					DepositNum,
					Receipt,
					IsRecurringCC,
					SecUserNumEntry,
					SecDateTEdit,
					PaymentSource,
					ProcessStatus,
					RecurringChargeDate,
					ExternalId,
					PaymentStatus,
					clinic_id,
					update_mode,
					updatedon
				) values(
					__PayNum,
					__PayType,
					__PayDate,
					__PayAmt,
					__CheckNum,
					__BankBranch,
					__PayNote,
					__IsSplit,
					__PatNum,
					__ClinicNum,
					__DateEntry,
					__DepositNum,
					__Receipt,
					__IsRecurringCC,
					__SecUserNumEntry,
					__SecDateTEdit,
					__PaymentSource,
					__ProcessStatus,
					__RecurringChargeDate,
					__ExternalId,
					__PaymentStatus,
					__clinic_id,
					__update_mode,
					__updatedon
				);
			END IF;
        ELSE
			IF __temAptNum > 0 THEN
				UPDATE jd_payment set
					PayType = __PayType
					,PayDate = __PayDate
					,PayAmt = __PayAmt
					,CheckNum = __CheckNum
					,BankBranch = __BankBranch
					,PayNote = __PayNote
					,IsSplit = __IsSplit
					,PatNum = __PatNum
					,ClinicNum = __ClinicNum
					,DateEntry = __DateEntry
					,DepositNum = __DepositNum
					,Receipt = __Receipt
					,IsRecurringCC = __IsRecurringCC
					,SecUserNumEntry = __SecUserNumEntry
					,SecDateTEdit = __SecDateTEdit
					,PaymentSource = __PaymentSource
					,ProcessStatus = __ProcessStatus
					,RecurringChargeDate = __RecurringChargeDate
					,PaymentStatus = __PaymentStatus
					,clinic_id = __clinic_id
					,update_mode = __update_mode
					,updatedon = __updatedon
				WHERE PayNum = __PayNum
					and clinic_id = __clinic_id;
			ELSE
				insert into jd_payment (
					PayNum,
					PayType,
					PayDate,
					PayAmt,
					CheckNum,
					BankBranch,
					PayNote,
					IsSplit,
					PatNum,
					ClinicNum,
					DateEntry,
					DepositNum,
					Receipt,
					IsRecurringCC,
					SecUserNumEntry,
					SecDateTEdit,
					PaymentSource,
					ProcessStatus,
					RecurringChargeDate,
					PaymentStatus,
					clinic_id,
					update_mode,
					updatedon
				) values(
					__PayNum,
					__PayType,
					__PayDate,
					__PayAmt,
					__CheckNum,
					__BankBranch,
					__PayNote,
					__IsSplit,
					__PatNum,
					__ClinicNum,
					__DateEntry,
					__DepositNum,
					__Receipt,
					__IsRecurringCC,
					__SecUserNumEntry,
					__SecDateTEdit,
					__PaymentSource,
					__ProcessStatus,
					__RecurringChargeDate,
					__PaymentStatus,
					__clinic_id,
					__update_mode,
					__updatedon
				);
			END IF;        
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_paysplit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_paysplit`(
			IN __SplitNum bigint(20),
			IN __SplitAmt double,
			IN __PatNum bigint(20),
			IN __ProcDate varchar(30),
			IN __PayNum bigint(20),
			IN __IsDiscount tinyint(3) unsigned,
			IN __DiscountType tinyint(3) unsigned,
			IN __ProvNum bigint(20),
			IN __PayPlanNum bigint(20),
			IN __DatePay varchar(30),
			IN __ProcNum bigint(20),
			IN __DateEntry varchar(30),
			IN __UnearnedType bigint(20),
			IN __ClinicNum bigint(20),
			IN __SecUserNumEntry bigint(20),
			IN __SecDateTEdit varchar(30),
			IN __FSplitNum bigint(20),
			IN __AdjNum bigint(20),
			IN __PayPlanChargeNum bigint(20),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select SplitNum into __temAptNum from jd_paysplit where SplitNum = __SplitNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_paysplit set
				SplitAmt = __SplitAmt
				,PatNum = __PatNum
				,ProcDate = __ProcDate
				,PayNum = __PayNum
				,IsDiscount = __IsDiscount
				,DiscountType = __DiscountType
				,ProvNum = __ProvNum
				,PayPlanNum = __PayPlanNum
				,DatePay = __DatePay
				,ProcNum = __ProcNum
				,DateEntry = __DateEntry
				,UnearnedType = __UnearnedType
				,ClinicNum = __ClinicNum
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateTEdit = __SecDateTEdit
				,FSplitNum = __FSplitNum
				,AdjNum = __AdjNum
				,PayPlanChargeNum = __PayPlanChargeNum
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE SplitNum = __SplitNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_paysplit (
				SplitNum,
				SplitAmt,
				PatNum,
				ProcDate,
				PayNum,
				IsDiscount,
				DiscountType,
				ProvNum,
				PayPlanNum,
				DatePay,
				ProcNum,
				DateEntry,
				UnearnedType,
				ClinicNum,
				SecUserNumEntry,
				SecDateTEdit,
				FSplitNum,
				AdjNum,
				PayPlanChargeNum,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__SplitNum,
				__SplitAmt,
				__PatNum,
				__ProcDate,
				__PayNum,
				__IsDiscount,
				__DiscountType,
				__ProvNum,
				__PayPlanNum,
				__DatePay,
				__ProcNum,
				__DateEntry,
				__UnearnedType,
				__ClinicNum,
				__SecUserNumEntry,
				__SecDateTEdit,
				__FSplitNum,
				__AdjNum,
				__PayPlanChargeNum,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_procedurecode` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_procedurecode`(
				IN __CodeNum bigint(20),
				IN __ProcCode varchar(15),
				IN __Descript varchar(255),
				IN __AbbrDesc varchar(50),
				IN __ProcTime varchar(24),
				IN __ProcCat bigint(20),
				IN __TreatArea tinyint(3) unsigned,
				IN __NoBillIns tinyint(3) unsigned,
				IN __IsProsth tinyint(3) unsigned,
				IN __DefaultNote text,
				IN __IsHygiene tinyint(3) unsigned,
				IN __GTypeNum smallint(5) unsigned,
				IN __AlternateCode1 varchar(15),
				IN __MedicalCode varchar(15),
				IN __IsTaxed tinyint(3) unsigned,
				IN __PaintType tinyint(4),
				IN __GraphicColor int(11),
				IN __LaymanTerm varchar(255),
				IN __IsCanadianLab tinyint(3) unsigned,
				IN __PreExisting tinyint(1),
				IN __BaseUnits int(11),
				IN __SubstitutionCode varchar(25),
				IN __SubstOnlyIf int(11),
				IN __DateTStamp varchar(30),
				IN __IsMultiVisit tinyint(4),
				IN __DrugNDC varchar(255),
				IN __RevenueCodeDefault varchar(255),
				IN __ProvNumDefault bigint(20),
				IN __CanadaTimeUnits double,
				IN __IsRadiology tinyint(4),
				IN __DefaultClaimNote text,
				IN __DefaultTPNote text,
				IN __BypassGlobalLock tinyint(4),
				IN __TaxCode varchar(16),
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select CodeNum into __temAptNum from jd_procedurecode where CodeNum = __CodeNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_procedurecode set
				ProcCode = __ProcCode
				,Descript = __Descript
				,AbbrDesc = __AbbrDesc
				,ProcTime = __ProcTime
				,ProcCat = __ProcCat
				,TreatArea = __TreatArea
				,NoBillIns = __NoBillIns
				,IsProsth = __IsProsth
				,DefaultNote = __DefaultNote
				,IsHygiene = __IsHygiene
				,GTypeNum = __GTypeNum
				,AlternateCode1 = __AlternateCode1
				,MedicalCode = __MedicalCode
				,IsTaxed = __IsTaxed
				,PaintType = __PaintType
				,GraphicColor = __GraphicColor
				,LaymanTerm = __LaymanTerm
				,IsCanadianLab = __IsCanadianLab
				,PreExisting = __PreExisting
				,BaseUnits = __BaseUnits
				,SubstitutionCode = __SubstitutionCode
				,SubstOnlyIf = __SubstOnlyIf
				,DateTStamp = __DateTStamp
				,IsMultiVisit = __IsMultiVisit
				,DrugNDC = __DrugNDC
				,RevenueCodeDefault = __RevenueCodeDefault
				,ProvNumDefault = __ProvNumDefault
				,CanadaTimeUnits = __CanadaTimeUnits
				,IsRadiology = __IsRadiology
				,DefaultClaimNote = __DefaultClaimNote
				,DefaultTPNote = __DefaultTPNote
				,BypassGlobalLock = __BypassGlobalLock
				,TaxCode = __TaxCode
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE CodeNum = __CodeNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_procedurecode (
				CodeNum,
				ProcCode,
				Descript,
				AbbrDesc,
				ProcTime,
				ProcCat,
				TreatArea,
				NoBillIns,
				IsProsth,
				DefaultNote,
				IsHygiene,
				GTypeNum,
				AlternateCode1,
				MedicalCode,
				IsTaxed,
				PaintType,
				GraphicColor,
				LaymanTerm,
				IsCanadianLab,
				PreExisting,
				BaseUnits,
				SubstitutionCode,
				SubstOnlyIf,
				DateTStamp,
				IsMultiVisit,
				DrugNDC,
				RevenueCodeDefault,
				ProvNumDefault,
				CanadaTimeUnits,
				IsRadiology,
				DefaultClaimNote,
				DefaultTPNote,
				BypassGlobalLock,
				TaxCode,
				clinic_id,
				update_mode,
				updatedon
            ) values(
				__CodeNum,
				__ProcCode,
				__Descript,
				__AbbrDesc,
				__ProcTime,
				__ProcCat,
				__TreatArea,
				__NoBillIns,
				__IsProsth,
				__DefaultNote,
				__IsHygiene,
				__GTypeNum,
				__AlternateCode1,
				__MedicalCode,
				__IsTaxed,
				__PaintType,
				__GraphicColor,
				__LaymanTerm,
				__IsCanadianLab,
				__PreExisting,
				__BaseUnits,
				__SubstitutionCode,
				__SubstOnlyIf,
				__DateTStamp,
				__IsMultiVisit,
				__DrugNDC,
				__RevenueCodeDefault,
				__ProvNumDefault,
				__CanadaTimeUnits,
				__IsRadiology,
				__DefaultClaimNote,
				__DefaultTPNote,
				__BypassGlobalLock,
				__TaxCode,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_procedurelog` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_procedurelog`(
				IN __ProcNum bigint(20),
				IN __PatNum bigint(20),
				IN __AptNum bigint(20),
				IN __OldCode varchar(15),
				IN __ProcDate varchar(30),
				IN __ProcFee double,
				IN __Surf varchar(10),
				IN __ToothNum varchar(2),
				IN __ToothRange varchar(100),
				IN __Priority bigint(20),
				IN __ProcStatus tinyint(3) unsigned,
				IN __ProvNum bigint(20),
				IN __Dx bigint(20),
				IN __PlannedAptNum bigint(20),
				IN __PlaceService tinyint(3) unsigned,
				IN __Prosthesis char(1),
				IN __DateOriginalProsth varchar(30),
				IN __ClaimNote varchar(80),
				IN __DateEntryC varchar(30),
				IN __ClinicNum bigint(20),
				IN __MedicalCode varchar(15),
				IN __DiagnosticCode varchar(255),
				IN __IsPrincDiag tinyint(3) unsigned,
				IN __ProcNumLab bigint(20),
				IN __BillingTypeOne bigint(20),
				IN __BillingTypeTwo bigint(20),
				IN __CodeNum bigint(20),
				IN __CodeMod1 char(2),
				IN __CodeMod2 char(2),
				IN __CodeMod3 char(2),
				IN __CodeMod4 char(2),
				IN __RevCode varchar(45),
				IN __UnitQty int(11),
				IN __BaseUnits int(11),
				IN __StartTime int(11),
				IN __StopTime int(11),
				IN __DateTP varchar(30),
				IN __SiteNum bigint(20),
				IN __HideGraphics tinyint(4),
				IN __CanadianTypeCodes varchar(20),
				IN __ProcTime time,
				IN __ProcTimeEnd time,
				IN __DateTStamp timestamp,
				IN __Prognosis bigint(20),
				IN __DrugUnit tinyint(4),
				IN __DrugQty float,
				IN __UnitQtyType tinyint(4),
				IN __StatementNum bigint(20),
				IN __IsLocked tinyint(4),
				IN __BillingNote varchar(255),
				IN __RepeatChargeNum bigint(20),
				IN __SnomedBodySite varchar(255),
				IN __DiagnosticCode2 varchar(255),
				IN __DiagnosticCode3 varchar(255),
				IN __DiagnosticCode4 varchar(255),
				IN __ProvOrderOverride bigint(20),
				IN __Discount double,
				IN __IsDateProsthEst tinyint(4),
				IN __IcdVersion tinyint(3) unsigned,
				IN __IsCpoe tinyint(4),
				IN __SecUserNumEntry bigint(20),
				IN __SecDateEntry varchar(30),
				IN __DateComplete varchar(30),
				IN __OrderingReferralNum bigint(20),
				IN __TaxAmt double,
				IN __Urgency tinyint(4),
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)

)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ProcNum into __temAptNum from jd_procedurelog where ProcNum = __ProcNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_procedurelog set
				PatNum = __PatNum
				,AptNum = __AptNum
				,OldCode = __OldCode
				,ProcDate = __ProcDate
				,ProcFee = __ProcFee
				,Surf = __Surf
				,ToothNum = __ToothNum
				,ToothRange = __ToothRange
				,Priority = __Priority
				,ProcStatus = __ProcStatus
				,ProvNum = __ProvNum
				,Dx = __Dx
				,PlannedAptNum = __PlannedAptNum
				,PlaceService = __PlaceService
				,Prosthesis = __Prosthesis
				,DateOriginalProsth = __DateOriginalProsth
				,ClaimNote = __ClaimNote
				,DateEntryC = __DateEntryC
				,ClinicNum = __ClinicNum
				,MedicalCode = __MedicalCode
				,DiagnosticCode = __DiagnosticCode
				,IsPrincDiag = __IsPrincDiag
				,ProcNumLab = __ProcNumLab
				,BillingTypeOne = __BillingTypeOne
				,BillingTypeTwo = __BillingTypeTwo
				,CodeNum = __CodeNum
				,CodeMod1 = __CodeMod1
				,CodeMod2 = __CodeMod2
				,CodeMod3 = __CodeMod3
				,CodeMod4 = __CodeMod4
				,RevCode = __RevCode
				,UnitQty = __UnitQty
				,BaseUnits = __BaseUnits
				,StartTime = __StartTime
				,StopTime = __StopTime
				,DateTP = __DateTP
				,SiteNum = __SiteNum
				,HideGraphics = __HideGraphics
				,CanadianTypeCodes = __CanadianTypeCodes
				,ProcTime = __ProcTime
				,ProcTimeEnd = __ProcTimeEnd
				,DateTStamp = __DateTStamp
				,Prognosis = __Prognosis
				,DrugUnit = __DrugUnit
				,DrugQty = __DrugQty
				,UnitQtyType = __UnitQtyType
				,StatementNum = __StatementNum
				,IsLocked = __IsLocked
				,BillingNote = __BillingNote
				,RepeatChargeNum = __RepeatChargeNum
				,SnomedBodySite = __SnomedBodySite
				,DiagnosticCode2 = __DiagnosticCode2
				,DiagnosticCode3 = __DiagnosticCode3
				,DiagnosticCode4 = __DiagnosticCode4
				,ProvOrderOverride = __ProvOrderOverride
				,Discount = __Discount
				,IsDateProsthEst = __IsDateProsthEst
				,IcdVersion = __IcdVersion
				,IsCpoe = __IsCpoe
				,SecUserNumEntry = __SecUserNumEntry
				,SecDateEntry = __SecDateEntry
				,DateComplete = __DateComplete
				,OrderingReferralNum = __OrderingReferralNum
				,TaxAmt = __TaxAmt
				,Urgency = __Urgency
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE ProcNum = __ProcNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_procedurelog (
				ProcNum,
				PatNum,
				AptNum,
				OldCode,
				ProcDate,
				ProcFee,
				Surf,
				ToothNum,
				ToothRange,
				Priority,
				ProcStatus,
				ProvNum,
				Dx,
				PlannedAptNum,
				PlaceService,
				Prosthesis,
				DateOriginalProsth,
				ClaimNote,
				DateEntryC,
				ClinicNum,
				MedicalCode,
				DiagnosticCode,
				IsPrincDiag,
				ProcNumLab,
				BillingTypeOne,
				BillingTypeTwo,
				CodeNum,
				CodeMod1,
				CodeMod2,
				CodeMod3,
				CodeMod4,
				RevCode,
				UnitQty,
				BaseUnits,
				StartTime,
				StopTime,
				DateTP,
				SiteNum,
				HideGraphics,
				CanadianTypeCodes,
				ProcTime,
				ProcTimeEnd,
				DateTStamp,
				Prognosis,
				DrugUnit,
				DrugQty,
				UnitQtyType,
				StatementNum,
				IsLocked,
				BillingNote,
				RepeatChargeNum,
				SnomedBodySite,
				DiagnosticCode2,
				DiagnosticCode3,
				DiagnosticCode4,
				ProvOrderOverride,
				Discount,
				IsDateProsthEst,
				IcdVersion,
				IsCpoe,
				SecUserNumEntry,
				SecDateEntry,
				DateComplete,
				OrderingReferralNum,
				TaxAmt,
				Urgency,
				clinic_id,
				update_mode,
				updatedon


            ) values(
				__ProcNum,
				__PatNum,
				__AptNum,
				__OldCode,
				__ProcDate,
				__ProcFee,
				__Surf,
				__ToothNum,
				__ToothRange,
				__Priority,
				__ProcStatus,
				__ProvNum,
				__Dx,
				__PlannedAptNum,
				__PlaceService,
				__Prosthesis,
				__DateOriginalProsth,
				__ClaimNote,
				__DateEntryC,
				__ClinicNum,
				__MedicalCode,
				__DiagnosticCode,
				__IsPrincDiag,
				__ProcNumLab,
				__BillingTypeOne,
				__BillingTypeTwo,
				__CodeNum,
				__CodeMod1,
				__CodeMod2,
				__CodeMod3,
				__CodeMod4,
				__RevCode,
				__UnitQty,
				__BaseUnits,
				__StartTime,
				__StopTime,
				__DateTP,
				__SiteNum,
				__HideGraphics,
				__CanadianTypeCodes,
				__ProcTime,
				__ProcTimeEnd,
				__DateTStamp,
				__Prognosis,
				__DrugUnit,
				__DrugQty,
				__UnitQtyType,
				__StatementNum,
				__IsLocked,
				__BillingNote,
				__RepeatChargeNum,
				__SnomedBodySite,
				__DiagnosticCode2,
				__DiagnosticCode3,
				__DiagnosticCode4,
				__ProvOrderOverride,
				__Discount,
				__IsDateProsthEst,
				__IcdVersion,
				__IsCpoe,
				__SecUserNumEntry,
				__SecDateEntry,
				__DateComplete,
				__OrderingReferralNum,
				__TaxAmt,
				__Urgency,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_product`(
	IN __product_id INT(11)
    ,IN  __guid varchar(100)
    ,IN __product_name varchar(1500)
    ,IN __category_id INT(11)
    ,IN __description varchar(1000)
	,IN __updatedon varchar(30)
	,IN __updatedby int(11)
	,IN __comments varchar(4000)    
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    DECLARE __temp_product_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	
    IF length(__product_name) > 0 && __product_id = 0 THEN
		select id into __temp_product_id from product where lcase(name) = lcase(__product_name) and organisation_id = __organisation_id and active = 1;
    END IF;
    
    IF __product_id > 0 THEN
		UPDATE product set
			name = __product_name
            ,category_id = __category_id
            ,description = __description
            ,updatedby = __updatedby
            ,updatedby = __updatedby
            ,comments = __comments
        WHERE id = __product_id
			and organisation_id = __organisation_id;
		set __result_id = __product_id;
	ELSEIF __temp_product_id > 0 THEN
		UPDATE product set
			name = __product_name
            ,category_id = __category_id
            ,description = __description
            ,updatedby = __updatedby
            ,updatedby = __updatedby
            ,comments = __comments
        WHERE id = __temp_product_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_product_id;
    ELSEIF __product_id = 0 THEN
		INSERT into product
        (
			organisation_id
			,name
			,category_id
			,description
			,createdon
			,createdby
			,comments
        )
		values
        (
			__organisation_id
			,__product_name
			,__category_id
			,__description
			,__updatedon
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
    END IF;
    IF __product_id > 0 THEN
		select __result_id as responseid, 'Product have been updated successfully' as response;
	ELSE
		select __result_id as responseid, 'Product have been created successfully' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_provider` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_provider`(
			IN __ProvNum bigint(20),
			IN __Abbr varchar(255),
			IN __ItemOrder smallint(5) unsigned,
			IN __LName varchar(100),
			IN __FName varchar(100),
			IN __MI varchar(100),
			IN __Suffix varchar(100),
			IN __FeeSched bigint(20),
			IN __Specialty bigint(20),
			IN __SSN varchar(12),
			IN __StateLicense varchar(15),
			IN __DEANum varchar(15),
			IN __IsSecondary tinyint(3) unsigned,
			IN __ProvColor int(11),
			IN __IsHidden tinyint(3) unsigned,
			IN __UsingTIN tinyint(3) unsigned,
			IN __BlueCrossID varchar(25),
			IN __SigOnFile tinyint(3) unsigned,
			IN __MedicaidID varchar(20),
			IN __OutlineColor int(11),
			IN __SchoolClassNum bigint(20),
			IN __NationalProvID varchar(255),
			IN __CanadianOfficeNum varchar(100),
			IN __DateTStamp varchar(30),
			IN __AnesthProvType bigint(20),
			IN __TaxonomyCodeOverride varchar(255),
			IN __IsCDAnet tinyint(4),
			IN __EcwID varchar(255),
			IN __StateRxID varchar(255),
			IN __IsNotPerson tinyint(4),
			IN __StateWhereLicensed varchar(50),
			IN __EmailAddressNum bigint(20),
			IN __IsInstructor tinyint(4),
			IN __EhrMuStage int(11),
			IN __ProvNumBillingOverride bigint(20),
			IN __CustomID varchar(255),
			IN __ProvStatus tinyint(4),
			IN __IsHiddenReport tinyint(4),
			IN __IsErxEnabled tinyint(4),
			IN __Birthdate varchar(30),
			IN __SchedNote varchar(255),
			IN __WebSchedDescript text,
			IN __WebSchedImageLocation varchar(255),
			IN __HourlyProdGoalAmt double,
			IN __DateTerm varchar(30),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select ProvNum into __temAptNum from jd_provider where ProvNum = __ProvNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_provider set
				Abbr = __Abbr
				,ItemOrder = __ItemOrder
				,LName = __LName
				,FName = __FName
				,MI = __MI
				,Suffix = __Suffix
				,FeeSched = __FeeSched
				,Specialty = __Specialty
				,SSN = __SSN
				,StateLicense = __StateLicense
				,DEANum = __DEANum
				,IsSecondary = __IsSecondary
				,ProvColor = __ProvColor
				,IsHidden = __IsHidden
				,UsingTIN = __UsingTIN
				,BlueCrossID = __BlueCrossID
				,SigOnFile = __SigOnFile
				,MedicaidID = __MedicaidID
				,OutlineColor = __OutlineColor
				,SchoolClassNum = __SchoolClassNum
				,NationalProvID = __NationalProvID
				,CanadianOfficeNum = __CanadianOfficeNum
				,DateTStamp = __DateTStamp
				,AnesthProvType = __AnesthProvType
				,TaxonomyCodeOverride = __TaxonomyCodeOverride
				,IsCDAnet = __IsCDAnet
				,EcwID = __EcwID
				,StateRxID = __StateRxID
				,IsNotPerson = __IsNotPerson
				,StateWhereLicensed = __StateWhereLicensed
				,EmailAddressNum = __EmailAddressNum
				,IsInstructor = __IsInstructor
				,EhrMuStage = __EhrMuStage
				,ProvNumBillingOverride = __ProvNumBillingOverride
				,CustomID = __CustomID
				,ProvStatus = __ProvStatus
				,IsHiddenReport = __IsHiddenReport
				,IsErxEnabled = __IsErxEnabled
				,Birthdate = __Birthdate
				,SchedNote = __SchedNote
				,WebSchedDescript = __WebSchedDescript
				,WebSchedImageLocation = __WebSchedImageLocation
				,HourlyProdGoalAmt = __HourlyProdGoalAmt
				,DateTerm = __DateTerm
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE ProvNum = __ProvNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_provider (
				ProvNum,
				Abbr,
				ItemOrder,
				LName,
				FName,
				MI,
				Suffix,
				FeeSched,
				Specialty,
				SSN,
				StateLicense,
				DEANum,
				IsSecondary,
				ProvColor,
				IsHidden,
				UsingTIN,
				BlueCrossID,
				SigOnFile,
				MedicaidID,
				OutlineColor,
				SchoolClassNum,
				NationalProvID,
				CanadianOfficeNum,
				DateTStamp,
				AnesthProvType,
				TaxonomyCodeOverride,
				IsCDAnet,
				EcwID,
				StateRxID,
				IsNotPerson,
				StateWhereLicensed,
				EmailAddressNum,
				IsInstructor,
				EhrMuStage,
				ProvNumBillingOverride,
				CustomID,
				ProvStatus,
				IsHiddenReport,
				IsErxEnabled,
				Birthdate,
				SchedNote,
				WebSchedDescript,
				WebSchedImageLocation,
				HourlyProdGoalAmt,
				DateTerm,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__ProvNum,
				__Abbr,
				__ItemOrder,
				__LName,
				__FName,
				__MI,
				__Suffix,
				__FeeSched,
				__Specialty,
				__SSN,
				__StateLicense,
				__DEANum,
				__IsSecondary,
				__ProvColor,
				__IsHidden,
				__UsingTIN,
				__BlueCrossID,
				__SigOnFile,
				__MedicaidID,
				__OutlineColor,
				__SchoolClassNum,
				__NationalProvID,
				__CanadianOfficeNum,
				__DateTStamp,
				__AnesthProvType,
				__TaxonomyCodeOverride,
				__IsCDAnet,
				__EcwID,
				__StateRxID,
				__IsNotPerson,
				__StateWhereLicensed,
				__EmailAddressNum,
				__IsInstructor,
				__EhrMuStage,
				__ProvNumBillingOverride,
				__CustomID,
				__ProvStatus,
				__IsHiddenReport,
				__IsErxEnabled,
				__Birthdate,
				__SchedNote,
				__WebSchedDescript,
				__WebSchedImageLocation,
				__HourlyProdGoalAmt,
				__DateTerm,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_purchaseorder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_purchaseorder`(
		IN __id int(11),
        IN __guid varchar(1000),
		IN __customer_id int(11),
		IN __order_no varchar(20),
		IN __order_date varchar(30),
		IN __vendor_code varchar(20),
		IN __amount_before_tax double(11,2),
        IN __inv_discount double(11,2),
		IN __cgst double(11,2),
		IN __sgst double(11,2),
		IN __amount_after_tax double(11,2),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
        IN __status varchar(20),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;    
    
    IF __order_no > 0 THEN
		select id into __temp_id from purchaseorder where lcase(order_no) = lcase(__order_no) and customer_id = __customer_id and organisation_id = __organisation_id;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE purchaseorder_detail set active = 0 where po_id = __id;
		UPDATE purchaseorder set
			customer_id = __customer_id
			,order_no = __order_no
			,order_date = STR_TO_DATE(__order_date, '%Y-%m-%d')
			,vendor_code = __vendor_code
			,amount_before_tax = __amount_before_tax
			,cgst = __cgst
			,sgst = __sgst
			,amount_after_tax = __amount_after_tax
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            -- ,status = __status
			,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE purchaseorder_detail set active = 0 where po_id = __temp_id;
		UPDATE purchaseorder set 
			customer_id = __customer_id
			,order_no = __order_no
			,order_date = STR_TO_DATE(__order_date, '%Y-%m-%d')
			,vendor_code = __vendor_code
			,amount_before_tax = __amount_before_tax
			,cgst = __cgst
			,sgst = __sgst
			,amount_after_tax = __amount_after_tax
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            -- ,status = __status
			,comments = __comments
        WHERE id = __temp_id
			and organisation_id = __organisation_id;
		set __result_id = __temp_id;
    
	ELSEIF __id = 0 THEN
		INSERT INTO purchaseorder (
			organisation_id
			,customer_id
			,order_no
			,order_date
			,vendor_code
			,amount_before_tax
            ,inv_discount
			,cgst
			,sgst
			,amount_after_tax
			,createdon
			,createdby
            ,status
			,comments
        ) values (
			__organisation_id
			,__customer_id
			,__order_no
			,STR_TO_DATE(__order_date, '%Y-%m-%d')
			,__vendor_code
			,__amount_before_tax
            ,__inv_discount
			,__cgst
			,__sgst
			,__amount_after_tax
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
            ,__status
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_purchaseorder_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_purchaseorder_detail`(
		IN __id int(11),
        IN __guid varchar(1000),
		IN __po_id int(11),
        IN __product_id bigint(11),
		IN __product_name varchar(1000),
		IN __hsn_sac varchar(100),
        IN __process varchar(100),
		IN __quantity bigint(11),
        IN __unit varchar(100),
        IN __weight_kg double(11,2),
		IN __rate double(11,2),
		IN __amount  double(11,2),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    DECLARE __tempProductId INT(11);
    DECLARE __organisation_id INT DEFAULT 0;
    SET __tempProductId = __product_id;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;  
    
    IF length(__product_name) > 0 &&  __product_id = 0 THEN
		-- select id into __temp_id from purchaseorder_detail where lcase(product_name) = lcase(__product_name) and po_id = __po_id;
        select id into __tempProductId from product where lcase(name) = lcase(__product_name) and organisation_id = __organisation_id order by id desc limit 1;
    END IF;    
	select __tempProductId  as tempProductId;
    
    IF __tempProductId = 0 THEN
		INSERT INTO product (
			organisation_id
			,name
            ,description
			,category_id
			,createdby
        ) values (
			__organisation_id
            ,__product_name
            ,__product_name
            ,1
            ,__updatedby
        );
        set __tempProductId = LAST_INSERT_ID();
    END IF;
        select __product_name as productname;

	IF __id > 0 THEN
		UPDATE purchaseorder_detail set
			product_id = __tempProductId
			-- ,product_name = __product_name
			,hsn_sac = __hsn_sac
            ,process = __process
			,quantity = __quantity
            ,unit = __unit
            ,weight_kg = __weight_kg
			,rate = __rate
			,amount = __amount
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __id
			and po_id = __po_id;
		set __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE purchaseorder_detail set
			product_id = __tempProductId
			-- ,product_name = __product_name
			,hsn_sac = __hsn_sac
            ,process = __process
			,quantity = __quantity
            ,unit = __unit
            ,weight_kg = __weight_kg
			,rate = __rate
			,amount = __amount
			,updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
			,comments = __comments
            ,active = 1
        WHERE id = __temp_id
			and po_id = __po_id;
		set __result_id = __temp_id;
	ELSEIF __id = 0 THEN
		INSERT INTO purchaseorder_detail (
			po_id
            ,product_id
			,product_name
			,hsn_sac
            ,process
			,quantity
            ,unit
            ,weight_kg
			,rate
			,amount
			,createdon
			,createdby
			,comments
        ) values (
			__po_id
            ,__tempProductId
			,''
			,__hsn_sac
            ,__process
			,__quantity
            ,__unit
            ,__weight_kg
			,__rate
			,__amount
			,STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
	END IF;
    select __result_id as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_purchaseorder_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_purchaseorder_status`(
		IN __id int(11),
        IN __guid varchar(1000),
		IN __updatedon varchar(30),
		IN __updatedby int(11),
        IN __status varchar(20),
		IN __comments varchar(4000)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;    
    
	IF __id > 0 THEN
		UPDATE purchaseorder_detail set active = 0 where po_id = __id;
		UPDATE purchaseorder set
			updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __updatedby
            ,status = __status
			,comments = __comments
        WHERE id = __id
			and organisation_id = __organisation_id;
		set __result_id = __id;
	END IF;
    
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_quotation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_quotation`(
	IN __quotation_id INT(11)
    ,IN  __guid varchar(100)
    ,IN __quote_number INT(11)
    ,IN __quote_date varchar(30)
    ,IN __quote_valid_until varchar(30)
    ,IN __quotation_description TEXT
    ,IN __customer_id INT(11)
    ,IN __quotation_discount decimal(11,2)
    ,IN __quotation_cgst decimal(11,2)
    ,IN __quotation_sgst decimal(11,2)
    ,IN __status_id INT(11)
	,IN __updatedon varchar(30)
	,IN __updatedby int(11)
	,IN __comments varchar(4000)    
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    DECLARE __tempcustomer_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	
	UPDATE quotation_detail set active = 0 where quotation_id = __quotation_id;
    
    IF __quotation_id > 0 THEN
		UPDATE quotation set
			quote_date = __quote_date
            ,quote_due = __quote_valid_until
            ,quote_description = __quotation_description
            ,customer_id = __customer_id
            ,quote_discount = __quotation_discount
            ,quote_cgst = __quotation_cgst
            ,quote_sgst = __quotation_sgst
            -- ,status_id = __status_id
            ,updatedon = __updatedon
            ,updatedby = __updatedby
            ,comments = __comments
        WHERE id = __quotation_id
			and organisation_id = __organisation_id;
		set __result_id = __quotation_id;
    ELSEIF __quotation_id = 0 THEN
		INSERT into quotation
        (
			organisation_id
            ,quote_number
			,customer_id
            ,quote_date
            ,quote_due
			,quote_description
            ,quote_discount
            ,quote_cgst
            ,quote_sgst
            ,status_id
			,createdon
			,createdby
			,comments
        )
		values
        (
			__organisation_id
            ,__quote_number
			,__customer_id
            ,__quote_date
            ,__quote_valid_until
			,__quotation_description
            ,__quotation_discount
            ,__quotation_cgst
            ,__quotation_sgst            
            ,__status_id
			,__updatedon
			,__updatedby
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
    END IF;
    
    IF __quotation_id > 0 THEN
		select __result_id as responseid, 'Quotation has been updated successfully' as response;
	ELSE
		select __result_id as responseid, 'Quotation has been created successfully' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_quotation_detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_quotation_detail`(
	IN __quotation_detail_id INT(11)
    ,IN  __guid varchar(100)
	,IN __quotation_id INT(11)
    ,IN __quotation_item varchar(2000)
    ,IN __quotation_drwaing_number varchar(2000)
    ,IN __quotation_quantity decimal(11, 2)
    ,IN __quotation_attahment_filename varchar(2000)
    ,IN __quotation_attahment_url varchar(2000)
	,IN __createdon varchar(30)
	,IN __createdby int(11)
	,IN __comments varchar(4000)    
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
        DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
    IF __quotation_id > 0 THEN
		INSERT into quotation_detail
        (
			quotation_id
			,quotation_item
			,quotation_drwaing_number
			,quotation_quantity
			,quotation_attahment_filename
			,quotation_attahment_url
			,createdby
			,createdon
			,comments
        )
		values
        (
			__quotation_id
			,__quotation_item
			,__quotation_drwaing_number
			,__quotation_quantity
			,__quotation_attahment_filename
			,__quotation_attahment_url
			,__createdby
			,__createdon
			,__comments
        );
        set __result_id = LAST_INSERT_ID();
    END IF;

	select __result_id as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_quotation_detail_response` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_quotation_detail_response`(
	IN __quotation_detail_id INT(11)
	,IN __quotation_id INT(11)
    ,IN __quotation_quantity decimal(11, 2)
    ,IN __quotation_unit varchar(100)
    ,IN __quotation_rate decimal(11, 2)
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    
    IF __quotation_id > 0 THEN
		UPDATE quotation_detail set 
			quotation_quantity = __quotation_quantity
            ,quotation_unit = __quotation_unit
            ,quotation_rate = __quotation_rate
        WHERE id = __quotation_detail_id 
        and quotation_id = __quotation_id;
        set __result_id = LAST_INSERT_ID();
    END IF;
	select __result_id as responseid, 'success' as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_quotation_response` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_quotation_response`(
	IN __quotation_id INT(11)
    ,IN  __guid varchar(100)
    ,IN __quote_number INT(11)
    ,IN __quote_valid_until varchar(30)
    ,IN __quotation_description TEXT
    ,IN __quotation_discount decimal(11,2)
    ,IN __quotation_cgst decimal(11,2)
    ,IN __quotation_sgst decimal(11,2)
    ,IN __status_id INT(11)
	,IN __updatedon varchar(30)
	,IN __updatedby int(11)
	,IN __comments varchar(4000)    
)
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    DECLARE __tempcustomer_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
	
    IF __quotation_id > 0 THEN
		UPDATE quotation set
            quote_valid_until = __quote_valid_until
            ,quote_description = __quotation_description
            ,quote_discount = __quotation_discount
            ,quote_cgst = __quotation_cgst
            ,quote_sgst = __quotation_sgst
            ,status_id = __status_id
            ,updatedon = __updatedon
            ,updatedby = __updatedby
            ,comments = __comments
        WHERE id = __quotation_id
			and organisation_id = __organisation_id;
		set __result_id = __quotation_id;
    
    END IF;
    
    IF __quotation_id > 0 THEN
		select __result_id as responseid, 'Quotation has been updated successfully' as response;
	ELSE
		select __result_id as responseid, 'Quotation has been created successfully' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_reset_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_reset_password`(
    IN __accountId INT,
    IN __emailId varchar(255),
    IN __hashpassword varchar(2500),
    IN __guid varchar(255),
    IN __updatedon varchar(30)
)
BEGIN
	DECLARE __userId INT;
    
    IF length(__emailId) > 0 THEN
		select id into __userId from user where username = __emailId;
    END IF;
    
    IF isnull(__userId) THEN
		select '0' as id, Concat('Email ''', __emailId, ''' does not exist. \n please try again with valid email.')  as response ;
    ELSE 
		IF __userId > 0 THEN
			update  user set password = __hashpassword, updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i') where id = __userId;
			update histforgotpassword set userId = __userId, isActive = 0, updatedon = STR_TO_DATE(__updatedon, '%Y-%m-%d %H:%i') where guid = __guid;
            select __userId as id, 'reset is success' as response;
        ELSE
            select '-1' as id, Concat('Email id ''', __emailId, ''' does not exist. please try with valid email id')  as response ;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_template_draft` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_template_draft`(
	IN __guid varchar(100),
	IN __id INT
    ,IN __category_id varchar(10)
	,IN __type varchar(10)
	,IN __subject varchar(250)
	,IN __bodycontent mediumtext
	,IN __bodycontentText mediumtext
	,IN __updatedon varchar(30)
	,IN __updatedby INT
	,IN __comments varchar(5000)
)
BEGIN
	DECLARE __temp_template_draft_id INT DEFAULT 0;
    DECLARE __result varchar(100);
	DECLARE __clinic_id INT DEFAULT 0;
	SET __clinic_id = func_get_clinic_id(__guid);
    
	IF (__id = 0 ) THEN
		insert into template_draft (
			type
			,category_id
			,subject
			,bodycontent
			,bodycontent_text
			,createdby
			,createdon
			,comments
			,clinic_id
        )
        values (
			__type
            ,__category_id
            ,__subject
            ,__bodycontent
            ,__bodycontentText
            ,__updatedby
			,__updatedon
            ,__comments
            ,__clinic_id
        );
		SET __temp_template_draft_id = LAST_INSERT_ID();
        SET __result = 'Template draft has been created';
	ELSE
		update template_draft set
		type = __type
        ,category_id = __category_id
		,subject = __subject
		,bodycontent = __bodycontent
        ,bodycontent_text = __bodycontentText
		,updatedon = __updatedon
		,updatedby = __updatedby
		,comments = __comments
        where id = __id and clinic_id = __clinic_id;
        SET __temp_template_draft_id = __id;
        SET __result = 'Template draft has been updated';
	END IF;
    select __temp_template_draft_id as template_id, __result as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_template_signature` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_template_signature`(
	IN __guid varchar(100)
	,IN __id INT
    ,IN __name varchar(1000)
	,IN __content mediumtext
	,IN __content_text mediumtext
	,IN __updatedon varchar(30)
	,IN __updatedby INT
	,IN __comments varchar(5000)
    ,IN __type varchar(5000)
    ,IN __profileUrl varchar(10000)
    ,IN __active bit
)
BEGIN
	DECLARE __temp_template_signature_id INT DEFAULT 0;
    DECLARE __result varchar(100);

	DECLARE _next TEXT DEFAULT NULL;
	DECLARE _nextlen INT DEFAULT NULL;
	DECLARE _value TEXT DEFAULT NULL;

	DECLARE _next_url TEXT DEFAULT NULL;
	DECLARE _nextlen_url INT DEFAULT NULL;
	DECLARE _value_url TEXT DEFAULT NULL;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    IF __active = 1 THEN
		update template_signature set active = 0;
    END IF;
    
	IF (__id = 0 ) THEN
		insert into template_signature (
		name
        ,content
		,content_text
		,createdby
		,createdon
		,comments
        ,active
        ,clinic_id)
        values (
			__name
            ,__content
			,__content_text
            ,__updatedby
			,__updatedon
            ,__comments
            ,__active
            ,__clinic_id
        );
		SET __temp_template_signature_id = LAST_INSERT_ID();
        SET __result = 'Template signature has been created';
	ELSE
		update template_signature set
		name = __name
        ,content = __content
		,content_text = __content_text
		,updatedon = __updatedon
		,updatedby = __updatedby
		,comments = __comments
        ,active = __active
        where id = __id and clinic_id = __clinic_id;
        SET __temp_template_signature_id = __id;
        SET __result = 'Template draft has been updated';
	END IF;
   
   -- update / insert profile links for signature
   delete from template_signature_media_links where signature_id = __temp_template_signature_id;
   iterator:
   LOOP
		-- exit the loop if the list seems empty or was null;
		-- this extra caution is necessary to avoid an endless loop in the proc.
	  IF LENGTH(TRIM(__type)) = 0 OR __type IS NULL THEN
		LEAVE iterator;
	  END IF;
	  
	  -- capture the next value from the list
	  SET _next = SUBSTRING_INDEX(__type,',',1);
      SET _next_url = SUBSTRING_INDEX(__profileUrl,',',1);
	  
	  -- save the length of the captured value; we will need to remove this
	  -- many characters + 1 from the beginning of the string 
	  -- before the next iteration
	  SET _nextlen = LENGTH(_next);
      SET _nextlen_url = LENGTH(_next_url);

	  -- trim the value of leading and trailing spaces, in case of sloppy CSV strings
	  SET _value = TRIM(_next);
      SET _value_url = TRIM(_next_url);

	  -- insert the extracted value into the target table
	  INSERT INTO template_signature_media_links (signature_id, type, address, createdby, createdon) VALUES (__temp_template_signature_id, _value, _value_url, __updatedby, __updatedon);
		  
	  -- rewrite the original string using the `INSERT()` string function,
	  -- args are original string, start position, how many characters to remove, 
	  -- and what to "insert" in their place (in this case, we "insert"
	  -- an empty string, which removes _nextlen + 1 characters)
	  SET __type = INSERT(__type,1,_nextlen + 1,'');
      SET __profileUrl = INSERT(__profileUrl,1,_nextlen_url + 1,'');
	  
   END LOOP;
   select __temp_template_signature_id as signature_id, __result as response;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_transfer_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_transfer_history`(
	IN __guid varchar(100),
    IN __start_datetime varchar(30),
    IN __end_datetime varchar(30),
    IN __duration varchar(200),
    IN __currentTime varchar(30),
    IN __updatedby bigint(20)
)
BEGIN
	
    DECLARE __temPatNum bigint(20);
    DECLARE __clinic_id INT(11);
    
    select id into __clinic_id from clinic where unique_id = __guid;
    
    IF length(__guid) > 0 and __clinic_id > 0 THEN
		insert into data_transfer_history 
        (
			clinic_id,
            start_date_time,
            end_date_time,
            duration,
            updatedon,
            updatedby
        )
        values 
        (
			__clinic_id,
            __start_datetime,
            __end_datetime,
            __duration,
            __currentTime,
            __updatedby
        );
        select '1' as responseid, 'success' as response;
	Else
		select '0' as responseid, 'failed' as response;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_transfer_hostory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_transfer_hostory`(
	IN __guid varchar(100),
    IN __start_datetime varchar(30),
    IN __end_datetime varchar(30),
    IN __duration varchar(200),
    IN __currentTime varchar(30),
    IN __updatedby bigint(20)
)
BEGIN
	
    DECLARE __temPatNum bigint(20);
    DECLARE __clinic_id INT(11);
    
    select id into __clinic_id from clinic where guid = __guid;
    
    IF length(__guid) > 0 THEN
		insert into data_transfer_history 
        (
			clinic_id,
            start_date_time,
            end_date_time,
            duration,
            updatedon,
            updatedby
        )
        values 
        (
			__clinic_id,
            __start_datetime,
            __end_datetime,
            __duration,
            __currentTime,
            __updatedby
        );
    END IF;
    select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_treatment_priority` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_treatment_priority`(
	IN __guid varchar(100),
	IN __proc_numbers varchar(2000),
    IN __priority INT,
	IN __opendentalDB CHAR(100)
)
BEGIN
	DECLARE front TEXT DEFAULT NULL;
    DECLARE frontlen INT DEFAULT NULL;
    DECLARE TempValue TEXT DEFAULT NULL;
	DECLARE sQLStmt TEXT;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);
    
    IF __priority > 0 THEN
		set @sQLStmt = CONCAT("update ", __opendentalDB, ".jd_treatplanattach set 
		Priority=(select def.DefNum from ", __opendentalDB, ".jd_definition def 
		where def.ItemName = '", __priority ,"' and def.clinic_id = ", __clinic_id, ") 
		where ProcNum in (", __proc_numbers, ") and clinic_id = ", __clinic_id);
		
		PREPARE Stmt FROM @sQLStmt;
		EXECUTE Stmt;
		DEALLOCATE PREPARE Stmt; 
    END IF;
    select 'success' as result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_treatplan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_treatplan`(
				IN __TreatPlanNum bigint(20),
				IN __PatNum bigint(20),
				IN __DateTP varchar(30),
				IN __Heading varchar(255),
				IN __Note text,
				IN __Signature text,
				IN __SigIsTopaz tinyint(1),
				IN __ResponsParty bigint(20),
				IN __DocNum bigint(20),
				IN __TPStatus tinyint(4),
                
				IN __SecUserNumEntry bigint(20),
				IN __SecDateEntry varchar(30),
				IN __SecDateTEdit varchar(30),
				IN __UserNumPresenter bigint(20),
				IN __TPType tinyint(4),
				IN __SignaturePractice text,
				IN __DateTSigned datetime,
				IN __DateTPracticeSigned varchar(30),
				IN __SignatureText varchar(255),
				IN __SignaturePracticeText varchar(255),
                
				IN __clinic_id INT(10),
				IN __update_mode char(1),
				IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select TreatPlanNum into __temAptNum from jd_treatplan where TreatPlanNum = __TreatPlanNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_treatplan set
			PatNum = __PatNum
			,DateTP = __DateTP
			,Heading = __Heading
			,Note = __Note
			,Signature = __Signature
			,SigIsTopaz = __SigIsTopaz
			,ResponsParty = __ResponsParty
			,DocNum = __DocNum
			,TPStatus = __TPStatus
			,SecUserNumEntry = __SecUserNumEntry
			,SecDateEntry = __SecDateEntry
			,SecDateTEdit = __SecDateTEdit
			,UserNumPresenter = __UserNumPresenter
			,TPType = __TPType
			,SignaturePractice = __SignaturePractice
			,DateTSigned = __DateTSigned
			,DateTPracticeSigned = __DateTPracticeSigned
			,SignatureText = __SignatureText
			,SignaturePracticeText = __SignaturePracticeText
			,clinic_id = __clinic_id
			,update_mode = __update_mode
			,updatedon = __updatedon

			WHERE TreatPlanNum = __TreatPlanNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_treatplan (
				TreatPlanNum,
				PatNum,
				DateTP,
				Heading,
				Note,
				Signature,
				SigIsTopaz,
				ResponsParty,
				DocNum,
				TPStatus,
				SecUserNumEntry,
				SecDateEntry,
				SecDateTEdit,
				UserNumPresenter,
				TPType,
				SignaturePractice,
				DateTSigned,
				DateTPracticeSigned,
				SignatureText,
				SignaturePracticeText,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__TreatPlanNum,
				__PatNum,
				__DateTP,
				__Heading,
				__Note,
				__Signature,
				__SigIsTopaz,
				__ResponsParty,
				__DocNum,
				__TPStatus,
				__SecUserNumEntry,
				__SecDateEntry,
				__SecDateTEdit,
				__UserNumPresenter,
				__TPType,
				__SignaturePractice,
				__DateTSigned,
				__DateTPracticeSigned,
				__SignatureText,
				__SignaturePracticeText,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_treatplanattach` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_treatplanattach`(
			IN __TreatPlanAttachNum bigint(20),
			IN __TreatPlanNum bigint(20),
			IN __ProcNum bigint(20),
			IN __Priority bigint(20),
			IN __clinic_id INT(10),
			IN __update_mode char(1),
			IN __updatedon varchar(30)
)
BEGIN
	    DECLARE __temAptNum bigint(20);
        
		Select TreatPlanAttachNum into __temAptNum from jd_treatplanattach where TreatPlanAttachNum = __TreatPlanAttachNum and clinic_id = __clinic_id limit 1;

		IF __temAptNum > 0 THEN
			UPDATE jd_treatplanattach set
				TreatPlanNum = __TreatPlanNum
				,ProcNum = __ProcNum
				,Priority = __Priority
				,clinic_id = __clinic_id
				,update_mode = __update_mode
				,updatedon = __updatedon

			WHERE TreatPlanAttachNum = __TreatPlanAttachNum
				and clinic_id = __clinic_id;
        ELSE
			insert into jd_treatplanattach (
				TreatPlanAttachNum,
				TreatPlanNum,
				ProcNum,
				Priority,
				clinic_id,
				update_mode,
				updatedon

            ) values(
				__TreatPlanAttachNum,
				__TreatPlanNum,
				__ProcNum,
				__Priority,
				__clinic_id,
				__update_mode,
				__updatedon
            );
        END IF;
		select '1' as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_useraccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_useraccount`(
			IN __id	int(11), -- user id
			IN __firstName	varchar(250),
            IN __lastName	varchar(250),
			IN __username	varchar(250),
			IN __password	varchar(1000),
			IN __phone	varchar(20),
			IN __roleid	int(11),
            IN __orgId	int(11),
			IN __organisation_name	varchar(1000),
            IN __profile_picture_path varchar(1000),
			IN __createdon	varchar(30),
			IN __createdby	int(11)
    )
BEGIN
	DECLARE __result_id INT DEFAULT 0;
    DECLARE __org_id INT DEFAULT 0;
    DECLARE __temp_id INT DEFAULT 0;
    DECLARE __temp_id_org INT DEFAULT 0;
    
    IF length(__username) > 0 THEN
		select id into __temp_id from user where lcase(username) = lcase(__username);
    END IF;
    
    IF length(__organisation_name) > 0 THEN
		select id into __temp_id_org from organisation where lcase(name) = lcase(__organisation_name);
    END IF;
    
    IF __temp_id_org > 0 THEN
		UPDATE organisation SET 
			name = __organisation_name
			,groupof = __organisation_name 
			,primary_contact = concat(__firstName, ' ', __lastName)
			,primary_phone = __phone
			,primary_email = __username
			,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __createdby
			WHERE id = __temp_id_org;
			set __org_id = __temp_id_org;
    ELSEIF __id > 0 THEN
		UPDATE organisation SET 
			name = __organisation_name
			,groupof = __organisation_name 
			,primary_contact = concat(__firstName, ' ', __lastName)
			,primary_phone = __phone
			,primary_email = __username
			,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
			,updatedby = __createdby
			WHERE id = __org_id;

			set __org_id = __temp_id_org;    
	ELSEIF __id = 0 THEN
		IF length(__organisation_name) > 0 THEN
			INSERT INTO organisation
			(
				name
				,groupof
				,primary_contact
				,primary_phone
				,primary_email
				,createdon
				,createdby
			)
			values
			(
				__organisation_name
                ,__organisation_name
                , concat(__firstName, ' ', __lastName)
				,__phone
				,__username
				,STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
				,__createdby
			);   
            set __org_id = LAST_INSERT_ID();
        ELSE
			set __org_id = __orgId;
        END IF;
        
        -- set __result_id = LAST_INSERT_ID();
    END IF;
    
    IF __id > 0 THEN
		UPDATE user SET 
        firstname = __firstname
        ,lastname = __lastname
        ,phone = __phone
        ,roleid = __roleid
        ,profile_picture_url = __profile_picture_path
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby        
        WHERE id = __id;
        SET __result_id = __id;
	ELSEIF __temp_id > 0 THEN
		UPDATE user SET 
        firstname = __firstname
        ,lastname = __lastname
        ,phone = __phone
        ,roleid = __roleid
        ,profile_picture_url = __profile_picture_path
        ,updatedon = STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        ,updatedby = __createdby
        WHERE id = __temp_id;
        SET __result_id = __temp_id;   
	ELSE
		INSERT INTO user
        (
			username,
            password, 
            firstname, 
            lastname, 
            roleid, 
            phone, 
            organisation_id, 
            profile_picture_url,
            createdon
        )
        values
        (
			__username,
            __password, 
            __firstName, 
            __lastName, 
            __roleid, 
            __phone, 
            __org_id, 
            __profile_picture_path,
            STR_TO_DATE(__createdon, '%Y-%m-%d %H:%i:%s')
        );
    END IF;
    
    select __result_id as responseid, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_usertask` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_usertask`(
		IN __task_id INT,
		IN __guid varchar(100),
		IN __task_name VARCHAR(255),
		IN __task_description VARCHAR(2000),
		IN __task_type VARCHAR(20),
		IN __task_cycle VARCHAR(20),
		IN __task_start_date VARCHAR(30),
		IN __task_end_date VARCHAR(30),
		IN __range_start_date VARCHAR(30),
		IN __range_end_date VARCHAR(30),
        IN __taskto INT,
		IN __createdon VARCHAR(20),
		IN __createdby INT
    )
BEGIN
	DECLARE __usertask_id INT DEFAULT 0;
	DECLARE __clinic_id INT DEFAULT 0;

	SET __clinic_id = func_get_clinic_id(__guid);


    IF __task_id > 0 THEN
		Update usertask  set
        task_start 	= __task_start_date
        ,task_end 	= __task_end_date
        -- ,range_start = __range_start_date
		-- ,range_end = __range_end_date
        ,updatedon 	= __createdon
        ,updatedby	= __createdby
        WHERE id = __task_id and clinic_id = __clinic_id;
        set __usertask_id = __task_id ;
	ELSEIF __task_id = 0 THEN
		IF length(__task_name) > 0 THEN
			INSERT INTO usertask (
				clinic_id
				,task_name
				,task_description
				,task_type
				,task_cycle
				,task_start
				,task_end
				,range_start
				,range_end
				,taskto
				,createdon
				,createdby
			) values (
				__clinic_id
				,__task_name
				,__task_description
				,__task_type
				,__task_cycle
				,__task_start_date
				,__task_end_date
				,__range_start_date
				,__range_end_date
				,__taskto
				,__createdon
				,__createdby
			);
		END IF;
		SET __usertask_id = LAST_INSERT_ID();
    END IF;
	select __usertask_id as usertaskId, 'success' as response;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_update_user_code_verification` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_update_user_code_verification`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __secretcode varchar(10),
    IN __verifieddon varchar(30)
)
BEGIN
	-- attempt
    DECLARE __verification_code varchar(10);
    DECLARE __verification_id INT;
    DECLARE __result_id INT DEFAULT 0;
    SET @expiryTime = 1;
    
    select id into __verification_id from user_code_verification  where user_id = __user_id and clinic_id = __paged and verifystatus = 'N' order by id desc limit 1;
    
    IF __verification_id is null THEN
		set __result_id = 0;
        select __result_id as resultId, 'Verification code does not exist' as response;
	ELSE
		select secretcode into __verification_code from user_code_verification  where id = __verification_id and DATE_ADD(createdon, INTERVAL @expiryTime MINUTE) >= DATE(__verifieddon) order by id desc limit 1;
        IF __verification_code is null THEN
			select __result_id as resultId, 'Verification code has been expired' as response;
		ELSE
			IF __verification_code = __secretcode THEN
				update user_code_verification set verifystatus = 'Y', veryfiedon = __verifieddon where id = __verification_id;
				set __result_id = 1;
				select __result_id as resultId, 'success' as response;
			END IF;
		END IF;

	END IF;
    
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_validate_customer_exist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_validate_customer_exist`(
			IN __guid varchar(1000)
			,IN __gstin varchar(50)
    )
BEGIN
	DECLARE __custresult_id INT DEFAULT 0;
    DECLARE __organisation_id INT DEFAULT 0;
    
    if length(__guid) > 0 THEN
		select organisation_id into __organisation_id from user_login_status where guid = __guid and active = 1;
    END IF;
    
	select id as customer_id, name as customer_name from customer where lcase(gstin) = lcase(__gstin) and organisation_id = __organisation_id;    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_verify_forgot_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_verify_forgot_password`(
    IN __guid varchar(100)
    )
BEGIN
    select 
    hfp.id,
    hfp.clinic_id,
    usr.id as userId,
    hfp.guid as guid,
    hfp.emailId as email,
    DATE_FORMAT(hfp.createdon, '%Y-%m-%d %H:%i') as createdon,
    DATE_FORMAT(hfp.expirydatetime, '%Y-%m-%d %H:%i') as expirydatetime,
    CAST(hfp.isActive as UNSIGNED) as isactive
    from histforgotpassword hfp
    join user usr on usr.username = hfp.emailId
    where hfp.guid = __guid;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_verify_secret_code` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_verify_secret_code`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __secretcode varchar(10),
    IN __verifieddon varchar(30)
)
BEGIN
	-- attempt
    DECLARE __verification_code varchar(10);
    DECLARE __verification_id INT;
    DECLARE __result_id INT DEFAULT 0;
    SET @expiryTime = 10;
    
    select max(id) into __verification_id  from user_code_verification where verifystatus = 'N' and id = (select max(id) from user_code_verification where user_id = __user_id and clinic_id = __paged) ;
    
    IF __verification_id is null THEN
		set __result_id = 0;
        select __result_id as resultId, 'Invalid verification code. Please try again' as response;
	ELSE
		select secretcode into __verification_code from user_code_verification  where id = __verification_id and verifystatus = 'N' and secretcode = __secretcode limit 1;
        IF __verification_code is null THEN
			select __result_id as resultId, 'Invalid verification code. Please try again' as response;
        ELSE
			select secretcode into __verification_code from user_code_verification  where id = __verification_id and DATE_ADD(createdon, INTERVAL @expiryTime MINUTE) >= timestamp(__verifieddon) and verifystatus = 'N' order by id desc limit 1;
			IF __verification_code is null THEN
				select __result_id as resultId, 'Verification code has been expired' as response;
			ELSE
				set __result_id = 0;
				IF __verification_code = __secretcode THEN
					update user_code_verification set verifystatus = 'Y', verifiedon = __verifieddon where id = __verification_id;
					set __result_id = 1;
					select __result_id as resultId, 'success' as response;
				ELSE
					select __result_id as resultId, 'Invalid verification code. Please try again' as response;
				END IF;
			END IF;
		END IF;
	END IF;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_verify_user_code_to_reset_password` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_verify_user_code_to_reset_password`(
	IN __user_id INT,
    IN __paged INT, -- Clinic Id
	IN __secretcode varchar(10),
    IN __verifieddon varchar(30)
)
BEGIN
	-- attempt
    DECLARE __verification_code varchar(10);
    DECLARE __verification_id INT;
    DECLARE __result_id INT DEFAULT 0;
    SET @expiryTime = 10;
    
    select max(id) into __verification_id  from user_code_verification where verifystatus = 'N' and id = (select max(id) from user_code_verification where user_id = __user_id and clinic_id = __paged) ;
    
    IF __verification_id is null THEN
		set __result_id = 0;
        select __result_id as resultId, 'Invalid verification code. Please try again' as response;
	ELSE
		select secretcode into __verification_code from user_code_verification  where id = __verification_id and verifystatus = 'N' and secretcode = __secretcode limit 1;
        IF __verification_code is null THEN
			select __result_id as resultId, 'Invalid verification code. Please try again' as response;
        ELSE
			select secretcode into __verification_code from user_code_verification  where id = __verification_id and DATE_ADD(createdon, INTERVAL @expiryTime MINUTE) >= timestamp(__verifieddon) and verifystatus = 'N' order by id desc limit 1;
			IF __verification_code is null THEN
				select __result_id as resultId, 'Verification code has been expired' as response;
			ELSE
				set __result_id = 0;
				IF __verification_code = __secretcode THEN
					update user_code_verification set verifystatus = 'Y', verifiedon = __verifieddon where id = __verification_id;
					set __result_id = 1;
					select __result_id as resultId, 'success' as response;
				ELSE
					select __result_id as resultId, 'Invalid verification code. Please try again' as response;
				END IF;
			END IF;
		END IF;
	END IF;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_table_v1_to_justdentaldb` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_table_v1_to_justdentaldb`( )
BEGIN
	DECLARE colName varchar(200);

    -- histemailsent
	SELECT column_name INTO colName
	FROM information_schema.columns 
	WHERE table_schema = 'justdentaldb'
		AND table_name = 'histemailsent'
	AND column_name = 'appointment_datetime';
	IF colName is null THEN 
		ALTER TABLE histemailsent add appointment_datetime datetime null COMMENT  'update appointment datetime to reflect the activity in patient profile';
	END IF; 

    -- opendental_configuration
    SELECT column_name INTO colName
	FROM information_schema.columns 
	WHERE table_schema = 'justdentaldb'
		AND table_name = 'opendental_configuration'
	AND column_name = 'review_url';

    IF colName is null THEN 
        ALTER TABLE `justdentaldb`.`opendental_configuration` 
        ADD COLUMN `review_url` VARCHAR(2000) NULL AFTER `active`,
        ADD COLUMN `feedback_url` VARCHAR(2000) NULL AFTER `review_url`,
        ADD COLUMN `website_url` VARCHAR(2000) NULL AFTER `feedback_url`,
        ADD COLUMN `microsite_url` VARCHAR(2000) NULL AFTER `website_url`,
        ADD COLUMN `other1_url` VARCHAR(2000) NULL AFTER `microsite_url`,
        ADD COLUMN `other2_url` VARCHAR(2000) NULL AFTER `other1_url`;
    END IF;

    -- consent table
        SELECT column_name INTO colName
	FROM information_schema.columns 
	WHERE table_schema = 'justdentaldb'
		AND table_name = 'consent'
	AND column_name = 'imageFolder';
    IF colName is null THEN 
        ALTER TABLE `justdentaldb`.`consent` 
        ADD COLUMN `imageFolder` VARCHAR(200) NULL;
    END IF;

    -- payoption table
    SELECT column_name INTO colName
	FROM information_schema.columns 
	WHERE table_schema = 'justdentaldb'
		AND table_name = 'payoption'
	AND column_name = 'imageFolder';
    IF colName is null THEN 
        ALTER TABLE `justdentaldb`.`payoption` 
        ADD COLUMN `imageFolder` VARCHAR(200) NULL;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:51
