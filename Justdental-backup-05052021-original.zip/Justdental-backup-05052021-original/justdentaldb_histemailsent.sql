-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `histemailsent`
--

DROP TABLE IF EXISTS `histemailsent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `histemailsent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_schedule_id` int(11) DEFAULT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `email_to` varchar(250) DEFAULT NULL,
  `email_cc` varchar(250) DEFAULT NULL,
  `text_to` varchar(10) DEFAULT NULL,
  `message_status` bit(1) DEFAULT b'0',
  `message_error` varchar(2500) DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `createdby` int(11) DEFAULT NULL,
  `appointment_datetime` datetime DEFAULT NULL COMMENT 'update appointment datetime to reflect the activity in patient profile',
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `templates` (`id`),
  KEY `template_id_idfk_1` (`template_id`),
  CONSTRAINT `template_id_idfk_1` FOREIGN KEY (`template_id`) REFERENCES `templates` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `histemailsent`
--

LOCK TABLES `histemailsent` WRITE;
/*!40000 ALTER TABLE `histemailsent` DISABLE KEYS */;
INSERT INTO `histemailsent` VALUES (71,1,4,3,1,2,2,'grant_terasa@gmail.com','mohan.k@bloomfieldx.com','',_binary '','','2021-04-21 21:42:35',1,'2021-04-21 16:55:00',1),(72,1,4,3,1,2,2,'grant_terasa@gmail.com','mohan.k@bloomfieldx.com','',_binary '','','2021-04-21 22:10:22',1,'2021-04-21 16:55:00',1);
/*!40000 ALTER TABLE `histemailsent` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger add_email_activity
after insert
ON histemailsent for each row
begin
	declare __template_eventname varchar(5000) default '';
    declare __activity_role varchar(100) default '';
    declare __activity_description varchar(1000) default '';
    declare __appointment_datetime varchar(30);
    
    select e.name into __template_eventname
	from trigger_event te
	left join event e on e.id = te.event_id
	where te.template_id = new.template_id limit 1;
	SET __appointment_datetime = new.appointment_datetime;
    -- select appt.AptDateTime into __appointment_datetime from appointment appt where appt.AptNum = new.appointment_id;
    
    -- setting __activity_role
    
    if(LOWER(__template_eventname) like '%reschedule appointment%') then
		set __activity_role = concat('Your appointment is rescheduled to ', DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i %p")); -- + DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i");
    elseif(LOWER(__template_eventname) like '%appointment is scheduled%') then
		set __activity_role = concat('Your appointment is scheduled on ' , DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i %p")); -- + DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i");
    elseif(LOWER(__template_eventname) like '%cancel appointment%') then
		set __activity_role = concat('Your appointment is cancelled for ',  DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i %p")); --  + DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i");
    elseif(LOWER(__template_eventname) like '%reminder%') then
		set __activity_role = concat('Appointment reminder was sent for ', DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i %p")); --  + DATE_FORMAT(__appointment_datetime, "%M %d %Y %H:%i");
    elseif(LOWER(__template_eventname) like '%birthday wishes%') then
		set __activity_role = 'Birthday Wishes have been';
    elseif(LOWER(__template_eventname) like '%appointment%' or LOWER(__template_eventname) like '%reminder%') then
		set __activity_role = 'Appointment';
	elseif(LOWER(__template_eventname) like '%patient%') then
		set __activity_role = 'Patient';
	elseif(LOWER(__template_eventname) like '%patient%') then
		set __activity_role = 'Patient1';
    end if;
    
    -- setting __activity_description
    if(LOWER(__template_eventname) like '%reminder%') then
		set __activity_description = 'Reminder sent';
	else
		set __activity_description = __template_eventname;
    end if;
    
    -- insert data into activity table
	if new.email_to IS NOT NULL then
		INSERT INTO activity (
			patient_id	
			,activity_type_id
			,act_datetime
			,act_description
            ,act_role
            ,act_other
			,user_id
			,createdby
            ,createdon
            ,clinic_id
        ) values (
			new.patient_id
			,1
			,__appointment_datetime
			,__activity_description
            ,__activity_role
            ,''
			,new.createdby
			,new.createdby
            ,__appointment_datetime
            ,new.clinic_id
        );
    end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:46
