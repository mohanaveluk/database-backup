-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_registration_status`
--

DROP TABLE IF EXISTS `account_registration_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_registration_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(20) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `guid` varchar(250) DEFAULT NULL,
  `createon` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `iscompleted` int(11) DEFAULT '0',
  `completedon` datetime DEFAULT NULL,
  `active` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `clinic_id` (`clinic_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_account_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_registration_status`
--

LOCK TABLES `account_registration_status` WRITE;
/*!40000 ALTER TABLE `account_registration_status` DISABLE KEYS */;
INSERT INTO `account_registration_status` VALUES (1,5,19,'ef407988-0386-4508-ba11-7da7bd78fb551','2021-04-29 22:51:54',1,'2021-05-03 14:48:00',0),(2,5,19,'55ecb2b4-dee5-41d3-b93a-2068fa7286a7','2021-04-29 23:05:00',1,'2021-05-03 14:48:00',0),(3,5,21,'a38530aa-9714-4204-bc1e-d5dc6a606a75','2021-05-03 16:24:15',1,'2021-05-03 14:48:00',0),(4,8,22,'4299f113-33f5-4a67-929f-2c5b68133692','2021-05-03 17:27:52',1,'2021-05-03 14:48:00',0),(5,9,23,'c46513b7-72fc-4d83-96c2-025e17abb2c6','2021-05-03 18:59:32',1,'2021-05-03 14:48:00',0),(6,9,23,'d1ab2c55-c018-4d32-8e3f-386061dbb28b','2021-05-03 19:21:40',1,'2021-05-03 14:48:00',0),(7,9,23,'282a2902-9d8b-4d31-87cc-b93a4f2cf396','2021-05-03 19:46:23',1,'2021-05-03 14:48:00',0);
/*!40000 ALTER TABLE `account_registration_status` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:43
