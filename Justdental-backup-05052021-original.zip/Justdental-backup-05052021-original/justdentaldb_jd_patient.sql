-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_patient`
--

DROP TABLE IF EXISTS `jd_patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_patient` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `PatNum` bigint(20) DEFAULT NULL,
  `LName` varchar(100) DEFAULT '',
  `FName` varchar(100) DEFAULT '',
  `MiddleI` varchar(100) DEFAULT '',
  `Preferred` varchar(100) DEFAULT '',
  `PatStatus` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Position` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `Birthdate` date NOT NULL DEFAULT '0001-01-01',
  `SSN` varchar(100) DEFAULT '',
  `Address` varchar(100) DEFAULT '',
  `Address2` varchar(100) DEFAULT '',
  `City` varchar(100) DEFAULT '',
  `State` varchar(100) DEFAULT '',
  `Zip` varchar(100) DEFAULT '',
  `HmPhone` varchar(30) DEFAULT '',
  `WkPhone` varchar(30) DEFAULT '',
  `WirelessPhone` varchar(30) DEFAULT '',
  `Guarantor` bigint(20) NOT NULL,
  `CreditType` char(1) DEFAULT '',
  `Email` varchar(100) DEFAULT '',
  `Salutation` varchar(100) DEFAULT '',
  `EstBalance` double NOT NULL DEFAULT '0',
  `PriProv` bigint(20) NOT NULL,
  `SecProv` bigint(20) NOT NULL,
  `FeeSched` bigint(20) NOT NULL,
  `BillingType` bigint(20) NOT NULL,
  `ImageFolder` varchar(100) DEFAULT '',
  `AddrNote` text,
  `FamFinUrgNote` text,
  `MedUrgNote` varchar(255) DEFAULT '',
  `ApptModNote` varchar(255) DEFAULT '',
  `StudentStatus` char(1) DEFAULT '',
  `SchoolName` varchar(255) NOT NULL,
  `ChartNumber` varchar(20) DEFAULT '',
  `MedicaidID` varchar(20) DEFAULT '',
  `Bal_0_30` double NOT NULL DEFAULT '0',
  `Bal_31_60` double NOT NULL DEFAULT '0',
  `Bal_61_90` double NOT NULL DEFAULT '0',
  `BalOver90` double NOT NULL DEFAULT '0',
  `InsEst` double NOT NULL DEFAULT '0',
  `BalTotal` double NOT NULL DEFAULT '0',
  `EmployerNum` bigint(20) NOT NULL,
  `EmploymentNote` varchar(255) DEFAULT '',
  `County` varchar(255) DEFAULT '',
  `GradeLevel` tinyint(4) NOT NULL DEFAULT '0',
  `Urgency` tinyint(4) NOT NULL DEFAULT '0',
  `DateFirstVisit` date NOT NULL DEFAULT '0001-01-01',
  `ClinicNum` bigint(20) NOT NULL,
  `HasIns` varchar(255) DEFAULT '',
  `TrophyFolder` varchar(255) DEFAULT '',
  `PlannedIsDone` tinyint(3) unsigned NOT NULL,
  `Premed` tinyint(3) unsigned NOT NULL,
  `Ward` varchar(255) DEFAULT '',
  `PreferConfirmMethod` tinyint(3) unsigned NOT NULL,
  `PreferContactMethod` tinyint(3) unsigned NOT NULL,
  `PreferRecallMethod` tinyint(3) unsigned NOT NULL,
  `SchedBeforeTime` time DEFAULT NULL,
  `SchedAfterTime` time DEFAULT NULL,
  `SchedDayOfWeek` tinyint(3) unsigned NOT NULL,
  `Language` varchar(100) DEFAULT '',
  `AdmitDate` date NOT NULL DEFAULT '0001-01-01',
  `Title` varchar(15) DEFAULT NULL,
  `PayPlanDue` double NOT NULL,
  `SiteNum` bigint(20) NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ResponsParty` bigint(20) NOT NULL,
  `CanadianEligibilityCode` tinyint(4) NOT NULL,
  `AskToArriveEarly` int(11) NOT NULL,
  `PreferContactConfidential` tinyint(4) NOT NULL,
  `SuperFamily` bigint(20) NOT NULL,
  `TxtMsgOk` tinyint(4) NOT NULL,
  `SmokingSnoMed` varchar(32) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `DateTimeDeceased` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `BillingCycleDay` int(11) NOT NULL DEFAULT '1',
  `SecUserNumEntry` bigint(20) NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `HasSuperBilling` tinyint(4) NOT NULL,
  `PatNumCloneFrom` bigint(20) NOT NULL,
  `DiscountPlanNum` bigint(20) NOT NULL,
  `HasSignedTil` bigint(4) DEFAULT NULL,
  `ShortCodeOptIn` bigint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indexPatNum` (`PatNum`),
  KEY `indexLName` (`LName`(10)),
  KEY `indexFName` (`FName`(10)),
  KEY `indexLFName` (`LName`,`FName`),
  KEY `indexGuarantor` (`Guarantor`),
  KEY `ResponsParty` (`ResponsParty`),
  KEY `SuperFamily` (`SuperFamily`),
  KEY `SiteNum` (`SiteNum`),
  KEY `PatStatus` (`PatStatus`),
  KEY `ClinicNum` (`ClinicNum`),
  KEY `Email` (`Email`),
  KEY `ChartNumber` (`ChartNumber`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `HmPhone` (`HmPhone`),
  KEY `WirelessPhone` (`WirelessPhone`),
  KEY `WkPhone` (`WkPhone`),
  KEY `PatNumCloneFrom` (`PatNumCloneFrom`),
  KEY `DiscountPlanNum` (`DiscountPlanNum`),
  KEY `FeeSched` (`FeeSched`),
  KEY `SecDateEntry` (`SecDateEntry`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_patient`
--

LOCK TABLES `jd_patient` WRITE;
/*!40000 ALTER TABLE `jd_patient` DISABLE KEYS */;
INSERT INTO `jd_patient` VALUES (1,1,'R','2021-05-05 08:17:00',1,'Grant','Teresa','','',0,0,1,'1988-08-15','','','','','','','','','(925)332-0011',1,'','grant_terasa@gmail.com','',2645,1,0,0,40,'GrantTeresa1','','','','','','','','',135,75,75,2420,0,2705,0,'','',0,0,'2019-08-07',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',2775,0,'2020-12-09 18:22:41',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0,0,0),(2,1,'R','2021-05-05 08:17:00',2,'Grant','Mark','','',0,0,1,'1999-09-22','','','','','','','','','(210)343-9315',1,'','','',0,1,0,0,40,'GrantMark2','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-08-07',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-10-02 23:49:37',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0,0,0),(3,1,'R','2021-05-05 08:17:00',3,'Grant','Stewert','','',0,0,0,'1979-01-29','954874521',' 1234 Happy freeway','','San Antonio','TX','78248','','','(201)696-1029',3,'','gteresa@gmail.com','',724,1,0,0,40,'GrantStewert3','','','','','','','','',103,0,0,621,0,724,0,'','',0,0,'2019-08-09',0,'I','',0,0,'',0,3,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-10-12 00:56:01',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0,0,0),(4,1,'R','2021-05-05 08:17:00',4,'Grant','','','',4,2,0,'0001-01-01','','','','','','','','','',4,'','','',0,1,0,0,40,'','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'0001-01-01',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2019-08-07 19:15:47',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0,0,0),(5,1,'R','2021-05-05 08:17:00',5,'Grant','Santra','','',0,1,0,'2002-03-30','','','','','','','','','(925)332-0011',1,'','grant.santra@gmail.com','',60,1,0,0,40,'GrantSantra5','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2019-08-09',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-09 18:22:41',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2019-08-07',0,0,0,0,0),(6,1,'R','2021-05-05 08:17:00',6,'Grant','','','',4,2,0,'0001-01-01','','','','','','','','','',6,'','','',0,1,0,0,40,'','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'0001-01-01',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-09-27 23:18:39',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(7,1,'R','2021-05-05 08:17:00',7,'Patient1','Test','','',0,0,1,'1998-05-06','','','','','','','','','(939)393-9393',7,'','testpatient1@gmail.com','',0,1,0,0,40,'PatientTest7','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-01',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-15 20:45:33',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(8,1,'R','2021-05-05 08:17:00',8,'Patient2','Test','','',0,0,0,'0001-01-01','','','','','','','','','(929)292-9292',8,'','testpatient2@gmail.com','',0,1,0,0,40,'','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-07',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-26 06:55:58',0,0,0,0,0,0,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(9,1,'R','2021-05-05 08:17:00',9,'Patient3','Test3','','',0,0,1,'1995-05-06','','','','','','','','','(925)332-0011',9,'','testpatient3@gmail.com','',0,1,0,0,40,'PatientTest9','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-07',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-27 02:35:20',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(10,1,'R','2021-05-05 08:17:00',10,'Patient4','Test4','','',0,1,0,'1998-06-07','','','','','','','','','',9,'','testpatient3@gmail.com','',0,1,0,0,40,'PatientTest10','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-08',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-26 06:56:34',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(11,1,'R','2021-05-05 08:17:00',11,'Patient5','Test5','','',0,1,2,'2009-03-26','','','','','','','','','',9,'','testpatient3@gmail.com','',0,1,0,0,40,'PatientTest11','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-08',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-26 06:57:03',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(12,1,'R','2021-05-05 08:17:00',12,'Patient6','Test6','','',0,0,2,'2013-05-13','','','','','','','','','',9,'','testpatient3@gmail.com','',0,1,0,0,40,'PatientTest12','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-09',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-26 06:57:23',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(13,1,'R','2021-05-05 08:17:00',13,'Patient7','Test7','','',0,1,2,'2015-09-19','','','','','','','','','',9,'',NULL,'',0,1,0,0,40,'PatientTest13','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-09',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-12 21:18:27',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(14,1,'R','2021-05-05 08:17:00',14,'Patient8','Test8','','',0,0,1,'1971-12-12','','','','','','','','','(925)332-6545',14,'','testpatient8@gmail.com','',72,1,0,0,40,'PatientTest14','','','','','','','','',72,210,63,0,0,345,0,'','',0,0,'2020-10-05',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-20 19:37:28',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(15,1,'R','2021-05-05 08:17:00',15,'Patient9','Test9','','',0,1,1,'1975-12-13','','','','','','','','','',14,'','testpatient8@gmail.com','',0,1,0,0,40,'','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-02',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-10-02 17:01:26',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(16,1,'R','2021-05-05 08:17:00',16,'Patient10','Test10','','',0,1,2,'1984-12-14','','','','','','','','','(925)332-8564',14,'','testpatient8@gmail.com','',55,1,0,0,40,'PatientTest16','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-01',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-16 22:35:13',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(17,1,'R','2021-05-05 08:17:00',17,'Patient11','Test11','','',0,0,2,'2004-12-15','','','','','','','','','',14,'','testpatient8@gmail.com','',55,1,0,0,40,'PatientTest17','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-02',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-16 22:35:13',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(18,1,'R','2021-05-05 08:17:00',18,'Patient12','Test12','','',0,1,2,'2012-12-16','','','','','','','','','',14,'','testpatient8@gmail.com','',163,1,0,0,40,'PatientTest18','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-02',0,'I','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-12-20 19:30:24',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(19,1,'R','2021-05-05 08:17:00',19,'Patient13','Test13','','',0,0,1,'1965-07-30','','','','','','','','','(971)236-9874',19,'','testpatient13@gmail.com','',0,1,0,0,40,'PatientTest19','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-12-03',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-26 06:52:42',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(20,1,'R','2021-05-05 08:17:00',20,'Patient14','Test14','','',0,1,1,'1969-07-30','','','','','','','','','(925)332-0011',19,'','testpatient13@gmail.com','',0,1,0,0,40,'PatientTest20','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-07',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2021-01-24 07:03:45',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(21,1,'R','2021-05-05 08:17:00',21,'Patient15','Test15','','',0,0,2,'1976-07-30','','','','','','','','','(971)236-9874',19,'','testpatient13@gmail.com','',0,1,0,0,40,'PatientTest21','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-07',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-10-07 14:26:24',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(22,1,'R','2021-05-05 08:17:00',22,'Patient16','Test16','','',0,0,2,'1980-07-30','','','','','','','','','(971)236-9874',19,'','testpatient13@gmail.com','',0,1,0,0,40,'PatientTest22','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-10-15',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-10-12 22:10:08',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0),(23,1,'R','2021-05-05 08:17:00',23,'Patient17','Test17','','',0,0,2,'1988-07-30','','','','','','','','','(971)236-9874',19,'','testpatient13@gmail.com','',0,1,0,0,40,'PatientTest23','','','','','','','','',0,0,0,0,0,0,0,'','',0,0,'2020-11-16',0,'','',0,0,'',0,0,0,'00:00:00','00:00:00',0,'','0001-01-01','',0,0,'2020-11-14 04:39:40',0,0,0,0,0,1,'','','0001-01-01 00:00:00',1,1,'2020-09-27',0,0,0,0,0);
/*!40000 ALTER TABLE `jd_patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:48
