-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_commlog`
--

DROP TABLE IF EXISTS `jd_commlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_commlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `CommlogNum` bigint(20) NOT NULL,
  `PatNum` bigint(20) NOT NULL,
  `CommDateTime` datetime NOT NULL DEFAULT '0000-01-01 00:00:00',
  `CommType` bigint(20) NOT NULL,
  `Note` text,
  `Mode_` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SentOrReceived` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `UserNum` bigint(20) NOT NULL,
  `Signature` text NOT NULL,
  `SigIsTopaz` tinyint(4) NOT NULL,
  `DateTStamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DateTimeEnd` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `CommSource` tinyint(4) DEFAULT NULL,
  `ProgramNum` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CommlogNum` (`CommlogNum`),
  KEY `PatNum` (`PatNum`),
  KEY `CommDateTime` (`CommDateTime`),
  KEY `CommType` (`CommType`),
  KEY `ProgramNum` (`ProgramNum`),
  KEY `indexPNCDateCType` (`PatNum`,`CommDateTime`,`CommType`),
  KEY `UserNum` (`UserNum`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_commlog`
--

LOCK TABLES `jd_commlog` WRITE;
/*!40000 ALTER TABLE `jd_commlog` DISABLE KEYS */;
INSERT INTO `jd_commlog` VALUES (1,1,'R','2021-05-05 08:17:00',1,5,'2021-01-11 15:10:17',235,'\'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged\'',0,0,1,'0',0,'2021-01-11 22:55:27','0001-01-01 00:00:00',0,0),(2,1,'R','2021-05-05 08:17:00',2,5,'2021-01-11 15:14:54',235,'First note',0,0,1,'0',0,'2021-01-11 21:15:52','0001-01-01 00:00:00',0,0),(3,1,'R','2021-05-05 08:17:00',3,5,'2021-01-11 15:59:41',237,'Second note',3,0,1,'0',0,'2021-01-11 21:59:54','0001-01-01 00:00:00',0,0),(4,1,'R','2021-05-05 08:17:00',4,5,'2021-01-11 16:04:40',235,'dfdfdfdf',0,0,1,'0',0,'2021-01-11 22:04:40','0001-01-01 00:00:00',0,0),(5,1,'R','2021-05-05 08:17:00',5,5,'2021-01-11 16:08:16',303,'fourth entry',0,0,1,'0',0,'2021-01-11 22:08:26','0001-01-01 00:00:00',0,0),(6,1,'R','2021-05-05 08:17:00',6,5,'2021-01-11 16:13:16',303,'Fifth entry',0,0,1,'0',0,'2021-01-11 22:13:21','0001-01-01 00:00:00',0,0),(7,1,'R','2021-05-05 08:17:00',7,5,'2021-01-11 16:17:44',235,'Sixth entry',0,0,1,'0',0,'2021-01-11 22:17:58','0001-01-01 00:00:00',0,0),(8,1,'R','2021-05-05 08:17:00',8,5,'2021-01-11 16:21:56',239,'Seventh entry',4,2,1,'0',0,'2021-01-11 22:22:08','0001-01-01 00:00:00',0,0),(9,1,'R','2021-05-05 08:17:00',9,5,'2021-01-11 16:24:02',298,'Eighth summary',4,1,1,'0',0,'2021-01-11 22:24:02','0001-01-01 00:00:00',0,0),(10,1,'R','2021-05-05 08:17:00',10,3,'2021-01-11 16:35:07',238,'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book',3,2,1,'0',0,'2021-01-11 22:35:07','0001-01-01 00:00:00',0,0),(11,1,'R','2021-05-05 08:17:00',11,3,'2021-01-11 16:59:53',303,'\'It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum\'',1,1,1,'0',0,'2021-01-11 22:59:53','0001-01-01 00:00:00',0,0),(12,1,'R','2021-05-05 08:17:00',12,3,'2021-01-11 17:00:15',237,'\'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, \'',5,1,1,'0',0,'2021-01-11 23:00:15','0001-01-01 00:00:00',0,0),(13,1,'R','2021-05-05 08:17:00',13,2,'2021-01-11 17:03:18',236,'\'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\'',0,0,1,'0',0,'2021-01-11 23:03:18','0001-01-01 00:00:00',0,0),(14,1,'R','2021-05-05 08:17:00',14,2,'2021-01-11 17:10:09',0,'\'sdsdsdsd\'',0,0,1,'0',0,'2021-01-11 23:10:09','0001-01-01 00:00:00',0,0),(15,1,'R','2021-05-05 08:17:00',15,2,'2021-01-11 17:58:22',237,'making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy',3,1,1,'0',0,'2021-01-11 23:59:06','0001-01-01 00:00:00',0,0),(16,1,'R','2021-05-05 08:17:00',16,1,'2021-01-11 18:00:31',235,'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, ',0,0,1,'0',0,'2021-01-12 00:00:37','0001-01-01 00:00:00',0,0),(17,1,'R','2021-05-05 08:17:00',17,2,'2021-01-11 19:02:24',235,'sdssd',0,0,1,'0',0,'2021-01-12 01:02:24','0001-01-01 00:00:00',0,0),(18,1,'R','2021-05-05 08:17:00',18,2,'2021-01-11 19:07:38',235,'making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.',0,0,1,'0',0,'2021-01-12 01:07:38','0001-01-01 00:00:00',0,0),(19,1,'R','2021-05-05 08:17:00',19,2,'2021-01-11 19:19:55',235,'sample test',0,0,1,'0',0,'2021-01-12 01:19:55','0001-01-01 00:00:00',0,0),(20,1,'R','2021-05-05 08:17:00',20,8,'2021-01-11 19:23:31',238,'test from chat',1,0,1,'0',0,'2021-01-12 01:23:31','0001-01-01 00:00:00',0,0);
/*!40000 ALTER TABLE `jd_commlog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:46
