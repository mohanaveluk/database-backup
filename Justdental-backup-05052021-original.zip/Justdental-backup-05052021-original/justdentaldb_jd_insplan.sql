-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: justdentaldb
-- ------------------------------------------------------
-- Server version	5.5.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jd_insplan`
--

DROP TABLE IF EXISTS `jd_insplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jd_insplan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clinic_id` bigint(10) DEFAULT NULL,
  `update_mode` char(1) NOT NULL DEFAULT 'R',
  `updatedon` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `PlanNum` bigint(20) NOT NULL,
  `GroupName` varchar(50) DEFAULT '',
  `GroupNum` varchar(25) DEFAULT NULL,
  `PlanNote` text NOT NULL,
  `FeeSched` bigint(20) NOT NULL,
  `PlanType` char(1) DEFAULT '',
  `ClaimFormNum` bigint(20) NOT NULL,
  `UseAltCode` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ClaimsUseUCR` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `CopayFeeSched` bigint(20) NOT NULL,
  `EmployerNum` bigint(20) NOT NULL,
  `CarrierNum` bigint(20) NOT NULL,
  `AllowedFeeSched` bigint(20) NOT NULL,
  `TrojanID` varchar(100) DEFAULT '',
  `DivisionNo` varchar(255) DEFAULT '',
  `IsMedical` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `FilingCode` bigint(20) NOT NULL,
  `DentaideCardSequence` tinyint(3) unsigned NOT NULL,
  `ShowBaseUnits` tinyint(1) NOT NULL,
  `CodeSubstNone` tinyint(1) NOT NULL,
  `IsHidden` tinyint(4) NOT NULL,
  `MonthRenew` tinyint(4) NOT NULL,
  `FilingCodeSubtype` bigint(20) NOT NULL,
  `CanadianPlanFlag` varchar(5) NOT NULL,
  `CanadianDiagnosticCode` varchar(255) NOT NULL,
  `CanadianInstitutionCode` varchar(255) NOT NULL,
  `RxBIN` varchar(255) NOT NULL,
  `CobRule` tinyint(4) NOT NULL,
  `SopCode` varchar(255) NOT NULL,
  `SecUserNumEntry` bigint(20) NOT NULL,
  `SecDateEntry` date NOT NULL DEFAULT '0001-01-01',
  `SecDateTEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `HideFromVerifyList` tinyint(4) NOT NULL,
  `OrthoType` tinyint(4) NOT NULL,
  `OrthoAutoProcFreq` tinyint(4) NOT NULL,
  `OrthoAutoProcCodeNumOverride` bigint(20) NOT NULL,
  `OrthoAutoFeeBilled` double NOT NULL,
  `OrthoAutoClaimDaysWait` int(11) NOT NULL,
  `BillingType` bigint(20) NOT NULL,
  `HasPpoSubstWriteoffs` tinyint(4) NOT NULL,
  `ExclusionFeeRule` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `CarrierNum` (`CarrierNum`),
  KEY `FilingCodeSubtype` (`FilingCodeSubtype`),
  KEY `TrojanID` (`TrojanID`),
  KEY `SecUserNumEntry` (`SecUserNumEntry`),
  KEY `CarrierNumPlanNum` (`CarrierNum`,`PlanNum`),
  KEY `OrthoAutoProcCodeNumOverride` (`OrthoAutoProcCodeNumOverride`),
  KEY `BillingType` (`BillingType`),
  KEY `FeeSched` (`FeeSched`),
  KEY `CopayFeeSched` (`CopayFeeSched`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jd_insplan`
--

LOCK TABLES `jd_insplan` WRITE;
/*!40000 ALTER TABLE `jd_insplan` DISABLE KEYS */;
INSERT INTO `jd_insplan` VALUES (1,1,'R','2021-05-05 08:17:00',5,'','','',53,'',3,0,0,0,0,6,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2019-08-09','2019-08-09 23:52:35',0,0,0,0,0,0,0,1,0),(2,1,'R','2021-05-05 08:17:00',6,'','','',0,'',3,0,0,0,0,6,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2019-08-09','2019-08-09 23:57:07',0,0,0,0,0,0,0,1,0),(3,1,'R','2021-05-05 08:17:00',7,'','','',0,'',3,0,0,0,0,6,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2019-08-09','2019-08-09 23:57:30',0,0,0,0,0,0,0,1,0),(4,1,'R','2021-05-05 08:17:00',8,'','','',0,'',3,0,0,0,0,6,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2019-08-09','2019-08-10 00:14:21',0,0,0,0,0,0,0,1,0),(5,1,'R','2021-05-05 08:17:00',9,'TPX','9373748','',0,'',3,0,0,0,1,7,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2020-12-20','2020-12-20 19:30:23',0,0,0,0,0,0,0,1,0),(6,1,'R','2021-05-05 08:17:00',10,'','','',0,'',3,0,0,0,2,8,0,'','',0,0,0,0,0,0,0,0,'','','','',1,'',1,'2020-12-28','2020-12-29 02:16:31',0,0,0,0,0,0,0,1,0);
/*!40000 ALTER TABLE `jd_insplan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-05 19:19:48
